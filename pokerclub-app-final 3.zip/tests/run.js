#!/usr/bin/env node
var fs = require("fs");
var path = require("path");
var vm = require("vm");
var assert = require("assert");

var code = fs.readFileSync(path.join(__dirname, "../js/store.js"), "utf8");
var sandbox = { console: console, Date: Date, Math: Math, JSON: JSON, Number: Number, String: String, Array: Array, Object: Object };
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
sandbox.localStorage = (function () {
  var m = {};
  return {
    getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
    setItem: function (k, v) { m[k] = String(v); },
    removeItem: function (k) { delete m[k]; }
  };
})();
vm.runInNewContext(code, sandbox);
var S = sandbox.PokerStore;
S.resetAll();

var fails = 0;
function test(name, fn) {
  try {
    fn();
    console.log("OK  " + name);
  } catch (e) {
    fails++;
    console.log("FAIL " + name);
    console.log("    " + e.message);
  }
}

test("cadastrar jogador", function () {
  var p = S.addPlayer({ name: "Carlos Silva", nickname: "Carlão", phone: "11999990000" });
  assert.ok(p.id);
  assert.strictEqual(S.state().players.length, 1);
  assert.strictEqual(S.displayName(p).indexOf("Carlão") > -1, true);
});

test("rejeitar jogador sem nome", function () {
  var threw = false;
  try { S.addPlayer({ name: "  " }); } catch (e) { threw = true; }
  assert.ok(threw);
});

test("editar e buscar jogador", function () {
  var p = S.state().players[0];
  S.updatePlayer(p.id, { name: "Carlos Silva", nickname: "CS", phone: "11888887777" });
  var found = S.searchPlayers("cs");
  assert.strictEqual(found.length, 1);
  found = S.searchPlayers("zzz");
  assert.strictEqual(found.length, 0);
});

test("criar torneio e adicionar jogadores", function () {
  var a = S.addPlayer({ name: "Ana Souza", nickname: "Aninha" });
  var b = S.addPlayer({ name: "Bruno Lima", nickname: "Brunão" });
  var t = S.addTournament({ name: "Friday Night", date: "2026-10-05", time: "20:00", buyIn: 50 });
  S.setTournamentPlayers(t.id, [S.state().players[2].id, a.id, b.id]);
  t = S.getTournament(t.id);
  assert.strictEqual(t.entries.length, 3);
  assert.strictEqual(S.playerTournamentsCount(a.id), 1);
});

test("pagamento pendente e pago", function () {
  var t = S.state().tournaments[0];
  var pid = t.entries[0].playerId;
  S.registerPayment(t.id, pid, 50);
  t = S.getTournament(t.id);
  assert.strictEqual(t.entries[0].paid, true);
  assert.strictEqual(S.collected(t), 50);
  S.markPending(t.id, pid);
  t = S.getTournament(t.id);
  assert.strictEqual(t.entries[0].paid, false);
  S.registerPayment(t.id, pid, 50);
});

test("cronometro iniciar pausar reiniciar e proxima rodada", function () {
  var t = S.state().tournaments[0];
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.timerRunning, true);
  assert.strictEqual(t.status, "live");
  S.pauseTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.timerRunning, false);
  S.resetTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, t.levels[0].minutes * 60);
  S.nextLevel(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, 1);
  S.prevLevel(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, 0);
});

test("tick zera o tempo", function () {
  var t = S.state().tournaments[0];
  t.timerRunning = true;
  t.remainingSec = 2;
  t.timerUpdatedAt = Date.now() - 3000;
  S.save();
  S.tickTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, 0);
  assert.strictEqual(t.timerRunning, false);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.currentLevel, 0);
});

test("admin confirma proxima rodada e inicia cronometro", function () {
  var t = S.state().tournaments[0];
  var level = t.currentLevel;
  S.confirmNextRound(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, level + 1);
  assert.strictEqual(t.roundEnded, false);
  assert.strictEqual(t.timerRunning, true);
  assert.strictEqual(t.remainingSec, t.levels[t.currentLevel].minutes * 60);
});

test("00:00 dispara fim da rodada sem mudar blinds e admin inicia depois", function () {
  var t = S.addTournament({ name: "Clock Test", date: "2026-10-05", time: "21:00", buyIn: 50 });
  S.setLevels(t.id, [
    { minutes: 1, small: 25, big: 50, ante: 0 },
    { minutes: 2, small: 50, big: 100, ante: 0 }
  ]);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  t.timerRunning = true;
  t.remainingSec = 10;
  t.timerUpdatedAt = Date.now() - 11000;
  S.save();
  S.tickTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, 0);
  assert.strictEqual(t.timerRunning, false);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.currentLevel, 0);
  assert.strictEqual(t.levels[0].small, 25);
  assert.strictEqual(t.levels[0].big, 50);
  var endedAt = t.roundEndedAt;
  var remaining = t.remainingSec;
  var level = t.currentLevel;
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, remaining);
  assert.strictEqual(t.currentLevel, level);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.roundEndedAt, endedAt);
  S.confirmNextRound(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, 1);
  assert.strictEqual(t.roundEnded, false);
  assert.strictEqual(t.timerRunning, true);
  assert.strictEqual(t.remainingSec, 120);
  assert.strictEqual(t.levels[t.currentLevel].small, 50);
  assert.strictEqual(t.levels[t.currentLevel].big, 100);
  S.deleteTournament(t.id);
});

test("clicar cronometro nao muda tempo blinds nem rodada", function () {
  var t = S.addTournament({ name: "No Block", date: "2026-10-05", time: "22:30", buyIn: 50 });
  S.setLevels(t.id, [
    { minutes: 15, small: 25, big: 50, ante: 0 },
    { minutes: 12, small: 50, big: 100, ante: 0 }
  ]);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  t.timerRunning = true;
  t.remainingSec = 1;
  t.timerUpdatedAt = Date.now() - 2000;
  S.save();
  S.tickTimer(t.id);
  t = S.getTournament(t.id);
  var remaining = t.remainingSec;
  var level = t.currentLevel;
  var small = t.levels[0].small;
  var big = t.levels[0].big;
  var endedAt = t.roundEndedAt;
  assert.strictEqual(remaining, 0);
  assert.strictEqual(t.roundEnded, true);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, remaining);
  assert.strictEqual(t.currentLevel, level);
  assert.strictEqual(t.levels[0].small, small);
  assert.strictEqual(t.levels[0].big, big);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.roundEndedAt, endedAt);
  assert.strictEqual(t.timerRunning, false);
  S.deleteTournament(t.id);
});

test("fim da rodada permanece ate admin iniciar proxima", function () {
  var t = S.addTournament({ name: "Alert Clock", date: "2026-10-05", time: "22:00", buyIn: 50 });
  S.setLevels(t.id, [
    { minutes: 15, small: 100, big: 200, ante: 25 },
    { minutes: 12, small: 200, big: 400, ante: 50 }
  ]);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  t.timerRunning = true;
  t.remainingSec = 1;
  t.timerUpdatedAt = Date.now() - 2000;
  S.save();
  S.tickTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, 0);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.timerRunning, false);
  assert.strictEqual(t.currentLevel, 0);
  assert.strictEqual(t.levels[0].small, 100);
  assert.strictEqual(t.levels[0].big, 200);
  var level = t.currentLevel;
  var remaining = t.remainingSec;
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, level);
  assert.strictEqual(t.remainingSec, remaining);
  assert.strictEqual(t.roundEnded, true);
  S.confirmNextRound(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.currentLevel, 1);
  assert.strictEqual(t.roundEnded, false);
  assert.strictEqual(t.timerRunning, true);
  S.deleteTournament(t.id);
});

test("tempo manual 5 10 15 nao inicia e nao muda blinds", function () {
  var t = S.addTournament({ name: "Manual Clock", date: "2026-10-05", time: "21:30", buyIn: 50 });
  S.setLevels(t.id, [
    { minutes: 15, small: 25, big: 50, ante: 10 },
    { minutes: 12, small: 50, big: 100, ante: 20 }
  ]);
  var set5 = S.setTimerMinutes(t.id, 5);
  assert.strictEqual(set5.remainingSec, 300);
  assert.strictEqual(set5.timerRunning, false);
  assert.strictEqual(set5.currentLevel, 0);
  assert.strictEqual(set5.levels[0].small, 25);
  assert.strictEqual(set5.levels[0].big, 50);
  assert.strictEqual(set5.levels[0].ante, 10);
  assert.strictEqual(set5.levels[1].small, 50);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.timerRunning, true);
  assert.strictEqual(t.remainingSec, 300);
  S.pauseTimer(t.id);
  var set10 = S.setTimerMinutes(t.id, 10);
  assert.strictEqual(set10.remainingSec, 600);
  assert.strictEqual(set10.timerRunning, false);
  assert.strictEqual(set10.levels[0].small, 25);
  var set15 = S.setTimerMinutes(t.id, 15);
  assert.strictEqual(set15.remainingSec, 900);
  assert.strictEqual(set15.timerRunning, false);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  t.timerRunning = true;
  t.remainingSec = 10;
  t.timerUpdatedAt = Date.now() - 11000;
  S.save();
  S.tickTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, 0);
  assert.strictEqual(t.roundEnded, true);
  assert.strictEqual(t.currentLevel, 0);
  assert.strictEqual(t.levels[0].small, 25);
  var json = S.exportData();
  var parsed = JSON.parse(json);
  assert.strictEqual(parsed.data.tournaments.find(function (x) { return x.id === t.id; }).remainingSec, 0);
  S.applyRemote(parsed.data);
  var remote = S.getTournament(t.id);
  assert.strictEqual(remote.remainingSec, 0);
  assert.strictEqual(remote.roundEnded, true);
  S.setTimerMinutes(t.id, 5);
  t = S.getTournament(t.id);
  assert.strictEqual(t.remainingSec, 300);
  assert.strictEqual(t.timerRunning, false);
  assert.strictEqual(t.roundEnded, false);
  assert.strictEqual(t.levels[0].big, 50);
  var bad = false;
  try { S.setTimerMinutes(t.id, 0); } catch (e) { bad = true; }
  assert.ok(bad);
  S.deleteTournament(t.id);
});

test("eliminar e coroar campeao automaticamente", function () {
  var t = S.state().tournaments[0];
  var ids = t.entries.map(function (e) { return e.playerId; });
  S.eliminatePlayer(t.id, ids[0]);
  S.eliminatePlayer(t.id, ids[1]);
  t = S.getTournament(t.id);
  assert.strictEqual(t.status, "finished");
  assert.ok(t.championId);
  assert.strictEqual(t.championId, ids[2]);
  var rank = S.ranking(t);
  assert.strictEqual(rank[0].position, 1);
  assert.strictEqual(rank[0].playerId, ids[2]);
  var preview = S.previewFinish(t.id, ids[2]);
  assert.strictEqual(preview[0].position, 1);
  var champ = S.champions("2026");
  assert.ok(champ.length >= 1);
  var titles = S.titlesByPlayer("2026");
  assert.ok(titles[0].titles >= 1);
});

test("historico de pagamentos e total", function () {
  var pid = S.state().tournaments[0].entries[0].playerId;
  assert.ok(S.playerPaidTotal(pid) >= 0);
  assert.ok(S.playerPayments(pid).length >= 1);
});

test("exportar e importar backup", function () {
  var json = S.exportData();
  var n = S.state().players.length;
  S.resetAll();
  assert.strictEqual(S.state().players.length, 0);
  S.importData(json);
  assert.strictEqual(S.state().players.length, n);
});

test("excluir jogador e torneio", function () {
  var p = S.addPlayer({ name: "Temp User" });
  S.deletePlayer(p.id);
  assert.strictEqual(!!S.getPlayer(p.id), false);
  var t = S.addTournament({ name: "Temp Cup", buyIn: 10 });
  S.deleteTournament(t.id);
  assert.strictEqual(!!S.getTournament(t.id), false);
});

test("configurar blinds", function () {
  var t = S.addTournament({ name: "Blinds Cup", buyIn: 20 });
  S.setLevels(t.id, [{ minutes: 8, small: 10, big: 20, ante: 0 }]);
  t = S.getTournament(t.id);
  assert.strictEqual(t.levels.length, 1);
  assert.strictEqual(t.levels[0].small, 10);
  assert.strictEqual(t.remainingSec, 8 * 60);
});

test("caixa entradas saidas e totais", function () {
  S.addCash({ type: "in", amount: 100, description: "Rebuy Ana", category: "rebuy", date: "2026-03-10" });
  S.addCash({ type: "out", amount: 40, description: "Jantar", category: "jantar", date: "2026-03-10" });
  var t = S.cashTotals("2026", "03");
  assert.ok(t.income >= 100);
  assert.strictEqual(t.expense, 40);
  assert.ok(t.balance >= 60);
  var month = S.monthlyReport("2026");
  assert.strictEqual(month.length, 12);
  assert.ok(month[2].income >= 100);
  var year = S.yearlyReport().find(function (y) { return y.year === "2026"; });
  assert.ok(year);
  assert.ok(year.expense >= 40);
});

test("criar administrador e entrar na sessao", function () {
  S.resetAll();
  S.logout();
  assert.strictEqual(S.needsSetup(), true);
  assert.strictEqual(S.session(), null);
  var admin = S.registerUser({ name: "Admin Clube", password: "1234", role: "admin" });
  assert.strictEqual(admin.role, "admin");
  S.login("Admin Clube", "1234");
  assert.strictEqual(S.isAdmin(), true);
  assert.strictEqual(S.session().name, "Admin Clube");
  assert.strictEqual(S.needsSetup(), false);
  S.loadSession();
  assert.strictEqual(S.isAdmin(), true);
  S.logout();
  assert.strictEqual(S.session(), null);
  S.login("admin clube", "1234");
  assert.strictEqual(S.isAdmin(), true);
  var dumped = JSON.parse(S.exportData());
  assert.ok(dumped.data.users.length);
  dumped.data.users.forEach(function (u) {
    assert.strictEqual(u.passHash, undefined);
    assert.ok(!("passHash" in u));
  });
  var raw = sandbox.localStorage.getItem(S.KEY);
  assert.ok(raw.indexOf("passHash") < 0);
});

test("admin e jogador", function () {
  S.resetAll();
  var admin = S.registerUser({ name: "Chefe", password: "1234", role: "player" });
  assert.strictEqual(admin.role, "admin");
  S.login("Chefe", "1234");
  assert.strictEqual(S.isAdmin(), true);
  S.registerUser({ name: "Ana", password: "abcd", role: "player" });
  S.logout();
  S.login("Ana", "abcd");
  assert.strictEqual(S.isAdmin(), false);
  var bad = false;
  try { S.login("Ana", "errada"); } catch (e) { bad = true; }
  assert.ok(bad);
});

test("cadastro seguinte nao vira admin sozinho", function () {
  S.resetAll();
  S.registerUser({ name: "Chefe", password: "1234", role: "admin" });
  var player = S.registerUser({ name: "Visitante", password: "abcd", role: "admin" });
  assert.strictEqual(player.role, "player");
});

test("editar e excluir lancamento", function () {
  var item = S.addCash({ type: "in", amount: 25, description: "Addon", category: "addon", date: "2026-04-01" });
  S.updateCash(item.id, { amount: 30, description: "Addon extra" });
  var got = S.getCash(item.id);
  assert.strictEqual(got.amount, 30);
  S.deleteCash(item.id);
  assert.strictEqual(!!S.getCash(item.id), false);
});

test("maos especiais e ranking cash pot", function () {
  S.resetAll();
  var ana = S.addPlayer({ name: "Ana Souza" });
  var bruno = S.addPlayer({ name: "Bruno Lima" });
  var royal = S.addHand({ type: "royal", playerId: ana.id, date: "2026-05-01" });
  assert.strictEqual(royal.points, 10);
  assert.strictEqual(royal.label, "Royal Flush");
  S.addHand({ type: "quads", playerId: bruno.id, date: "2026-05-02" });
  S.addHand({ type: "award", playerId: bruno.id, date: "2026-05-03" });
  S.addHand({ type: "straightflush", playerId: ana.id, date: "2025-12-01" });
  var rank = S.cashPotRanking("2026");
  assert.strictEqual(rank.length, 2);
  assert.strictEqual(rank[0].playerId, ana.id);
  assert.strictEqual(rank[0].points, 10);
  assert.strictEqual(rank[0].royal, 1);
  assert.strictEqual(rank[1].playerId, bruno.id);
  assert.strictEqual(rank[1].points, 6);
  assert.strictEqual(S.handsByYear("2026").length, 3);
  assert.strictEqual(S.handsByYear("2025").length, 1);
  var bad = false;
  try { S.addHand({ type: "fullhouse", playerId: ana.id }); } catch (e) { bad = true; }
  assert.ok(bad);
});

test("fechar e reabrir temporada cash pot", function () {
  var rank = S.cashPotRanking("2026");
  var season = S.closeSeason("2026");
  assert.strictEqual(season.year, "2026");
  assert.strictEqual(season.championId, rank[0].playerId);
  assert.strictEqual(season.points, 10);
  assert.ok(S.getSeason("2026"));
  var empty = false;
  try { S.closeSeason("2099"); } catch (e) { empty = true; }
  assert.ok(empty);
  S.reopenSeason("2026");
  assert.strictEqual(S.getSeason("2026"), null);
  season = S.closeSeason("2026");
  assert.strictEqual(season.championId, rank[0].playerId);
});

test("backup inclui maos e temporadas", function () {
  var json = S.exportData();
  var nHands = S.state().hands.length;
  S.resetAll();
  assert.strictEqual(S.state().hands.length, 0);
  S.importData(json);
  assert.strictEqual(S.state().hands.length, nHands);
  assert.ok(S.getSeason("2026"));
  S.applyRemote({ players: [], tournaments: [], payments: [], cash: [], users: [], hands: [], seasons: [] });
  assert.strictEqual(S.state().hands.length, 0);
  assert.strictEqual(S.state().seasons.length, 0);
});

test("cronometro usa relogio do aparelho sem reescrever a cada segundo", function () {
  var t = S.addTournament({ name: "Sync Clock", date: "2026-10-05", time: "21:00", buyIn: 50 });
  S.setLevels(t.id, [{ minutes: 10, small: 25, big: 50, ante: 0 }]);
  S.startTimer(t.id);
  t = S.getTournament(t.id);
  var stored = t.remainingSec;
  var shown = S.remainingNow(t, Date.now() + 4000);
  assert.ok(shown <= stored - 3);
  assert.strictEqual(S.getTournament(t.id).remainingSec, stored);
  S.pauseTimer(t.id);
  t = S.getTournament(t.id);
  assert.strictEqual(t.timerRunning, false);
  assert.ok(t.remainingSec <= stored);
});

test("relogio livre funciona sem torneio", function () {
  S.resetAll();
  assert.strictEqual(S.state().tournaments.length, 0);
  var c = S.getClock();
  assert.ok(c.remainingSec > 0);
  assert.strictEqual(c.timerRunning, false);
  S.setClockMinutes(5);
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 300);
  assert.strictEqual(c.remainingSec % 60, 0);
  assert.strictEqual(c.timerRunning, false);
  S.setClockMinutes(30);
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 1800);
  assert.strictEqual(c.durationSec, 1800);
  assert.strictEqual(c.remainingSec % 60, 0);
  assert.strictEqual(c.timerRunning, false);
  S.setClockMinutes(15);
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 900);
  assert.strictEqual(c.durationSec, 900);
  assert.strictEqual(c.remainingSec % 60, 0);
  S.setClockMinutes(5);
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 300);
  assert.strictEqual(c.timerRunning, false);
  S.startClock();
  c = S.getClock();
  assert.strictEqual(c.timerRunning, true);
  c.remainingSec = 2;
  c.timerUpdatedAt = Date.now() - 3000;
  c.endAt = Date.now() - 3000;
  S.save();
  S.tickClock();
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 0);
  assert.strictEqual(c.timerRunning, false);
  S.resetClock();
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 300);
  assert.strictEqual(c.durationSec, 300);
  assert.strictEqual(S.clockStatus(), "ready");
  S.setClockMinutes(10);
  S.addClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 660);
  S.addClockSeconds(10);
  assert.strictEqual(S.getClock().remainingSec, 670);
  S.subClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 610);
  S.subClockSeconds(10);
  assert.strictEqual(S.getClock().remainingSec, 600);
  S.resetClock();
  assert.strictEqual(S.getClock().remainingSec, 600);
  S.setClockMinutes(10);
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 600);
  S.startClock();
  S.pauseClock();
  c = S.getClock();
  assert.strictEqual(c.timerRunning, false);
  assert.strictEqual(S.clockStatus(), "paused");
  var paused = c.remainingSec;
  S.startClock();
  c = S.getClock();
  assert.strictEqual(c.timerRunning, true);
  assert.ok(c.remainingSec <= paused);
  assert.strictEqual(S.clockStatus(), "running");
  S.resetClock();
  c = S.getClock();
  assert.strictEqual(c.remainingSec, 600);
  assert.strictEqual(c.timerRunning, false);
  assert.strictEqual(S.clockStatus(), "ready");
  S.addClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 660);
  S.subClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 600);
  S.subClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 540);
  S.setClockMinutes(1);
  c = S.getClock();
  c.remainingSec = 30;
  S.save();
  S.subClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 0);
  S.subClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 0);
  c.remainingSec = 0;
  c.timerRunning = false;
  S.save();
  assert.strictEqual(S.clockStatus(), "finished");
  S.resetClock();
  assert.strictEqual(S.getClock().remainingSec, 60);
  S.setClockMinutes(10);
  S.startClock();
  var beforeEnd = S.getClock().endAt;
  S.addClockSeconds(10);
  assert.ok(S.getClock().endAt >= beforeEnd + 9000);
  assert.ok(S.remainingClockNow() >= 605);
  S.subClockSeconds(10);
  assert.ok(S.remainingClockNow() <= 605);
  S.pauseClock();
  var pausedSec = S.getClock().remainingSec;
  S.addClockSeconds(10);
  assert.strictEqual(S.getClock().remainingSec, pausedSec + 10);
  S.subClockSeconds(10);
  assert.strictEqual(S.getClock().remainingSec, pausedSec);
  S.resetClock();
  S.setClockMinutes(1);
  c = S.getClock();
  c.remainingSec = 5;
  S.save();
  S.subClockSeconds(10);
  assert.strictEqual(S.getClock().remainingSec, 0);
});

test("fonte da tela Relogio mostra INICIAR e RESETAR sem checar admin", function () {
  var app = fs.readFileSync(path.join(__dirname, "../js/app.js"), "utf8");
  var css = fs.readFileSync(path.join(__dirname, "../css/styles.css"), "utf8");
  var cloud = fs.readFileSync(path.join(__dirname, "../js/cloud.js"), "utf8");
  var schema = fs.readFileSync(path.join(__dirname, "../supabase/schema.sql"), "utf8");
  var html = fs.readFileSync(path.join(__dirname, "../index.html"), "utf8");
  var start = app.indexOf("function clubClockCardHtml");
  var end = app.indexOf("function renderStandaloneClock");
  var card = app.slice(start, end);
  assert.ok(card.indexOf('id="tmStart"') >= 0);
  assert.ok(card.indexOf('id="tmPause"') >= 0);
  assert.ok(card.indexOf('id="tmReset"') >= 0);
  assert.ok(card.indexOf('id="tmPlus"') >= 0);
  assert.ok(card.indexOf('id="tmMinus"') >= 0);
  assert.ok(card.indexOf('id="tmPlus10"') >= 0);
  assert.ok(card.indexOf('id="tmMinus10"') >= 0);
  assert.ok(card.indexOf('id="tmMinutes"') >= 0);
  assert.ok(card.indexOf('id="tmApply"') >= 0);
  assert.ok(card.indexOf("INICIAR") >= 0);
  assert.ok(card.indexOf("PAUSAR") >= 0);
  assert.ok(card.indexOf("RESET") >= 0);
  assert.ok(card.indexOf("APLICAR") >= 0);
  assert.ok(card.indexOf("+1 MIN") >= 0);
  assert.ok(card.indexOf("-1 MIN") >= 0);
  assert.ok(card.indexOf("+10 SEG") >= 0);
  assert.ok(card.indexOf("-10 SEG") >= 0);
  assert.ok(card.indexOf("isAdmin") < 0);
  assert.ok(app.indexOf("S.setClockMinutes") >= 0);
  assert.ok(app.indexOf("applyClockMinutesFromInput") >= 0);
  assert.ok(app.indexOf("bindClockControls();") >= 0);
  assert.ok(app.indexOf("if (isAdmin()) bindClockControls") < 0);
  assert.ok(app.indexOf("function enterPresent") >= 0);
  assert.ok(app.indexOf("function playBip") >= 0);
  assert.ok(app.indexOf("function playFinalBip") >= 0);
  assert.ok(app.indexOf("function speakNextSlide") >= 0);
  assert.ok(app.indexOf("function lockLandscape") >= 0);
  assert.ok(app.indexOf("lock(\"landscape\")") >= 0);
  assert.ok(app.indexOf("requestFullscreen") >= 0);
  assert.ok(app.indexOf("Próximo slide") >= 0);
  assert.ok(app.indexOf("beepCycleId") >= 0);
  assert.ok(app.indexOf("is-flash") >= 0);
  assert.ok(app.indexOf("if (presentMode) enterPresent") >= 0);
  var startFn = app.slice(app.indexOf("function startClubClockFromClick"), app.indexOf("function resetClubClockFromClick"));
  assert.ok(startFn.indexOf("unlockAudio") >= 0);
  assert.ok(startFn.indexOf("S.startClock") >= 0);
  assert.ok(startFn.indexOf("toast(") < 0);
  assert.ok(app.indexOf("clubClockCardHtml()") >= 0);
  assert.ok(app.indexOf("bindClockControls();") >= 0);
  assert.ok(html.indexOf("presentStage") >= 0);
  assert.ok(html.indexOf("presentExit") >= 0);
  assert.ok(html.indexOf("presentAudioHint") >= 0);
  assert.ok(html.indexOf("presentPlus") >= 0);
  assert.ok(html.indexOf("presentMinus") >= 0);
  assert.ok(html.indexOf("presentPlus10") >= 0);
  assert.ok(html.indexOf("presentMinus10") >= 0);
  assert.ok(html.indexOf("presentStart") >= 0);
  assert.ok(html.indexOf("presentPause") >= 0);
  assert.ok(html.indexOf("presentMinutes") >= 0);
  assert.ok(html.indexOf("presentApply") >= 0);
  assert.ok(css.indexOf(".present-controls") >= 0);
  assert.ok(css.indexOf(".present-stage") >= 0);
  assert.ok(css.indexOf("body.clock-present #app") >= 0);
  assert.ok(css.indexOf(".clock-controls") >= 0);
  assert.ok(css.indexOf(".clock-adjust-grid") >= 0);
  assert.ok(css.indexOf(".clock-minutes-row") >= 0);
  assert.ok(css.indexOf("presentFlash") >= 0);
  assert.ok(css.indexOf("@media (orientation: landscape)") >= 0);
  assert.ok(css.indexOf("42vmin") >= 0);
  assert.ok(cloud.indexOf("set_club_clock") >= 0);
  assert.ok(cloud.indexOf("p_start_at") >= 0);
  assert.ok(cloud.indexOf("p_end_at") >= 0);
  assert.ok(cloud.indexOf("p_cycle_id") >= 0);
  assert.ok(cloud.indexOf("syncNow: syncNow") >= 0);
  assert.ok(schema.indexOf("set_club_clock") >= 0);
  assert.ok(schema.indexOf("p_start_at") >= 0);
  assert.ok(schema.indexOf("p_end_at") >= 0);
  assert.ok(schema.indexOf("p_cycle_id") >= 0);
});

test("jogadores nao vêm do localStorage e cadastro exige nuvem", function () {
  var app = fs.readFileSync(path.join(__dirname, "../js/app.js"), "utf8");
  var cloud = fs.readFileSync(path.join(__dirname, "../js/cloud.js"), "utf8");
  var store = fs.readFileSync(path.join(__dirname, "../js/store.js"), "utf8");
  var sw = fs.readFileSync(path.join(__dirname, "../sw.js"), "utf8");
  assert.ok(cloud.indexOf('.from("players").select("*")') >= 0);
  assert.ok(cloud.indexOf('.eq("club_id", CLUB_ID)') >= 0);
  assert.ok(cloud.indexOf('var CLUB_ID = "pokerclub"') >= 0);
  assert.ok(cloud.indexOf("upsertPlayer") >= 0);
  assert.ok(cloud.indexOf("replacePlayers(rows)") >= 0);
  assert.ok(app.indexOf("PokerCloud.upsertPlayer(next)") >= 0);
  assert.ok(app.indexOf("PokerCloud.fetchPlayers()") >= 0);
  assert.ok(app.indexOf("S.replacePlayers(rows)") >= 0);
  assert.ok(app.indexOf("console.error(\"Falha ao gravar jogador no Supabase\"") >= 0);
  assert.ok(app.indexOf("supabaseErrorText") >= 0);
  assert.ok(app.indexOf("SUPABASE ERROR") >= 0);
  assert.ok(cloud.indexOf("formatCloudError") >= 0);
  assert.ok(cloud.indexOf("configMissingError") >= 0);
  assert.ok(cloud.indexOf("SELECT public.players") >= 0);
  assert.ok(cloud.indexOf("UPSERT public.players") >= 0);
  var writeCfg = fs.readFileSync(path.join(__dirname, "../scripts/write-config.js"), "utf8");
  assert.ok(writeCfg.indexOf("process.exit(1)") >= 0);
  assert.ok(writeCfg.indexOf("BUILD FAIL") >= 0);
  var loadFn = store.slice(store.indexOf("function load()"), store.indexOf("function publicUser"));
  assert.ok(loadFn.indexOf("players: []") >= 0);
  assert.ok(loadFn.indexOf("data.players") < 0);
  assert.ok(sw.indexOf("pokerclub-v31") >= 0);
  var fn = fs.readFileSync(path.join(__dirname, "../netlify/functions/supabase-config.js"), "utf8");
  assert.ok(fn.indexOf("USER_SUPABASE_URL") >= 0);
  assert.ok(fn.indexOf("USER_SUPABASE_ANON_KEY") >= 0);
  assert.ok(fn.indexOf("service_role") >= 0);
  var cfgJs = fs.readFileSync(path.join(__dirname, "../js/supabase-config.js"), "utf8");
  assert.ok(cfgJs.indexOf("__pokerSupabaseConfigPromise") >= 0);
  assert.ok(cfgJs.indexOf("/.netlify/functions/supabase-config") >= 0);
  assert.ok(sw.indexOf("networkFirst") >= 0);
  assert.ok(sw.indexOf("/.netlify/functions/") >= 0);
  assert.ok(cloud.indexOf("isConfigPending") >= 0);
  assert.ok(cloud.indexOf("configPending") >= 0);
  assert.ok(app.indexOf("ensureCloud") >= 0);
  assert.ok(app.indexOf("USER_SUPABASE_URL") >= 0);
  assert.ok(app.indexOf("Modo local neste aparelho") < 0);
  assert.ok(cloud.indexOf("return waitConfig().then") >= 0);
  sandbox.localStorage.setItem("pokerclub_v1", JSON.stringify({
    players: [{ id: "local-only", name: "Local Fantasma", nickname: "", phone: "", createdAt: "2026-01-01" }],
    tournaments: [], payments: [], cash: [], users: [], hands: [], seasons: [], clock: null
  }));
  S.load();
  assert.strictEqual(S.state().players.length, 0);
});

test("admin permanece autenticado e relogio persiste apos save/load", function () {
  S.resetAll();
  S.registerUser({ name: "Admin Club", password: "1234" });
  S.login("Admin Club", "1234");
  assert.strictEqual(S.isAdmin(), true);
  S.addClockMinute();
  S.addClockMinute();
  assert.strictEqual(S.getClock().remainingSec, 720);
  S.startClock();
  var raw = sandbox.localStorage.getItem("pokerclub_v1");
  var sess = sandbox.localStorage.getItem("pokerclub_session");
  assert.ok(raw);
  assert.ok(sess);
  var parsed = JSON.parse(raw);
  assert.strictEqual(parsed.clock.timerRunning, true);
  assert.strictEqual(parsed.clock.remainingSec, 720);
  S.logout();
  assert.strictEqual(S.isAdmin(), false);
  S.loadSession();
  assert.strictEqual(S.isAdmin(), false);
  S.login("Admin Club", "1234");
  assert.strictEqual(S.isAdmin(), true);
});

if (fails) {
  console.log("\n" + fails + " teste(s) falharam");
  process.exit(1);
}
console.log("\nTodos os testes passaram");
