window.POKER_FIREBASE_CONFIG = {
  apiKey: "COLE_AQUI",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJETO",
  storageBucket: "SEU_PROJETO.appspot.com",
  messagingSenderId: "",
  appId: "",
  clubId: "pokerclub"
};
