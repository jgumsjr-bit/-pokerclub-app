window.POKER_SUPABASE_CONFIG = {
  url: "https://SEU_PROJETO.supabase.co",
  anonKey: "COLE_A_CHAVE_ANON_PUBLISHABLE",
  clubId: "pokerclub"
};
