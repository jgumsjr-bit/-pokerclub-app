(function (global) {
  var KEY = "pokerclub_v1";
  var DEFAULT_LEVELS = [
    { minutes: 15, small: 25, big: 50, ante: 0 },
    { minutes: 15, small: 50, big: 100, ante: 0 },
    { minutes: 15, small: 75, big: 150, ante: 0 },
    { minutes: 15, small: 100, big: 200, ante: 25 },
    { minutes: 15, small: 150, big: 300, ante: 25 },
    { minutes: 15, small: 200, big: 400, ante: 50 },
    { minutes: 15, small: 300, big: 600, ante: 75 },
    { minutes: 12, small: 400, big: 800, ante: 100 },
    { minutes: 12, small: 500, big: 1000, ante: 100 },
    { minutes: 12, small: 600, big: 1200, ante: 200 },
    { minutes: 12, small: 800, big: 1600, ante: 200 },
    { minutes: 10, small: 1000, big: 2000, ante: 300 }
  ];

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function today() {
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + m + "-" + day;
  }

  function nowTime() {
    var d = new Date();
    return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  }

  function clone(v) {
    return JSON.parse(JSON.stringify(v));
  }

  function emptyClock() {
    return {
      remainingSec: 600,
      durationSec: 600,
      timerRunning: false,
      timerUpdatedAt: null,
      paused: false,
      startAt: null,
      endAt: null,
      cycleId: "",
      status: "ready"
    };
  }

  function normalizeClock(c) {
    if (!c) return emptyClock();
    var duration = Math.max(1, Number(c.durationSec) || 600);
    var remaining = c.remainingSec == null ? duration : Math.max(0, Number(c.remainingSec) || 0);
    var endAt = c.endAt == null ? null : Number(c.endAt);
    var startAt = c.startAt == null ? null : Number(c.startAt);
    var running = !!c.timerRunning;
    return {
      remainingSec: remaining,
      durationSec: duration,
      timerRunning: running,
      timerUpdatedAt: c.timerUpdatedAt || startAt || null,
      paused: !!c.paused && !running,
      startAt: startAt,
      endAt: endAt,
      cycleId: c.cycleId || "",
      status: c.status || (running ? "running" : (c.paused ? "paused" : "ready"))
    };
  }

  function emptyState() {
    return { players: [], tournaments: [], payments: [], cash: [], users: [], hands: [], seasons: [], clock: emptyClock() };
  }

  var memory = emptyState();
  var storage = null;
  var sessionUser = null;
  var applyingRemote = false;
  var SESSION_KEY = "pokerclub_session";
  var onChange = [];

  function getStorage() {
    if (storage) return storage;
    try {
      if (typeof localStorage !== "undefined") {
        storage = localStorage;
        return storage;
      }
    } catch (e) {}
    var mem = {};
    storage = {
      getItem: function (k) { return mem[k] == null ? null : mem[k]; },
      setItem: function (k, v) { mem[k] = String(v); },
      removeItem: function (k) { delete mem[k]; }
    };
    return storage;
  }

  function cloudLive() {
    try {
      if (global.POKER_SUPABASE_CONFIG && global.POKER_SUPABASE_CONFIG.url && global.POKER_SUPABASE_CONFIG.anonKey) return true;
    } catch (e) {}
    try {
      var raw = getStorage().getItem("pokerclub_supabase_cfg");
      if (!raw) return false;
      var cfg = JSON.parse(raw);
      return !!(cfg && cfg.url && cfg.anonKey);
    } catch (e) {
      return false;
    }
  }

  function load() {
    try {
      var raw = getStorage().getItem(KEY);
      if (!raw) {
        memory = emptyState();
        return memory;
      }
      var data = JSON.parse(raw);
      memory = {
        players: [],
        tournaments: data.tournaments || [],
        payments: data.payments || [],
        cash: data.cash || [],
        users: (data.users || []).map(function (u) {
          return {
            id: u.id,
            email: u.email || "",
            name: u.name || "",
            role: u.role === "admin" ? "admin" : "player",
            playerId: u.playerId || "",
            passHash: u.passHash || "",
            createdAt: u.createdAt || ""
          };
        }),
        hands: data.hands || [],
        seasons: data.seasons || [],
        clock: normalizeClock(data.clock)
      };
    } catch (e) {
      memory = emptyState();
    }
    return memory;
  }

  function publicUser(u) {
    if (!u) return u;
    return {
      id: u.id,
      email: u.email || "",
      name: u.name || "",
      role: u.role === "admin" ? "admin" : "player",
      playerId: u.playerId || "",
      createdAt: u.createdAt || ""
    };
  }

  function persistable() {
    return {
      players: cloudLive() ? [] : (memory.players || []),
      tournaments: memory.tournaments || [],
      payments: memory.payments || [],
      cash: memory.cash || [],
      users: (memory.users || []).map(publicUser),
      hands: memory.hands || [],
      seasons: memory.seasons || [],
      clock: memory.clock || emptyClock()
    };
  }

  function save() {
    var data = persistable();
    if (cloudLive()) data.players = [];
    if (!cloudLive()) {
      getStorage().setItem(KEY, JSON.stringify(data));
    } else {
      try {
        var raw = getStorage().getItem(KEY);
        var prev = raw ? JSON.parse(raw) : {};
        prev.players = [];
        prev.tournaments = data.tournaments;
        prev.payments = data.payments;
        prev.cash = data.cash;
        prev.users = data.users;
        prev.hands = data.hands;
        prev.seasons = data.seasons;
        prev.clock = data.clock;
        getStorage().setItem(KEY, JSON.stringify(prev));
      } catch (e) {}
    }
    if (!applyingRemote) {
      try {
        if (typeof PokerCloud !== "undefined" && PokerCloud.schedulePush) PokerCloud.schedulePush(memory);
      } catch (e) {}
      onChange.forEach(function (fn) { try { fn(); } catch (e) {} });
    }
    return memory;
  }

  function state() {
    return memory;
  }

  function resetAll() {
    memory = emptyState();
    save();
    return memory;
  }

  function exportData() {
    return JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), data: persistable() }, null, 2);
  }

  function importData(json) {
    var parsed = typeof json === "string" ? JSON.parse(json) : json;
    var data = parsed.data || parsed;
    if (!data || !Array.isArray(data.players) || !Array.isArray(data.tournaments)) {
      throw new Error("Arquivo de backup invalido");
    }
    memory = {
      players: data.players || [],
      tournaments: data.tournaments || [],
      payments: data.payments || [],
      cash: data.cash || [],
      users: (data.users || []).map(publicUser),
      hands: data.hands || [],
      seasons: data.seasons || [],
      clock: normalizeClock(data.clock)
    };
    save();
    return memory;
  }

  function normalizeName(s) {
    return String(s || "").trim();
  }

  function addPlayer(input) {
    var name = normalizeName(input.name);
    if (!name) throw new Error("Informe o nome completo");
    var player = {
      id: uid(),
      name: name,
      nickname: normalizeName(input.nickname),
      phone: normalizeName(input.phone),
      createdAt: input.createdAt || today()
    };
    if (!cloudLive()) {
      memory.players.unshift(player);
      save();
    }
    return player;
  }

  function updatePlayer(id, input) {
    var p = memory.players.find(function (x) { return x.id === id; });
    if (!p) throw new Error("Jogador nao encontrado");
    var name = normalizeName(input.name);
    if (!name) throw new Error("Informe o nome completo");
    var next = {
      id: p.id,
      name: name,
      nickname: normalizeName(input.nickname),
      phone: normalizeName(input.phone),
      createdAt: input.createdAt || p.createdAt
    };
    if (!cloudLive()) {
      p.name = next.name;
      p.nickname = next.nickname;
      p.phone = next.phone;
      p.createdAt = next.createdAt;
      save();
      return p;
    }
    return next;
  }

  function deletePlayer(id) {
    if (!cloudLive()) {
      memory.players = memory.players.filter(function (x) { return x.id !== id; });
      save();
    }
    return true;
  }

  function getPlayer(id) {
    return memory.players.find(function (x) { return x.id === id; }) || null;
  }

  function displayName(player) {
    if (!player) return "Jogador removido";
    return player.nickname ? player.name + " (" + player.nickname + ")" : player.name;
  }

  function playerTournamentsCount(playerId) {
    return memory.tournaments.filter(function (t) {
      return (t.entries || []).some(function (e) { return e.playerId === playerId; });
    }).length;
  }

  function searchPlayers(q) {
    var s = String(q || "").trim().toLowerCase();
    var list = memory.players.slice();
    if (!s) return list;
    return list.filter(function (p) {
      return (p.name + " " + p.nickname + " " + p.phone).toLowerCase().indexOf(s) !== -1;
    });
  }

  function addTournament(input) {
    var name = normalizeName(input.name);
    if (!name) throw new Error("Informe o nome do torneio");
    var buyIn = Number(input.buyIn);
    if (!(buyIn >= 0)) throw new Error("Valor da inscricao invalido");
    var levels = (input.levels && input.levels.length) ? clone(input.levels) : clone(DEFAULT_LEVELS);
    var t = {
      id: uid(),
      name: name,
      date: input.date || today(),
      time: input.time || nowTime(),
      buyIn: buyIn,
      status: "upcoming",
      entries: [],
      levels: levels,
      currentLevel: 0,
      remainingSec: (levels[0] ? levels[0].minutes : 15) * 60,
      timerRunning: false,
      timerUpdatedAt: null,
      roundEnded: false,
      roundEndedAt: null,
      emergencyStarted: false,
      emergencyStartedBy: "",
      emergencyStartedById: "",
      emergencyStartedAt: null,
      championId: null,
      finishedAt: null
    };
    memory.tournaments.unshift(t);
    save();
    return t;
  }

  function updateTournament(id, input) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    if (input.name != null) {
      var name = normalizeName(input.name);
      if (!name) throw new Error("Informe o nome do torneio");
      t.name = name;
    }
    if (input.date != null) t.date = input.date;
    if (input.time != null) t.time = input.time;
    if (input.buyIn != null) {
      var buyIn = Number(input.buyIn);
      if (!(buyIn >= 0)) throw new Error("Valor da inscricao invalido");
      t.buyIn = buyIn;
    }
    if (input.levels) t.levels = clone(input.levels);
    save();
    return t;
  }

  function deleteTournament(id) {
    memory.tournaments = memory.tournaments.filter(function (x) { return x.id !== id; });
    memory.payments = memory.payments.filter(function (p) { return p.tournamentId !== id; });
    save();
    return true;
  }

  function getTournament(id) {
    return memory.tournaments.find(function (x) { return x.id === id; }) || null;
  }

  function setTournamentPlayers(id, playerIds) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    var keep = {};
    (t.entries || []).forEach(function (e) { keep[e.playerId] = e; });
    t.entries = (playerIds || []).map(function (pid) {
      if (keep[pid]) return keep[pid];
      var p = getPlayer(pid);
      return {
        playerId: pid,
        nameSnapshot: p ? p.name : "Jogador",
        nickSnapshot: p ? p.nickname : "",
        paid: false,
        paidAmount: 0,
        paidAt: null,
        eliminated: false,
        position: null
      };
    });
    save();
    return t;
  }

  function registerPayment(tournamentId, playerId, amount) {
    var t = getTournament(tournamentId);
    if (!t) throw new Error("Torneio nao encontrado");
    var e = (t.entries || []).find(function (x) { return x.playerId === playerId; });
    if (!e) throw new Error("Jogador nao esta no torneio");
    var val = Number(amount);
    if (!(val >= 0)) throw new Error("Valor invalido");
    e.paidAmount = val;
    e.paid = val >= Number(t.buyIn || 0);
    e.paidAt = today();
    memory.payments.unshift({
      id: uid(),
      playerId: playerId,
      tournamentId: tournamentId,
      amount: val,
      date: today(),
      status: e.paid ? "pago" : "pendente"
    });
    save();
    return e;
  }

  function markPending(tournamentId, playerId) {
    var t = getTournament(tournamentId);
    var e = t && (t.entries || []).find(function (x) { return x.playerId === playerId; });
    if (!e) throw new Error("Inscricao nao encontrada");
    e.paid = false;
    e.paidAmount = 0;
    e.paidAt = null;
    memory.payments.unshift({
      id: uid(),
      playerId: playerId,
      tournamentId: tournamentId,
      amount: 0,
      date: today(),
      status: "pendente"
    });
    save();
    return e;
  }

  function collected(t) {
    return (t.entries || []).reduce(function (s, e) { return s + Number(e.paidAmount || 0); }, 0);
  }

  function activeCount(t) {
    return (t.entries || []).filter(function (e) { return !e.eliminated; }).length;
  }

  function startTournament(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    if (!(t.entries || []).length) throw new Error("Adicione jogadores antes de iniciar");
    t.status = "live";
    if (!t.remainingSec) t.remainingSec = (t.levels[t.currentLevel] || t.levels[0]).minutes * 60;
    save();
    return t;
  }

  function eliminatePlayer(tournamentId, playerId) {
    var t = getTournament(tournamentId);
    if (!t) throw new Error("Torneio nao encontrado");
    var e = (t.entries || []).find(function (x) { return x.playerId === playerId; });
    if (!e) throw new Error("Jogador nao encontrado");
    if (e.eliminated) return t;
    var remaining = (t.entries || []).filter(function (x) { return !x.eliminated; });
    e.eliminated = true;
    e.position = remaining.length;
    var left = (t.entries || []).filter(function (x) { return !x.eliminated; });
    if (left.length === 1) {
      left[0].position = 1;
      t.championId = left[0].playerId;
      t.status = "finished";
      t.timerRunning = false;
      t.finishedAt = today();
    } else if (left.length === 0) {
      t.status = "finished";
      t.timerRunning = false;
      t.finishedAt = today();
    }
    save();
    return t;
  }

  function undoEliminate(tournamentId, playerId) {
    var t = getTournament(tournamentId);
    var e = t && (t.entries || []).find(function (x) { return x.playerId === playerId; });
    if (!e) throw new Error("Jogador nao encontrado");
    e.eliminated = false;
    e.position = null;
    if (t.championId === playerId) t.championId = null;
    if (t.status === "finished") t.status = "live";
    t.finishedAt = null;
    save();
    return t;
  }

  function setChampion(tournamentId, playerId) {
    var t = getTournament(tournamentId);
    if (!t) throw new Error("Torneio nao encontrado");
    (t.entries || []).forEach(function (e) {
      if (e.playerId === playerId) {
        e.eliminated = false;
        e.position = 1;
      } else if (!e.eliminated) {
        e.eliminated = true;
        if (!e.position) e.position = 2;
      }
    });
    t.championId = playerId;
    t.status = "finished";
    t.timerRunning = false;
    t.finishedAt = today();
    save();
    return t;
  }

  function setLevels(id, levels) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    if (!levels || !levels.length) throw new Error("Informe ao menos uma rodada");
    t.levels = levels.map(function (l) {
      return {
        minutes: Math.max(1, Number(l.minutes) || 15),
        small: Math.max(0, Number(l.small) || 0),
        big: Math.max(0, Number(l.big) || 0),
        ante: Math.max(0, Number(l.ante) || 0)
      };
    });
    if (t.currentLevel >= t.levels.length) t.currentLevel = t.levels.length - 1;
    if (!t.timerRunning) t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    save();
    return t;
  }

  function tickTimer(id, nowMs) {
    var t = getTournament(id);
    if (!t || !t.timerRunning) return t;
    var now = nowMs || Date.now();
    var sec = remainingNow(t, now);
    if (sec > 0) return t;
    t.remainingSec = 0;
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    t.roundEnded = true;
    t.roundEndedAt = t.roundEndedAt || now;
    save();
    return t;
  }

  function remainingNow(t, nowMs) {
    if (!t) return 0;
    var sec = Number(t.remainingSec || 0);
    if (t.timerRunning && t.timerUpdatedAt) {
      var delta = Math.floor(((nowMs || Date.now()) - t.timerUpdatedAt) / 1000);
      if (delta > 0) sec = Math.max(0, sec - delta);
    }
    return sec;
  }

  function clearEmergency(t) {
    t.emergencyStarted = false;
    t.emergencyStartedBy = "";
    t.emergencyStartedById = "";
    t.emergencyStartedAt = null;
  }

  function markEmergency(t) {
    var sess = sessionUser;
    t.emergencyStarted = true;
    t.emergencyStartedBy = sess ? (sess.name || sess.email || "Jogador") : "Jogador";
    t.emergencyStartedById = sess ? (sess.id || "") : "";
    t.emergencyStartedAt = Date.now();
  }

  function getClock() {
    if (!memory.clock) memory.clock = emptyClock();
    return memory.clock;
  }

  function remainingClockNow(nowMs) {
    var c = getClock();
    var now = nowMs || Date.now();
    if (c.timerRunning && c.endAt) {
      return Math.max(0, Math.ceil((Number(c.endAt) - now) / 1000));
    }
    var sec = Number(c.remainingSec || 0);
    if (c.timerRunning && c.timerUpdatedAt) {
      var delta = Math.floor((now - Number(c.timerUpdatedAt)) / 1000);
      if (delta > 0) sec = Math.max(0, sec - delta);
    }
    return sec;
  }

  function clockStatus(nowMs) {
    var c = getClock();
    var sec = remainingClockNow(nowMs);
    if (c.timerRunning && sec <= 0) return "finished";
    if (sec <= 0 && !c.timerRunning && !c.paused && Number(c.remainingSec) === 0) return "finished";
    if (c.timerRunning) return "running";
    if (c.paused) return "paused";
    return "ready";
  }

  function tickClock(nowMs) {
    var c = getClock();
    if (!c.timerRunning) return c;
    var now = nowMs || Date.now();
    var sec = remainingClockNow(now);
    if (sec > 0) return c;
    c.remainingSec = 0;
    c.timerRunning = false;
    c.timerUpdatedAt = null;
    c.paused = false;
    c.status = "finished";
    c.endAt = c.endAt || now;
    save();
    return c;
  }

  function setClockMinutes(minutes) {
    var mins = Number(minutes);
    if (!(mins > 0) || mins !== Math.floor(mins)) throw new Error("Informe os minutos");
    if (mins > 180) throw new Error("Informe no maximo 180 minutos");
    var c = getClock();
    c.durationSec = mins * 60;
    c.remainingSec = mins * 60;
    c.timerRunning = false;
    c.timerUpdatedAt = null;
    c.paused = false;
    c.startAt = null;
    c.endAt = null;
    c.cycleId = "";
    c.status = "ready";
    save();
    return c;
  }

  function startClock() {
    var c = getClock();
    var now = Date.now();
    var sec = remainingClockNow(now);
    if (sec <= 0) sec = c.durationSec || 600;
    c.remainingSec = sec;
    c.durationSec = Number(c.durationSec) || sec || 600;
    c.timerRunning = true;
    c.timerUpdatedAt = now;
    c.paused = false;
    c.startAt = now;
    c.endAt = now + sec * 1000;
    c.cycleId = uid();
    c.status = "running";
    save();
    return c;
  }

  function pauseClock() {
    var c = getClock();
    var now = Date.now();
    c.remainingSec = remainingClockNow(now);
    c.timerRunning = false;
    c.timerUpdatedAt = null;
    c.paused = c.remainingSec > 0;
    c.endAt = null;
    c.startAt = null;
    c.status = c.paused ? "paused" : "finished";
    save();
    return c;
  }

  function adjustClockSeconds(deltaSec) {
    var step = Math.round(Number(deltaSec) || 0);
    if (!step) return getClock();
    var c = getClock();
    var now = Date.now();
    var sec = remainingClockNow(now);
    sec = Math.max(0, sec + step);
    if (sec > 180 * 60) sec = 180 * 60;
    c.remainingSec = sec;
    if (sec <= 0) {
      c.timerRunning = false;
      c.timerUpdatedAt = null;
      c.paused = false;
      c.startAt = null;
      c.endAt = now;
      c.status = "finished";
    } else if (c.timerRunning) {
      c.timerUpdatedAt = now;
      c.startAt = now;
      c.endAt = now + sec * 1000;
      c.paused = false;
      c.status = "running";
    } else if (c.paused) {
      c.timerUpdatedAt = null;
      c.startAt = null;
      c.endAt = null;
      c.status = "paused";
    } else {
      c.durationSec = Math.max(1, sec);
      c.timerUpdatedAt = null;
      c.startAt = null;
      c.endAt = null;
      c.paused = false;
      c.status = "ready";
    }
    save();
    return c;
  }

  function adjustClockMinutes(delta) {
    return adjustClockSeconds(Math.round(Number(delta) || 0) * 60);
  }

  function addClockMinute() {
    return adjustClockSeconds(60);
  }

  function subClockMinute() {
    return adjustClockSeconds(-60);
  }

  function addClockSeconds(n) {
    return adjustClockSeconds(n == null ? 10 : n);
  }

  function subClockSeconds(n) {
    return adjustClockSeconds(-(n == null ? 10 : n));
  }

  function resetClock() {
    var c = getClock();
    var dur = Math.max(1, Number(c.durationSec) || 600);
    c.timerRunning = false;
    c.timerUpdatedAt = null;
    c.paused = false;
    c.durationSec = dur;
    c.remainingSec = dur;
    c.startAt = null;
    c.endAt = null;
    c.cycleId = "";
    c.status = "ready";
    save();
    return c;
  }

  function startTimer(id, opts) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    var emergency = !!(opts && opts.emergency);
    if (t.status === "finished") throw new Error("Torneio encerrado");
    if (t.status === "upcoming") {
      if ((t.entries || []).length) startTournament(id);
      else t.status = "live";
    }
    t = getTournament(id);
    t.roundEnded = false;
    t.roundEndedAt = null;
    t.timerRunning = true;
    t.timerUpdatedAt = Date.now();
    if (t.remainingSec == null || t.remainingSec <= 0) t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    if (emergency) markEmergency(t);
    else clearEmergency(t);
    save();
    return t;
  }

  function emergencyStartTimer(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    if (t.status === "finished") throw new Error("Torneio encerrado");
    if (t.timerRunning) throw new Error("O cronometro ja esta em andamento");
    if (t.roundEnded) throw new Error("Apenas o admin pode iniciar a proxima rodada");
    return startTimer(id, { emergency: true });
  }

  function setTimerMinutes(id, minutes) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    var mins = Number(minutes);
    if (!(mins > 0) || mins !== Math.floor(mins)) throw new Error("Informe os minutos");
    if (mins > 180) throw new Error("Informe no maximo 180 minutos");
    var small = t.levels[t.currentLevel] && t.levels[t.currentLevel].small;
    var big = t.levels[t.currentLevel] && t.levels[t.currentLevel].big;
    var ante = t.levels[t.currentLevel] && t.levels[t.currentLevel].ante;
    t.remainingSec = mins * 60;
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    t.roundEnded = false;
    t.roundEndedAt = null;
    if (t.levels[t.currentLevel]) {
      t.levels[t.currentLevel].small = small;
      t.levels[t.currentLevel].big = big;
      t.levels[t.currentLevel].ante = ante;
    }
    save();
    return t;
  }

  function pauseTimer(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    t.remainingSec = remainingNow(t);
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    save();
    return t;
  }

  function resetTimer(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    t.roundEnded = false;
    t.roundEndedAt = null;
    t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    clearEmergency(t);
    save();
    return t;
  }

  function ackRoundEnd(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    t.roundEnded = false;
    t.roundEndedAt = null;
    save();
    return t;
  }

  function confirmNextRound(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    t.roundEnded = false;
    t.roundEndedAt = null;
    if (t.currentLevel < t.levels.length - 1) t.currentLevel += 1;
    t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    t.timerRunning = true;
    t.timerUpdatedAt = Date.now();
    save();
    return t;
  }

  function nextLevel(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    t.roundEnded = false;
    t.roundEndedAt = null;
    if (t.currentLevel < t.levels.length - 1) t.currentLevel += 1;
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    save();
    return t;
  }

  function prevLevel(id) {
    var t = getTournament(id);
    if (!t) throw new Error("Torneio nao encontrado");
    if (t.currentLevel > 0) t.currentLevel -= 1;
    t.timerRunning = false;
    t.timerUpdatedAt = null;
    t.roundEnded = false;
    t.roundEndedAt = null;
    t.remainingSec = t.levels[t.currentLevel].minutes * 60;
    save();
    return t;
  }

  function liveTournament() {
    return memory.tournaments.find(function (t) { return t.status === "live"; }) || null;
  }

  function nextTournament() {
    var now = today();
    var upcoming = memory.tournaments.filter(function (t) { return t.status === "upcoming"; });
    upcoming.sort(function (a, b) {
      return String(a.date + a.time).localeCompare(String(b.date + b.time));
    });
    return upcoming.find(function (t) { return t.date >= now; }) || upcoming[0] || null;
  }

  function ranking(t) {
    return (t.entries || []).slice().sort(function (a, b) {
      var pa = a.position || 9999;
      var pb = b.position || 9999;
      if (pa !== pb) return pa - pb;
      if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
      return 0;
    });
  }

  function previewFinish(tournamentId, championId) {
    var t = getTournament(tournamentId);
    if (!t) throw new Error("Torneio nao encontrado");
    var rows = (t.entries || []).map(function (e) {
      var copy = {
        playerId: e.playerId,
        nameSnapshot: e.nameSnapshot,
        position: e.position,
        eliminated: e.eliminated
      };
      if (e.playerId === championId) {
        copy.position = 1;
        copy.eliminated = false;
      } else if (!e.eliminated && !e.position) {
        copy.eliminated = true;
        copy.position = 2;
      }
      return copy;
    }).sort(function (a, b) { return (a.position || 9999) - (b.position || 9999); });
    return rows;
  }

  function champions(year) {
    return memory.tournaments.filter(function (t) {
      if (!t.championId) return false;
      if (!year) return true;
      return String(t.date).slice(0, 4) === String(year);
    }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
  }

  function titlesByPlayer(year) {
    var map = {};
    champions(year).forEach(function (t) {
      map[t.championId] = (map[t.championId] || 0) + 1;
    });
    return Object.keys(map).map(function (pid) {
      return { playerId: pid, player: getPlayer(pid), titles: map[pid] };
    }).sort(function (a, b) { return b.titles - a.titles || displayName(a.player).localeCompare(displayName(b.player)); });
  }

  function playerPayments(playerId) {
    return memory.payments.filter(function (p) { return p.playerId === playerId; });
  }

  function playerPaidTotal(playerId) {
    return memory.tournaments.reduce(function (s, t) {
      var e = (t.entries || []).find(function (x) { return x.playerId === playerId; });
      return s + (e ? Number(e.paidAmount || 0) : 0);
    }, 0);
  }

  function availableYears() {
    var years = {};
    memory.tournaments.forEach(function (t) {
      if (t.date) years[String(t.date).slice(0, 4)] = true;
    });
    (memory.cash || []).forEach(function (c) {
      if (c.date) years[String(c.date).slice(0, 4)] = true;
    });
    (memory.hands || []).forEach(function (h) {
      if (h.date) years[String(h.date).slice(0, 4)] = true;
    });
    (memory.seasons || []).forEach(function (s) {
      if (s.year) years[String(s.year)] = true;
    });
    var list = Object.keys(years).sort().reverse();
    var y = String(new Date().getFullYear());
    if (list.indexOf(y) === -1) list.unshift(y);
    return list;
  }

  var CASH_CATEGORIES_IN = ["inscricao", "rebuy", "addon", "jantar", "outros"];
  var CASH_CATEGORIES_OUT = ["premio", "jantar", "aluguel", "insumos", "outros"];

  function cashLabel(cat) {
    return ({
      inscricao: "Inscrição",
      rebuy: "Rebuy",
      addon: "Addon",
      jantar: "Jantar",
      premio: "Prêmio",
      aluguel: "Aluguel",
      insumos: "Insumos",
      outros: "Outros"
    })[cat] || cat;
  }

  function addCash(input) {
    var type = input.type === "out" ? "out" : "in";
    var amount = Number(input.amount);
    if (!(amount > 0)) throw new Error("Informe um valor maior que zero");
    var desc = normalizeName(input.description);
    if (!desc) throw new Error("Informe a descricao");
    var item = {
      id: uid(),
      type: type,
      amount: amount,
      description: desc,
      category: normalizeName(input.category) || "outros",
      date: input.date || today(),
      tournamentId: input.tournamentId || "",
      playerId: input.playerId || "",
      auto: !!input.auto
    };
    memory.cash = memory.cash || [];
    memory.cash.unshift(item);
    save();
    return item;
  }

  function updateCash(id, input) {
    var item = (memory.cash || []).find(function (x) { return x.id === id; });
    if (!item) throw new Error("Lancamento nao encontrado");
    if (input.amount != null) {
      var amount = Number(input.amount);
      if (!(amount > 0)) throw new Error("Informe um valor maior que zero");
      item.amount = amount;
    }
    if (input.description != null) {
      var desc = normalizeName(input.description);
      if (!desc) throw new Error("Informe a descricao");
      item.description = desc;
    }
    if (input.category != null) item.category = normalizeName(input.category) || "outros";
    if (input.date != null) item.date = input.date;
    if (input.type != null) item.type = input.type === "out" ? "out" : "in";
    if (input.tournamentId != null) item.tournamentId = input.tournamentId;
    if (input.playerId != null) item.playerId = input.playerId;
    save();
    return item;
  }

  function deleteCash(id) {
    memory.cash = (memory.cash || []).filter(function (x) { return x.id !== id; });
    save();
    return true;
  }

  function getCash(id) {
    return (memory.cash || []).find(function (x) { return x.id === id; }) || null;
  }

  function tournamentBuyInTotal(t) {
    return (t.entries || []).reduce(function (s, e) { return s + Number(e.paidAmount || 0); }, 0);
  }

  function cashEntries() {
    var list = (memory.cash || []).slice();
    memory.tournaments.forEach(function (t) {
      (t.entries || []).forEach(function (e) {
        var val = Number(e.paidAmount || 0);
        if (!(val > 0)) return;
        list.push({
          id: "auto-" + t.id + "-" + e.playerId,
          type: "in",
          amount: val,
          description: "Inscrição " + (getPlayer(e.playerId) ? getPlayer(e.playerId).name : e.nameSnapshot),
          category: "inscricao",
          date: e.paidAt || t.date,
          tournamentId: t.id,
          playerId: e.playerId,
          auto: true
        });
      });
    });
    list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
    return list;
  }

  function inPeriod(date, year, month) {
    if (!date) return false;
    if (year && String(date).slice(0, 4) !== String(year)) return false;
    if (month) {
      var mm = String(month).padStart(2, "0");
      if (String(date).slice(5, 7) !== mm) return false;
    }
    return true;
  }

  function cashTotals(year, month) {
    var entries = cashEntries().filter(function (c) { return inPeriod(c.date, year, month); });
    var income = 0;
    var expense = 0;
    entries.forEach(function (c) {
      if (c.type === "out") expense += Number(c.amount || 0);
      else income += Number(c.amount || 0);
    });
    return { income: income, expense: expense, balance: income - expense, count: entries.length };
  }

  function cashByCategory(year, month) {
    var map = {};
    cashEntries().filter(function (c) { return inPeriod(c.date, year, month); }).forEach(function (c) {
      var key = c.type + ":" + (c.category || "outros");
      if (!map[key]) map[key] = { type: c.type, category: c.category || "outros", total: 0 };
      map[key].total += Number(c.amount || 0);
    });
    return Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return b.total - a.total; });
  }

  function monthlyReport(year) {
    var months = [];
    for (var m = 1; m <= 12; m++) {
      var mm = String(m).padStart(2, "0");
      var t = cashTotals(year, mm);
      t.month = mm;
      months.push(t);
    }
    return months;
  }

  function yearlyReport() {
    return availableYears().map(function (y) {
      var t = cashTotals(y);
      t.year = y;
      return t;
    });
  }

  var HAND_TYPES = [
    { id: "royal", label: "Royal Flush", points: 10 },
    { id: "straightflush", label: "Straight Flush", points: 7 },
    { id: "quads", label: "Quadra", points: 4 },
    { id: "award", label: "Premia", points: 2 }
  ];

  function handType(id) {
    return HAND_TYPES.find(function (h) { return h.id === id; }) || null;
  }

  function addHand(input) {
    var type = handType(input.type);
    if (!type) throw new Error("Informe o tipo da mão");
    if (!input.playerId) throw new Error("Informe o jogador");
    var player = getPlayer(input.playerId);
    if (!player) throw new Error("Jogador nao encontrado");
    var item = {
      id: uid(),
      type: type.id,
      label: type.label,
      points: type.points,
      playerId: input.playerId,
      tournamentId: input.tournamentId || "",
      date: input.date || today(),
      note: normalizeName(input.note)
    };
    memory.hands = memory.hands || [];
    memory.hands.unshift(item);
    save();
    return item;
  }

  function deleteHand(id) {
    memory.hands = (memory.hands || []).filter(function (x) { return x.id !== id; });
    save();
    return true;
  }

  function handsByYear(year) {
    return (memory.hands || []).filter(function (h) {
      return !year || String(h.date).slice(0, 4) === String(year);
    });
  }

  function cashPotRanking(year) {
    var map = {};
    handsByYear(year).forEach(function (h) {
      if (!map[h.playerId]) map[h.playerId] = { playerId: h.playerId, player: getPlayer(h.playerId), points: 0, royal: 0, straightflush: 0, quads: 0, award: 0, count: 0 };
      map[h.playerId].points += Number(h.points || 0);
      map[h.playerId].count += 1;
      if (map[h.playerId][h.type] != null) map[h.playerId][h.type] += 1;
    });
    return Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) {
      if (b.points !== a.points) return b.points - a.points;
      if (b.royal !== a.royal) return b.royal - a.royal;
      if (b.straightflush !== a.straightflush) return b.straightflush - a.straightflush;
      if (b.quads !== a.quads) return b.quads - a.quads;
      return displayName(a.player).localeCompare(displayName(b.player));
    });
  }

  function getSeason(year) {
    year = String(year);
    return (memory.seasons || []).find(function (s) { return String(s.year) === year; }) || null;
  }

  function closeSeason(year) {
    year = String(year);
    var rank = cashPotRanking(year);
    if (!rank.length) throw new Error("Nenhuma mão registrada neste ano");
    memory.seasons = memory.seasons || [];
    var existing = getSeason(year);
    var payload = {
      year: year,
      championId: rank[0].playerId,
      points: rank[0].points,
      closedAt: today(),
      ranking: rank.map(function (r) {
        return { playerId: r.playerId, points: r.points, royal: r.royal, straightflush: r.straightflush, quads: r.quads, award: r.award };
      })
    };
    if (existing) {
      existing.championId = payload.championId;
      existing.points = payload.points;
      existing.closedAt = payload.closedAt;
      existing.ranking = payload.ranking;
    } else {
      memory.seasons.unshift(payload);
    }
    save();
    return getSeason(year);
  }

  function reopenSeason(year) {
    memory.seasons = (memory.seasons || []).filter(function (s) { return String(s.year) !== String(year); });
    save();
    return true;
  }

  function hashPass(s) {
    var h = 5381;
    s = String(s || "");
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h) + s.charCodeAt(i);
    return String(h >>> 0);
  }

  function applyRemote(data) {
    applyingRemote = true;
    memory = {
      players: Object.prototype.hasOwnProperty.call(data, "players") && Array.isArray(data.players)
        ? data.players
        : (memory.players || []),
      tournaments: data.tournaments || [],
      payments: data.payments || [],
      cash: data.cash || [],
      users: memory.users || [],
      hands: data.hands || [],
      seasons: data.seasons || [],
      clock: data.clock ? normalizeClock(data.clock) : (memory.clock || emptyClock())
    };
    applyingRemote = false;
    onChange.forEach(function (fn) { try { fn("remote"); } catch (e) {} });
    return memory;
  }

  function replacePlayers(list) {
    applyingRemote = true;
    memory.players = Array.isArray(list) ? list.slice() : [];
    applyingRemote = false;
    onChange.forEach(function (fn) { try { fn("remote"); } catch (e) {} });
    return memory.players;
  }

  function applyPlayerChange(event, player, oldPlayer) {
    var ev = String(event || "").toUpperCase();
    var id = (player && player.id) || (oldPlayer && oldPlayer.id);
    if (!id) return memory;
    applyingRemote = true;
    if (ev === "DELETE" || ev === "REMOVED") {
      memory.players = memory.players.filter(function (x) { return x.id !== id; });
    } else if (player) {
      var i = -1;
      for (var n = 0; n < memory.players.length; n++) {
        if (memory.players[n].id === player.id) { i = n; break; }
      }
      if (i >= 0) memory.players[i] = player;
      else memory.players.unshift(player);
    }
    applyingRemote = false;
    onChange.forEach(function (fn) { try { fn("remote"); } catch (e) {} });
    return memory;
  }

  function subscribe(fn) {
    onChange.push(fn);
    return function () { onChange = onChange.filter(function (x) { return x !== fn; }); };
  }

  function setSession(user) {
    if (!user) {
      sessionUser = null;
      getStorage().removeItem(SESSION_KEY);
      return null;
    }
    sessionUser = {
      id: user.id || "",
      email: user.email || "",
      name: user.name || "",
      role: user.role === "admin" ? "admin" : "player",
      playerId: user.playerId || ""
    };
    getStorage().setItem(SESSION_KEY, JSON.stringify(sessionUser));
    return sessionUser;
  }

  function loadSession() {
    try {
      var raw = getStorage().getItem(SESSION_KEY);
      if (!raw) { sessionUser = null; return null; }
      var s = JSON.parse(raw);
      sessionUser = {
        id: s.id || "",
        email: s.email || "",
        name: s.name || "",
        role: s.role === "admin" ? "admin" : "player",
        playerId: s.playerId || ""
      };
      return sessionUser;
    } catch (e) {
      sessionUser = null;
      return null;
    }
  }

  function session() { return sessionUser; }

  function isAdmin() { return !!(sessionUser && sessionUser.role === "admin"); }

  function canWrite() { return !!(sessionUser && sessionUser.role === "admin"); }

  function users() { return (memory.users || []).map(publicUser); }

  function setUsers(list) {
    memory.users = (list || []).map(publicUser);
    return memory.users;
  }

  function loginKey(s) {
    return normalizeName(s).toLowerCase();
  }

  function findUserByLogin(login) {
    var key = loginKey(login);
    if (!key) return null;
    return (memory.users || []).find(function (u) {
      return loginKey(u.name) === key || loginKey(u.email) === key;
    }) || null;
  }

  function localEmail(name) {
    var slug = loginKey(name).replace(/[^a-z0-9]+/g, ".").replace(/^\.+|\.+$/g, "") || "user";
    return slug + "@pokerclub.app";
  }

  function registerUser(input) {
    memory.users = memory.users || [];
    var name = normalizeName(input.name);
    if (!name) throw new Error("Informe o nome");
    if (!input.password || String(input.password).length < 4) throw new Error("Senha mínima de 4 caracteres");
    if (findUserByLogin(name)) throw new Error("Nome já cadastrado");
    var email = normalizeName(input.email).toLowerCase();
    if (!email || email.indexOf("@") < 1) email = localEmail(name);
    if (memory.users.some(function (u) { return loginKey(u.email) === loginKey(email); })) throw new Error("Nome já cadastrado");
    var role = "player";
    if (!memory.users.length) role = "admin";
    var user = {
      id: uid(),
      email: email,
      name: name,
      role: role,
      playerId: input.playerId || "",
      passHash: hashPass(input.password),
      createdAt: today()
    };
    memory.users.push(user);
    save();
    return publicUser(user);
  }

  function updateUser(id, input) {
    var u = (memory.users || []).find(function (x) { return x.id === id; });
    if (!u) throw new Error("Usuário não encontrado");
    if (input.name != null) u.name = normalizeName(input.name) || u.name;
    if (input.role === "admin" || input.role === "player") u.role = input.role;
    if (input.playerId != null) u.playerId = input.playerId;
    if (input.password && String(input.password).length >= 4) u.passHash = hashPass(input.password);
    save();
    if (sessionUser && sessionUser.id === id) {
      sessionUser.name = u.name;
      sessionUser.role = u.role;
      sessionUser.playerId = u.playerId || "";
      getStorage().setItem(SESSION_KEY, JSON.stringify(sessionUser));
    }
    return publicUser(u);
  }

  function deleteUser(id) {
    if (sessionUser && sessionUser.id === id) throw new Error("Não é possível excluir o usuário logado");
    memory.users = (memory.users || []).filter(function (x) { return x.id !== id; });
    save();
    return true;
  }

  function login(nameOrEmail, password) {
    var user = findUserByLogin(nameOrEmail);
    if (!user) throw new Error("Usuário não encontrado");
    if (!user.passHash || user.passHash !== hashPass(password)) throw new Error("Senha incorreta");
    return setSession({ id: user.id, email: user.email, name: user.name, role: user.role, playerId: user.playerId || "" });
  }

  function logout() {
    sessionUser = null;
    getStorage().removeItem(SESSION_KEY);
  }

  function needsSetup() {
    if (sessionUser) return false;
    return !(memory.users || []).length;
  }

  function formatMoney(n) {
    var v = Number(n || 0);
    return "R$ " + v.toFixed(2).replace(".", ",");
  }

  function formatDate(iso) {
    if (!iso) return "";
    var p = String(iso).split("-");
    if (p.length !== 3) return iso;
    return p[2] + "/" + p[1] + "/" + p[0];
  }

  load();

  global.PokerStore = {
    KEY: KEY,
    DEFAULT_LEVELS: DEFAULT_LEVELS,
    uid: uid,
    today: today,
    nowTime: nowTime,
    load: load,
    save: save,
    state: state,
    resetAll: resetAll,
    exportData: exportData,
    importData: importData,
    addPlayer: addPlayer,
    updatePlayer: updatePlayer,
    deletePlayer: deletePlayer,
    getPlayer: getPlayer,
    displayName: displayName,
    playerTournamentsCount: playerTournamentsCount,
    searchPlayers: searchPlayers,
    addTournament: addTournament,
    updateTournament: updateTournament,
    deleteTournament: deleteTournament,
    getTournament: getTournament,
    setTournamentPlayers: setTournamentPlayers,
    registerPayment: registerPayment,
    markPending: markPending,
    collected: collected,
    activeCount: activeCount,
    startTournament: startTournament,
    eliminatePlayer: eliminatePlayer,
    undoEliminate: undoEliminate,
    setChampion: setChampion,
    setLevels: setLevels,
    tickTimer: tickTimer,
    getClock: getClock,
    tickClock: tickClock,
    setClockMinutes: setClockMinutes,
    startClock: startClock,
    pauseClock: pauseClock,
    resetClock: resetClock,
    adjustClockMinutes: adjustClockMinutes,
    adjustClockSeconds: adjustClockSeconds,
    addClockMinute: addClockMinute,
    subClockMinute: subClockMinute,
    addClockSeconds: addClockSeconds,
    subClockSeconds: subClockSeconds,
    startTimer: startTimer,
    emergencyStartTimer: emergencyStartTimer,
    remainingNow: remainingNow,
    remainingClockNow: remainingClockNow,
    clockStatus: clockStatus,
    setTimerMinutes: setTimerMinutes,
    pauseTimer: pauseTimer,
    resetTimer: resetTimer,
    nextLevel: nextLevel,
    prevLevel: prevLevel,
    ackRoundEnd: ackRoundEnd,
    confirmNextRound: confirmNextRound,
    liveTournament: liveTournament,
    nextTournament: nextTournament,
    champions: champions,
    ranking: ranking,
    previewFinish: previewFinish,
    titlesByPlayer: titlesByPlayer,
    playerPayments: playerPayments,
    playerPaidTotal: playerPaidTotal,
    availableYears: availableYears,
    formatMoney: formatMoney,
    formatDate: formatDate,
    CASH_CATEGORIES_IN: CASH_CATEGORIES_IN,
    CASH_CATEGORIES_OUT: CASH_CATEGORIES_OUT,
    cashLabel: cashLabel,
    addCash: addCash,
    updateCash: updateCash,
    deleteCash: deleteCash,
    getCash: getCash,
    cashEntries: cashEntries,
    cashTotals: cashTotals,
    cashByCategory: cashByCategory,
    monthlyReport: monthlyReport,
    yearlyReport: yearlyReport,
    inPeriod: inPeriod,
    HAND_TYPES: HAND_TYPES,
    handType: handType,
    addHand: addHand,
    deleteHand: deleteHand,
    handsByYear: handsByYear,
    cashPotRanking: cashPotRanking,
    getSeason: getSeason,
    closeSeason: closeSeason,
    reopenSeason: reopenSeason,
    applyRemote: applyRemote,
    applyRemotePlayers: replacePlayers,
    applyPlayerChange: applyPlayerChange,
    replacePlayers: replacePlayers,
    subscribe: subscribe,
    loadSession: loadSession,
    setSession: setSession,
    session: session,
    isAdmin: isAdmin,
    canWrite: canWrite,
    users: users,
    setUsers: setUsers,
    registerUser: registerUser,
    updateUser: updateUser,
    deleteUser: deleteUser,
    login: login,
    logout: logout,
    needsSetup: needsSetup
  };
})(typeof window !== "undefined" ? window : globalThis);
