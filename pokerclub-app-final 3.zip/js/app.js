(function () {
  var S = null;
  var view = "dashboard";
  var timerId = null;
  var lastAlertKey = "";
  var roundAlertClosed = false;
  var ALERT_CLOSED_KEY = "pokerclub_round_alert_closed";
  var audioCtx = null;
  var yearFilter = String(new Date().getFullYear());
  var playerQuery = "";
  var payQuery = "";
  var selectedTournamentId = "";
  var cashYear = String(new Date().getFullYear());
  var cashMonth = String(new Date().getMonth() + 1).padStart(2, "0");
  var cashTab = "mov";
  var potYear = String(new Date().getFullYear());
  var cloudBound = false;
  var presentMode = false;
  var userDismissedPresent = false;
  var clockBeeps = { three: false, two: false, one: false, zero: false };
  var lastClockFloor = null;
  var beepCycleId = "";
  var audioGestureBound = false;

  function $(id) { return document.getElementById(id); }

  function isAdmin() { return S.isAdmin(); }

  function toast(msg) {
    var el = $("toast");
    el.textContent = msg;
    el.hidden = false;
    el.classList.toggle("toast-error", /SUPABASE ERROR|ERRO:/i.test(String(msg || "")));
    clearTimeout(toast._t);
    var ms = String(msg || "").length > 80 ? 12000 : 2800;
    toast._t = setTimeout(function () { el.hidden = true; }, ms);
  }

  function supabaseErrorText(err, fallback) {
    if (err && err.message) return err.message;
    if (typeof PokerCloud !== "undefined" && PokerCloud.formatCloudError) {
      return PokerCloud.formatCloudError(err || { message: fallback || "erro desconhecido" }).message;
    }
    return fallback || "ERRO: não foi possível sincronizar com o banco online.";
  }

  function initials(name) {
    var p = String(name || "?").trim().split(/\s+/);
    return ((p[0] && p[0][0]) || "?") + ((p[1] && p[1][0]) || "");
  }

  function money(n) { return S.formatMoney(n); }
  function dte(n) { return S.formatDate(n); }

  function openModal(html) {
    var root = $("modalRoot");
    root.innerHTML = '<div class="sheet">' + html + "</div>";
    root.hidden = false;
    root.onclick = function (e) { if (e.target === root) closeModal(); };
  }
  function closeModal() {
    var root = $("modalRoot");
    root.hidden = true;
    root.innerHTML = "";
  }

  function finishConfirm(t, playerId) {
    var champ = S.getPlayer(playerId);
    var rows = S.previewFinish(t.id, playerId);
    var html = "<h2>Confirmar resultado</h2>" +
      '<div class="champion-banner"><div class="crown">CAMPEÃO</div><strong>' + S.displayName(champ) + "</strong></div>" +
      '<p class="muted">Títulos e histórico serão atualizados automaticamente.</p><div class="list">';
    rows.forEach(function (e) {
      var p = S.getPlayer(e.playerId);
      html += '<div class="item"><div class="avatar">' + (e.position || "-") + '</div><div class="meta"><strong>' +
        esc(p ? p.name : e.nameSnapshot) + "</strong><span>" + (e.position ? e.position + "º lugar" : "Sem posição") + "</span></div></div>";
    });
    html += '</div><div class="btn-row" style="margin-top:12px">' +
      '<button class="btn ghost" id="cNo">Cancelar</button>' +
      '<button class="btn primary" id="cYes">Confirmar</button></div>';
    openModal(html);
    $("cNo").onclick = closeModal;
    $("cYes").onclick = function () {
      S.setChampion(t.id, playerId);
      closeModal();
      toast("Campeão e ranking registrados");
      selectedTournamentId = t.id;
      setView("tournaments");
    };
  }

  function confirmBox(msg, onYes) {
    openModal(
      "<h2>Confirmar</h2><p>" + msg + '</p><div class="btn-row">' +
      '<button class="btn ghost" id="cNo">Cancelar</button>' +
      '<button class="btn danger" id="cYes">Excluir</button></div>'
    );
    $("cNo").onclick = closeModal;
    $("cYes").onclick = function () { closeModal(); onYes(); };
  }

  function titles(title, sub) {
    $("pageTitle").textContent = title;
    $("pageSubtitle").textContent = sub;
  }

  function ensureAudio() {
    if (audioCtx) return audioCtx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    audioCtx = new AC();
    return audioCtx;
  }

  function unlockAudio() {
    var ctx = ensureAudio();
    if (!ctx) return null;
    if (ctx.state === "suspended") {
      try { ctx.resume(); } catch (e) {}
    }
    try {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      g.gain.setValueAtTime(0.001, ctx.currentTime);
      o.connect(g);
      g.connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + 0.04);
    } catch (e) {}
    return ctx;
  }

  function playTone(freq, dur, gain, type) {
    var ctx = ensureAudio();
    if (!ctx) return;
    if (ctx.state === "suspended") {
      try { ctx.resume(); } catch (e) {}
    }
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type || "sine";
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(gain || 0.28, ctx.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + dur + 0.02);
  }

  function playBip() {
    playTone(880, 0.16, 0.3, "sine");
  }

  function playFinalBip() {
    playTone(660, 0.22, 0.34, "square");
    setTimeout(function () { playTone(990, 0.38, 0.38, "square"); }, 160);
  }

  function speakNextSlide() {
    try {
      if (!window.speechSynthesis) return;
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance("Próximo slide.");
      u.lang = "pt-BR";
      window.speechSynthesis.speak(u);
    } catch (e) {}
  }

  function audioBlocked() {
    return !audioCtx || audioCtx.state === "suspended";
  }

  function updateAudioHint() {
    var el = $("presentAudioHint");
    if (!el) return;
    var show = presentMode && audioBlocked();
    el.hidden = !show;
    if (show) el.removeAttribute("hidden");
    else el.setAttribute("hidden", "hidden");
  }

  function bindAudioGesture() {
    if (audioGestureBound) return;
    audioGestureBound = true;
    var unlock = function () {
      unlockAudio();
      updateAudioHint();
    };
    document.addEventListener("pointerdown", unlock, { passive: true });
    document.addEventListener("touchstart", unlock, { passive: true });
    document.addEventListener("click", unlock, { passive: true });
  }

  function cancelClockSounds() {
    clockBeeps = { three: false, two: false, one: false, zero: false };
    lastClockFloor = null;
    beepCycleId = "";
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {}
  }

  function clockBeepTick(sec) {
    var clock = S.getClock ? S.getClock() : {};
    var cycle = (clock && clock.cycleId) || "";
    if (cycle !== beepCycleId) {
      beepCycleId = cycle;
      clockBeeps = { three: false, two: false, one: false, zero: false };
      lastClockFloor = null;
    }
    var st = S.clockStatus ? S.clockStatus() : "";
    var s = Math.max(0, Math.floor(Number(sec) || 0));
    if (st !== "running" && st !== "finished") {
      lastClockFloor = s;
      updatePresentVisual(s);
      return;
    }
    if (lastClockFloor == null && st === "finished" && s <= 0) {
      clockBeeps.zero = true;
      lastClockFloor = 0;
      updatePresentVisual(s);
      return;
    }
    if (!clockBeeps.three && (s === 3 || (lastClockFloor != null && lastClockFloor > 3 && s < 3 && s >= 0))) {
      clockBeeps.three = true;
      playBip();
    }
    if (!clockBeeps.two && (s === 2 || (lastClockFloor != null && lastClockFloor > 2 && s < 2 && s >= 0))) {
      clockBeeps.two = true;
      playBip();
    }
    if (!clockBeeps.one && (s === 1 || (lastClockFloor != null && lastClockFloor > 1 && s < 1 && s > 0))) {
      clockBeeps.one = true;
      playBip();
    }
    if (!clockBeeps.zero && s <= 0 && (lastClockFloor == null ? st === "running" : lastClockFloor > 0)) {
      clockBeeps.zero = true;
      playFinalBip();
      speakNextSlide();
    }
    lastClockFloor = s;
    updatePresentVisual(s);
  }

  function isIOS() {
    var ua = String(navigator.userAgent || "");
    return /iP(hone|ad|od)/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  function requestClockFullscreen() {
    if (isIOS()) return;
    var el = document.documentElement;
    var req = el.requestFullscreen || el.webkitRequestFullscreen || el.webkitRequestFullScreen;
    if (!req) return;
    try {
      var p = req.call(el);
      if (p && p.catch) p.catch(function () {});
    } catch (e) {}
  }

  function exitClockFullscreen() {
    var exit = document.exitFullscreen || document.webkitExitFullscreen || document.webkitCancelFullScreen;
    if (!exit) return;
    if (!(document.fullscreenElement || document.webkitFullscreenElement)) return;
    try {
      var p = exit.call(document);
      if (p && p.catch) p.catch(function () {});
    } catch (e) {}
  }

  function lockLandscape() {
    try {
      var ori = screen.orientation || screen.mozOrientation;
      if (ori && ori.lock) {
        var p = ori.lock("landscape");
        if (p && p.catch) p.catch(function () {});
      }
    } catch (e) {}
  }

  function unlockOrientation() {
    try {
      var ori = screen.orientation || screen.mozOrientation;
      if (ori && ori.unlock) ori.unlock();
    } catch (e) {}
  }

  function updatePresentVisual(sec) {
    var stage = $("presentStage");
    var el = $("presentTime");
    var n = Math.max(0, Math.floor(Number(sec) || 0));
    if (el) {
      el.textContent = fmtTime(n);
      el.className = "present-time" + (n <= 10 ? " danger" : "");
    }
    if (!stage) return;
    var st = S.clockStatus ? S.clockStatus() : "";
    var flash = st === "running" && n <= 10 && n > 0;
    stage.classList.toggle("is-flash", flash);
    stage.classList.toggle("is-done", st === "finished" || n <= 0);
    updateAudioHint();
  }

  function updatePresentTime() {
    updatePresentVisual(clockSeconds());
  }

  function showPresentStage() {
    var stage = $("presentStage");
    if (!stage) return;
    stage.hidden = false;
    stage.removeAttribute("hidden");
    stage.classList.add("is-on");
    stage.style.display = "flex";
  }

  function hidePresentStage() {
    var stage = $("presentStage");
    if (!stage) return;
    stage.classList.remove("is-on");
    stage.hidden = true;
    stage.setAttribute("hidden", "hidden");
    stage.style.display = "none";
  }

  function enterPresent(opts) {
    presentMode = true;
    document.body.classList.add("clock-present");
    showPresentStage();
    updatePresentTime();
    bindAudioGesture();
    if (opts && opts.fullscreen) {
      requestClockFullscreen();
      lockLandscape();
    }
    updateAudioHint();
  }

  function leavePresent() {
    presentMode = false;
    document.body.classList.remove("clock-present");
    var stage = $("presentStage");
    if (stage) {
      stage.classList.remove("is-flash");
      stage.classList.remove("is-done");
    }
    hidePresentStage();
    exitClockFullscreen();
    unlockOrientation();
    updateAudioHint();
  }

  function syncPresentFromClock() {
    var st = S.clockStatus ? S.clockStatus() : "";
    if (st === "running") {
      if (!presentMode && !userDismissedPresent) enterPresent({ fullscreen: false });
    } else if (st === "ready") {
      userDismissedPresent = false;
      if (presentMode) leavePresent();
    }
    updatePresentTime();
  }

  function playAlarm() {
    var ctx = ensureAudio();
    if (!ctx) return;
    if (ctx.state === "suspended") ctx.resume();
    [0, 0.35, 0.7].forEach(function (delay) {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      o.type = "square";
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + delay);
      g.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + delay + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + delay + 0.25);
      o.connect(g); g.connect(ctx.destination);
      o.start(ctx.currentTime + delay);
      o.stop(ctx.currentTime + delay + 0.28);
    });
    if (navigator.vibrate) navigator.vibrate([200, 80, 200, 80, 300]);
  }

  function nextBlindsText(t) {
    var next = t.levels[t.currentLevel + 1];
    if (!next) return "Última rodada";
    return next.small + " / " + next.big + (next.ante ? " · Ante " + next.ante : "");
  }

  function alertKeyOf(t) {
    if (!t) return "";
    return t.id + ":" + t.currentLevel + ":" + (t.roundEndedAt || 0);
  }

  function readClosedAlert() {
    try { return sessionStorage.getItem(ALERT_CLOSED_KEY) || ""; } catch (e) { return ""; }
  }

  function writeClosedAlert(key) {
    try {
      if (key) sessionStorage.setItem(ALERT_CLOSED_KEY, key);
      else sessionStorage.removeItem(ALERT_CLOSED_KEY);
    } catch (e) {}
  }

  function endedTournament() {
    var list = S.state().tournaments;
    for (var i = 0; i < list.length; i++) {
      if (list[i].roundEnded) return list[i];
    }
    return null;
  }

  function hideRoundAlert() {
    var ov = $("alertOverlay");
    if (ov) ov.hidden = true;
  }

  function dismissRoundAlert(t) {
    roundAlertClosed = true;
    writeClosedAlert(alertKeyOf(t) || lastAlertKey);
    if (t) selectedTournamentId = t.id;
    hideRoundAlert();
  }

  function openTimerScreen(t) {
    if (t) selectedTournamentId = t.id;
    view = "timer";
    document.querySelectorAll(".tab").forEach(function (tab) {
      tab.classList.toggle("active", tab.getAttribute("data-view") === "timer");
    });
    renderTimer();
  }

  function goCronometro() {
    var ended = endedTournament();
    dismissRoundAlert(ended);
    openTimerScreen(ended);
  }

  function showRoundAlert(t) {
    var ov = $("alertOverlay");
    if (!ov || roundAlertClosed) return;
    ov.hidden = false;
    var title = $("alertTitle");
    var sub = $("alertSub");
    var blinds = $("alertBlinds");
    var nextBtn = $("alertNext");
    if (title) title.textContent = "FIM DA RODADA";
    if (sub) sub.textContent = "BLINDS SERÃO AUMENTADOS";
    if (blinds) blinds.textContent = nextBlindsText(t);
    if (nextBtn) {
      var last = t.currentLevel >= t.levels.length - 1;
      nextBtn.hidden = !isAdmin();
      nextBtn.textContent = last ? "Encerrar alerta" : "Iniciar próxima rodada";
    }
  }

  function syncRoundAlert() {
    var ended = endedTournament();
    if (!ended) {
      roundAlertClosed = false;
      lastAlertKey = "";
      writeClosedAlert("");
      hideRoundAlert();
      return;
    }
    var key = alertKeyOf(ended);
    if (roundAlertClosed || readClosedAlert() === key) {
      roundAlertClosed = true;
      hideRoundAlert();
      return;
    }
    if (lastAlertKey !== key) {
      lastAlertKey = key;
      roundAlertClosed = false;
      playAlarm();
    }
    showRoundAlert(ended);
  }

  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
  }

  function statusLabel(st) {
    if (st === "live") return "Em andamento";
    if (st === "finished") return "Encerrado";
    return "Agendado";
  }

  function currentTournament() {
    return S.liveTournament() || S.getTournament(selectedTournamentId) || S.nextTournament() || S.state().tournaments[0] || null;
  }

  function setView(name) {
    view = name;
    document.querySelectorAll(".tab").forEach(function (t) {
      t.classList.toggle("active", t.getAttribute("data-view") === name);
    });
    render();
  }

  function timerClass(sec) {
    if (sec <= 10) return "timer final10";
    if (sec <= 30) return "timer danger";
    if (sec <= 60) return "timer warn";
    return "timer";
  }

  function liveSeconds(t) {
    return t ? S.remainingNow(t) : 0;
  }

  function clockSeconds() {
    return S.remainingClockNow ? S.remainingClockNow() : (S.getClock().remainingSec || 0);
  }

  function clockStatusLabel() {
    var st = S.clockStatus ? S.clockStatus() : (S.getClock().timerRunning ? "running" : "ready");
    if (st === "running") return "Em andamento";
    if (st === "paused") return "Pausado";
    if (st === "finished") return "Finalizado";
    return "Pronto";
  }

  function clockStatusClass() {
    var st = S.clockStatus ? S.clockStatus() : (S.getClock().timerRunning ? "running" : "ready");
    return "clock-status " + st;
  }

  function tick() {
    var running = S.state().tournaments.filter(function (t) { return t.timerRunning; });
    var changed = false;
    running.forEach(function (live) {
      var before = live.roundEnded;
      S.tickTimer(live.id);
      if (S.getTournament(live.id).roundEnded && !before) changed = true;
    });
    var clock = S.getClock();
    if (clock && clock.timerRunning) {
      var wasRunning = clock.timerRunning;
      S.tickClock();
      clock = S.getClock();
      if (wasRunning && !clock.timerRunning) changed = true;
    }
    syncRoundAlert();
    if (view === "timer") {
      var clubEl = $("clubClockTime");
      var stEl = document.querySelector("#clubClockCard .clock-status");
      if (clubEl) {
        var sec = clockSeconds();
        clubEl.textContent = fmtTime(sec);
        clubEl.className = timerClass(sec);
        if (stEl) { stEl.textContent = clockStatusLabel(); stEl.className = clockStatusClass(); }
      }
      var t = S.getTournament(selectedTournamentId) || S.liveTournament();
      if (t && !t.roundEnded) {
        var tourEl = document.querySelector("#view .card.timer-wrap:not(#clubClockCard) .timer");
        if (tourEl) {
          var tsec = liveSeconds(t);
          tourEl.textContent = fmtTime(tsec);
          tourEl.className = timerClass(tsec);
        }
      }
      if (changed) render();
    } else if (view === "dashboard") {
      var liveT = S.liveTournament();
      var elDash = document.querySelector(".timer");
      var stDash = document.querySelector(".clock-status");
      if (elDash && liveT && !liveT.roundEnded) {
        var dsec = liveSeconds(liveT);
        elDash.textContent = fmtTime(dsec);
        elDash.className = timerClass(dsec);
      } else if (elDash && !liveT) {
        var csec = clockSeconds();
        elDash.textContent = fmtTime(csec);
        elDash.className = timerClass(csec);
        if (stDash) { stDash.textContent = clockStatusLabel(); stDash.className = clockStatusClass(); }
        if (changed) render();
      } else if (changed) render();
    }
    clockBeepTick(clockSeconds());
    syncPresentFromClock();
  }

  function startLoop() {
    if (timerId) clearInterval(timerId);
    timerId = setInterval(tick, 250);
  }

  function field(label, attrs) {
    return "<label>" + label + '<input ' + attrs + "></label>";
  }

  /* ---------- DASHBOARD ---------- */
  function renderDashboard() {
    titles("Poker Club", "Painel do clube");
    var live = S.liveTournament();
    var next = S.nextTournament();
    var t = live || next;
    var champs = S.champions().slice(0, 3);
    var ranking = S.titlesByPlayer().slice(0, 5);
    var playersN = S.state().players.length;
    var html = cloudDiagHtml();
    html += '<div class="kpi">' +
      '<div class="card"><div class="num">' + playersN + '</div><div class="lbl">Jogadores</div></div>' +
      '<div class="card"><div class="num">' + S.state().tournaments.length + '</div><div class="lbl">Torneios</div></div></div>';

    if (live) {
      var lvl = live.levels[live.currentLevel] || live.levels[0];
      html += '<div class="card">' +
        '<h3>Torneio em andamento</h3>' +
        "<strong>" + live.name + "</strong>" +
        '<div class="muted">' + dte(live.date) + " " + live.time + " · " + S.activeCount(live) + " ativos</div>" +
        '<div class="timer-wrap"><div class="' + timerClass(liveSeconds(live)) + '">' + fmtTime(liveSeconds(live)) + "</div>" +
        '<div class="round-info">Rodada ' + (live.currentLevel + 1) + " / " + live.levels.length + "</div>" +
        '<div class="blinds">' + lvl.small + " / " + lvl.big + (lvl.ante ? " · Ante " + lvl.ante : "") + "</div></div>" +
        '<div class="row"><span class="muted">Arrecadado</span><strong>' + money(S.collected(live)) + "</strong></div>" +
        '<button class="btn primary block" data-go="timer" style="margin-top:10px">Abrir cronômetro</button></div>';
    } else if (next) {
      html += '<div class="card"><h3>Próximo torneio</h3><strong>' + next.name + "</strong>" +
        '<div class="muted">' + dte(next.date) + " às " + next.time + " · Inscrição " + money(next.buyIn) + "</div>" +
        '<div class="row" style="margin-top:8px"><span class="muted">Inscritos</span><strong>' + (next.entries || []).length + "</strong></div>" +
        '<button class="btn primary block" data-open-t="' + next.id + '" style="margin-top:10px">Abrir torneio</button></div>';
    } else {
      html += '<div class="card empty">Nenhum torneio cadastrado.<br>O relógio funciona mesmo assim.</div>';
    }
    html += clubClockCardHtml();

    html += '<div class="card"><h3>Últimos campeões</h3>';
    if (!champs.length) html += '<div class="muted">Ainda não há campeões.</div>';
    else champs.forEach(function (c) {
      var p = S.getPlayer(c.championId);
      html += '<div class="item"><div class="avatar">' + initials(p ? p.name : "?") + '</div><div class="meta"><strong>' + S.displayName(p) + "</strong><span>" + c.name + " · " + dte(c.date) + "</span></div></div>";
    });
    html += "</div>";

    html += '<div class="card"><h3>Ranking de títulos</h3>';
    if (!ranking.length) html += '<div class="muted">Sem títulos registrados.</div>';
    else ranking.forEach(function (r, i) {
      html += '<div class="row" style="padding:6px 0"><span>' + (i + 1) + ". " + S.displayName(r.player) + "</span><strong>" + r.titles + "</strong></div>";
    });
    html += "</div>";

    var potYearNow = String(new Date().getFullYear());
    var pot = S.cashPotRanking(potYearNow);
    var potSeason = S.getSeason(potYearNow);
    html += '<div class="card"><h3>Cash Pot ' + potYearNow + "</h3>";
    if (potSeason) {
      html += '<div class="muted">Campeão: ' + S.displayName(S.getPlayer(potSeason.championId)) + " · " + potSeason.points + " pts</div>";
    } else if (!pot.length) {
      html += '<div class="muted">Nenhuma mão especial neste ano.</div>';
    } else {
      html += '<div class="row"><span>Líder</span><strong>' + S.displayName(pot[0].player) + " · " + pot[0].points + " pts</strong></div>";
    }
    html += '<button class="btn ghost block" data-go="cashpot" style="margin-top:10px">Ver ranking</button></div>';

    if (isAdmin()) {
      var totals = S.cashTotals();
      html += '<div class="card"><h3>Caixa</h3>' +
        '<div class="row"><span class="muted">Entradas</span><strong class="amt in">' + money(totals.income) + "</strong></div>" +
        '<div class="row"><span class="muted">Saídas</span><strong class="amt out">' + money(totals.expense) + "</strong></div>" +
        '<div class="row"><span class="muted">Saldo</span><strong>' + money(totals.balance) + "</strong></div>" +
        '<button class="btn block" data-go="cash" style="margin-top:10px">Abrir caixa</button></div>';
    }

    if (!S.session()) {
      html += '<div class="card"><h3>Acesso do clube</h3>' +
        '<p class="muted">Cadastre com nome e senha. A senha fica no Auth, não no clube.</p>' +
        '<button class="btn primary block" id="btnLogin">Entrar</button>' +
        '<button class="btn block" id="btnRegUser" style="margin-top:8px">Cadastrar usuário</button>' +
        '<button class="btn ghost block" id="btnRegAdmin" style="margin-top:8px">Sou administrador</button></div>';
    }

    $("view").innerHTML = html;
    bindClockControls();
    var btnLogin = $("btnLogin");
    if (btnLogin) btnLogin.onclick = showLogin;
    var btnRegAdmin = $("btnRegAdmin");
    if (btnRegAdmin) btnRegAdmin.onclick = function () { showRegister("admin"); };
    var btnRegUser = $("btnRegUser");
    if (btnRegUser) btnRegUser.onclick = function () { showRegister("player"); };
  }

  /* ---------- PLAYERS ---------- */
  function playerForm(p) {
    openModal(
      "<h2>" + (p ? "Editar jogador" : "Novo jogador") + "</h2>" +
      '<div class="form">' +
      field("Nome completo", 'id="fName" value="' + (p ? esc(p.name) : "") + '"') +
      field("Apelido", 'id="fNick" value="' + (p ? esc(p.nickname) : "") + '"') +
      field("Telefone", 'id="fPhone" value="' + (p ? esc(p.phone) : "") + '" type="tel"') +
      field("Data de cadastro", 'id="fDate" type="date" value="' + (p ? p.createdAt : S.today()) + '"') +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button>' +
      '<button class="btn primary" id="fSave">Salvar</button></div></div>'
    );
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      ensureCloud().then(function () {
        if (!PokerCloud.upsertPlayer) throw (PokerCloud.configMissingError ? PokerCloud.configMissingError() : { message: "Supabase nao configurado" });
        var payload = { name: $("fName").value, nickname: $("fNick").value, phone: $("fPhone").value, createdAt: $("fDate").value };
        var next = p ? S.updatePlayer(p.id, payload) : S.addPlayer(payload);
        return PokerCloud.upsertPlayer(next).then(function () {
          return PokerCloud.fetchPlayers();
        }).then(function (rows) {
          S.replacePlayers(rows);
          closeModal(); toast("Jogador salvo"); render();
        });
      }).catch(function (err) {
        console.error("Falha ao gravar jogador no Supabase", err);
        toast(supabaseErrorText(err, "UPSERT public.players falhou"));
      });
    };
  }

  function cloudDiagHtml() {
    var st = (typeof PokerCloud !== "undefined" && PokerCloud.status) ? PokerCloud.status() : null;
    var cfg = (typeof PokerCloud !== "undefined" && PokerCloud.getConfig) ? PokerCloud.getConfig() : null;
    var sess = S.session ? S.session() : null;
    var host = cfg && cfg.url ? String(cfg.url).replace(/^https:\/\//, "").split("/")[0] : "(ausente)";
    var lines = [];
    lines.push("club_id: pokerclub");
    lines.push("URL: " + host);
    lines.push("anon key no build: " + (cfg && cfg.anonKey ? "sim" : "NAO"));
    lines.push("Auth JWT: " + (sess && sess.id ? "sim (" + String(sess.id).slice(0, 8) + ")" : "NAO"));
    if (st && st.error) lines.push(st.error);
    else if (!cfg) lines.push("SUPABASE ERROR: {code: CONFIG, message: POKER_SUPABASE_CONFIG ausente no build, details: js/supabase-config.js null, hint: Netlify env USER_SUPABASE_URL + USER_SUPABASE_ANON_KEY}");
    var bad = !cfg || !sess || !sess.id || (st && st.error);
    if (!bad) return "";
    return '<div class="cloud-error">' + lines.map(function (l) { return "<div>" + esc(l) + "</div>"; }).join("") +
      '<button class="btn primary block" id="cloudFixBtn" type="button" style="margin-top:10px">Conectar banco agora</button></div>';
  }

  function renderPlayers() {
    titles("Jogadores", S.state().players.length + " cadastrados");
    var list = S.searchPlayers(playerQuery);
    var html = cloudDiagHtml();
    html += '<input class="search" id="playerSearch" placeholder="Buscar nome, apelido ou telefone" value="' + esc(playerQuery) + '">';
    html += '<div class="list">';
    if (!list.length) html += '<div class="empty">Nenhum jogador encontrado.</div>';
    list.forEach(function (p) {
      var n = S.playerTournamentsCount(p.id);
      html += '<div class="item">' +
        '<div class="avatar">' + initials(p.name) + "</div>" +
        '<div class="meta"><strong>' + esc(p.name) + "</strong><span>" +
        (p.nickname ? esc(p.nickname) + " · " : "") + esc(p.phone || "sem telefone") + " · " + n + " torneio(s)</span></div>" +
        (isAdmin() ? '<div class="small-actions"><button class="btn" data-edit-p="' + p.id + '">Editar</button>' +
        '<button class="btn danger" data-del-p="' + p.id + '">Excluir</button></div>' : "") + "</div>";
    });
    html += "</div>" + (isAdmin() ? '<button class="fab" id="addPlayer" type="button">+</button>' : "");
    $("view").innerHTML = html;
    var s = $("playerSearch");
    s.oninput = function () {
      playerQuery = s.value;
      var pos = s.selectionStart;
      render();
      var ns = $("playerSearch");
      if (ns) { ns.focus(); ns.setSelectionRange(pos, pos); }
    };
  }

  /* ---------- TOURNAMENTS ---------- */
  function tournamentForm(t) {
    openModal(
      "<h2>" + (t ? "Editar torneio" : "Novo torneio") + "</h2>" +
      '<div class="form">' +
      field("Nome do torneio", 'id="tName" value="' + (t ? esc(t.name) : "") + '"') +
      field("Data", 'id="tDate" type="date" value="' + (t ? t.date : S.today()) + '"') +
      field("Horario", 'id="tTime" type="time" value="' + (t ? t.time : S.nowTime()) + '"') +
      field("Valor da inscricao (R$)", 'id="tBuy" type="number" min="0" step="0.01" value="' + (t ? t.buyIn : 50) + '"') +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button>' +
      '<button class="btn primary" id="fSave">Salvar</button></div></div>'
    );
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      try {
        var payload = { name: $("tName").value, date: $("tDate").value, time: $("tTime").value, buyIn: $("tBuy").value };
        if (t) S.updateTournament(t.id, payload); else S.addTournament(payload);
        closeModal(); toast("Torneio salvo"); render();
      } catch (err) { toast(err.message); }
    };
  }

  function pickPlayers(t) {
    var selected = {};
    (t.entries || []).forEach(function (e) { selected[e.playerId] = true; });
    var html = "<h2>Jogadores do torneio</h2>";
    if (!S.state().players.length) html += '<div class="empty">Cadastre jogadores primeiro.</div>';
    S.state().players.forEach(function (p) {
      html += '<label class="check"><input type="checkbox" data-pid="' + p.id + '"' + (selected[p.id] ? " checked" : "") + ">" +
        "<div><strong>" + esc(p.name) + "</strong><div class='muted'>" + esc(p.nickname || p.phone || "") + "</div></div></label>";
    });
    html += '<button class="btn primary block" id="savePlayers">Salvar inscritos</button>';
    openModal(html);
    $("savePlayers").onclick = function () {
      var ids = Array.prototype.map.call(document.querySelectorAll("#modalRoot input[data-pid]:checked"), function (el) {
        return el.getAttribute("data-pid");
      });
      S.setTournamentPlayers(t.id, ids);
      closeModal(); toast("Inscritos atualizados"); render();
    };
  }

  function renderTournamentDetail(t) {
    selectedTournamentId = t.id;
    titles(t.name, dte(t.date) + " " + t.time);
    var champ = t.championId ? S.getPlayer(t.championId) : null;
    var html = '<div class="card"><div class="row"><span class="tag ' + (t.status === "live" ? "live" : t.status === "finished" ? "ok" : "warn") + '">' + statusLabel(t.status) + "</span>" +
      "<strong>" + money(t.buyIn) + "</strong></div>" +
      '<div class="muted" style="margin-top:8px">Inscritos ' + (t.entries || []).length + " · Ativos " + S.activeCount(t) + " · Arrecadado " + money(S.collected(t)) + "</div>";
    if (champ) html += '<div class="champion-banner" style="margin-top:12px"><div class="crown">CAMPEÃO</div><strong>' + S.displayName(champ) + "</strong>" +
      '<div class="muted">' + S.titlesByPlayer().filter(function (r) { return r.playerId === t.championId; }).map(function (r) { return r.titles + " título(s)"; }).join("") + "</div></div>";
    if (isAdmin()) {
      html += '<div class="btn-row" style="margin-top:12px"><button class="btn" data-edit-t="' + t.id + '">Editar</button>' +
        '<button class="btn" data-pick="' + t.id + '">Jogadores</button></div>' +
        '<div class="btn-row" style="margin-top:8px"><button class="btn primary" data-go="timer">Cronômetro</button>' +
        (t.status === "upcoming" ? '<button class="btn" data-start="' + t.id + '">Iniciar</button>' : '<button class="btn ghost" data-go="payments">Pagamentos</button>') +
        "</div>";
    } else {
      html += '<button class="btn primary block" data-go="timer" style="margin-top:12px">Ver cronômetro</button>';
    }
    html += "</div>";

    html += '<div class="card"><h3>' + (t.status === "finished" ? "Ranking final" : "Controle dos jogadores") + "</h3>";
    var entries = S.ranking(t);
    if (!entries.length) html += '<div class="muted">Nenhum inscrito ainda.</div>';
    entries.forEach(function (e) {
      var p = S.getPlayer(e.playerId);
      html += '<div class="item"><div class="avatar">' + initials(p ? p.name : e.nameSnapshot) + "</div>" +
        '<div class="meta"><strong>' + esc(p ? p.name : e.nameSnapshot) + "</strong><span>" +
        (e.eliminated ? "Eliminado · " + (e.position ? e.position + "º lugar" : "") : "No torneio") +
        " · " + (e.paid ? "Pago " + money(e.paidAmount) : "Pendente") + "</span></div>" +
        '<div class="small-actions">';
      if (isAdmin() && !e.eliminated && t.status !== "finished") {
        html += '<button class="btn danger" data-elim="' + e.playerId + '">Eliminar</button>';
        if ((t.entries || []).filter(function (x) { return !x.eliminated; }).length <= 2)
          html += '<button class="btn primary" data-champ="' + e.playerId + '">Campeão</button>';
      } else if (isAdmin() && e.eliminated) {
        html += '<button class="btn" data-undo="' + e.playerId + '">Reativar</button>';
      }
      html += "</div></div>";
    });
    html += "</div>";
    html += '<button class="btn ghost block" data-back-t>Voltar a lista</button>';
    $("view").innerHTML = html;
  }

  function renderTournaments() {
    if (selectedTournamentId) {
      var t = S.getTournament(selectedTournamentId);
      if (t) return renderTournamentDetail(t);
      selectedTournamentId = "";
    }
    titles("Torneios", S.state().tournaments.length + " registrados");
    var html = '<div class="list">';
    var list = S.state().tournaments.slice();
    if (!list.length) html += '<div class="empty">Nenhum torneio ainda.</div>';
    list.forEach(function (t) {
      html += '<div class="item" data-open-t="' + t.id + '">' +
        '<div class="avatar">' + (t.status === "live" ? "GO" : t.status === "finished" ? "OK" : "T") + "</div>" +
        '<div class="meta"><strong>' + esc(t.name) + "</strong><span>" + dte(t.date) + " " + t.time + " · " + (t.entries || []).length + " jogadores · " + money(t.buyIn) + "</span></div>" +
        '<span class="tag ' + (t.status === "live" ? "live" : t.status === "finished" ? "ok" : "warn") + '">' + statusLabel(t.status) + "</span>" +
        (isAdmin() ? '<button class="btn danger" data-del-t="' + t.id + '">Excluir</button>' : "") + "</div>";
    });
    html += "</div>" + (isAdmin() ? '<button class="fab" id="addT" type="button">+</button>' : "");
    $("view").innerHTML = html;
  }

  /* ---------- TIMER ---------- */
  function levelsEditor(t) {
    var rows = t.levels.map(function (l, i) {
      return '<div class="form" style="border-bottom:1px solid var(--line);padding-bottom:8px;margin-bottom:8px">' +
        "<strong>Rodada " + (i + 1) + "</strong>" +
        '<div class="btn-row three">' +
        field("Min", 'data-lv="' + i + '" data-k="minutes" type="number" min="1" value="' + l.minutes + '"') +
        field("SB", 'data-lv="' + i + '" data-k="small" type="number" min="0" value="' + l.small + '"') +
        field("BB", 'data-lv="' + i + '" data-k="big" type="number" min="0" value="' + l.big + '"') +
        "</div>" + field("Ante", 'data-lv="' + i + '" data-k="ante" type="number" min="0" value="' + l.ante + '"') + "</div>";
    }).join("");
    openModal("<h2>Estrutura de blinds</h2>" + rows +
      '<div class="btn-row"><button class="btn" id="addLvl">+ Rodada</button><button class="btn primary" id="saveLvl">Salvar</button></div>');
    $("addLvl").onclick = function () {
      var levels = t.levels.concat([{ minutes: 15, small: 0, big: 0, ante: 0 }]);
      S.setLevels(t.id, levels);
      closeModal();
      levelsEditor(S.getTournament(t.id));
    };
    $("saveLvl").onclick = function () {
      var map = {};
      document.querySelectorAll("#modalRoot [data-lv]").forEach(function (inp) {
        var i = inp.getAttribute("data-lv");
        map[i] = map[i] || {};
        map[i][inp.getAttribute("data-k")] = inp.value;
      });
      var levels = Object.keys(map).sort(function (a, b) { return a - b; }).map(function (k) { return map[k]; });
      try { S.setLevels(t.id, levels); closeModal(); toast("Estrutura salva"); render(); }
      catch (err) { toast(err.message); }
    };
  }

  function startClubClockFromClick() {
    unlockAudio();
    bindAudioGesture();
    cancelClockSounds();
    userDismissedPresent = true;
    S.startClock();
    render();
    updatePresentTime();
  }

  function resetClubClockFromClick() {
    cancelClockSounds();
    userDismissedPresent = false;
    S.resetClock();
    leavePresent();
    toast("Resetado");
    render();
  }

  function bindClockButton(id, fn) {
    var el = $(id);
    if (el) el.onclick = fn;
  }

  function applyClockMinutesFromInput(inputId) {
    var el = $(inputId);
    var raw = el ? String(el.value || "").trim() : "";
    var mins = parseInt(raw, 10);
    if (!raw || !isFinite(mins) || mins !== Number(raw) || mins < 1) {
      toast("Informe os minutos");
      return;
    }
    try {
      cancelClockSounds();
      S.setClockMinutes(mins);
      toast(mins + ":00");
      render();
      updatePresentTime();
    } catch (e) { toast(e.message); }
  }

  function bindClockControls() {
    bindClockButton("tmStart", function () { try { startClubClockFromClick(); } catch (e) { toast(e.message); } });
    bindClockButton("tmPause", function () { S.pauseClock(); toast("Pausado"); render(); });
    bindClockButton("tmReset", function () { try { resetClubClockFromClick(); } catch (e) { toast(e.message); } });
    bindClockButton("tmPlus", function () { S.addClockMinute(); render(); updatePresentTime(); });
    bindClockButton("tmMinus", function () { S.subClockMinute(); render(); updatePresentTime(); });
    bindClockButton("tmPlus10", function () { S.addClockSeconds(10); render(); updatePresentTime(); });
    bindClockButton("tmMinus10", function () { S.subClockSeconds(10); render(); updatePresentTime(); });
    bindClockButton("tmApply", function () { applyClockMinutesFromInput("tmMinutes"); });
    bindClockButton("tmFullscreen", function () {
      userDismissedPresent = false;
      enterPresent({ fullscreen: true });
    });
  }

  function bindPresentControls() {
    bindClockButton("presentStart", function () { try { startClubClockFromClick(); } catch (e) { toast(e.message); } });
    bindClockButton("presentPause", function () { S.pauseClock(); toast("Pausado"); updatePresentTime(); render(); });
    bindClockButton("presentReset", function () { try { resetClubClockFromClick(); } catch (e) { toast(e.message); } });
    bindClockButton("presentPlus", function () { S.addClockMinute(); updatePresentTime(); render(); });
    bindClockButton("presentMinus", function () { S.subClockMinute(); updatePresentTime(); render(); });
    bindClockButton("presentPlus10", function () { S.addClockSeconds(10); updatePresentTime(); render(); });
    bindClockButton("presentMinus10", function () { S.subClockSeconds(10); updatePresentTime(); render(); });
    bindClockButton("presentApply", function () { applyClockMinutesFromInput("presentMinutes"); });
  }

  function clubClockCardHtml() {
    var sec = clockSeconds();
    var running = S.clockStatus && S.clockStatus() === "running";
    return '<div class="card timer-wrap" id="clubClockCard">' +
      "<h3>Cronômetro</h3>" +
      '<p class="muted">Relógio livre · ajuste o tempo antes de iniciar</p>' +
      '<div class="' + clockStatusClass() + '">' + clockStatusLabel() + "</div>" +
      '<div class="' + timerClass(sec) + '" id="clubClockTime">' + fmtTime(sec) + "</div>" +
      '<h3 class="clock-controls-title">Controles do cronômetro</h3>' +
      '<div class="clock-controls">' +
      '<button class="btn primary block" id="tmStart" type="button">INICIAR</button>' +
      '<button class="btn block" id="tmPause" type="button">PAUSAR</button>' +
      '<button class="btn block" id="tmReset" type="button">RESET</button>' +
      '<div class="clock-minutes-row">' +
      '<input class="clock-minutes-input" id="tmMinutes" type="number" inputmode="numeric" min="1" max="180" step="1" placeholder="30" aria-label="Minutos">' +
      '<span class="clock-minutes-label">minutos</span>' +
      '<button class="btn primary" id="tmApply" type="button">APLICAR</button>' +
      "</div>" +
      '<div class="clock-adjust-grid">' +
      '<button class="btn adj-time" id="tmPlus" type="button">+1 MIN</button>' +
      '<button class="btn adj-time" id="tmMinus" type="button">-1 MIN</button>' +
      '<button class="btn adj-time" id="tmPlus10" type="button">+10 SEG</button>' +
      '<button class="btn adj-time" id="tmMinus10" type="button">-10 SEG</button>' +
      "</div>" +
      '<button class="btn ghost block" id="tmFullscreen" type="button">' + (running ? "Tela cheia" : "Mesa / tela cheia") + "</button>" +
      "</div>" +
      '<div class="muted" style="margin-top:10px">Tempo sincronizado em todos os aparelhos via Supabase.</div></div>';
  }

  function renderStandaloneClock() {
    titles("Cronômetro", "Relógio livre");
    $("view").innerHTML = clubClockCardHtml();
    bindClockControls();
  }

  function renderTimer() {
    var t = S.liveTournament() || S.getTournament(selectedTournamentId);
    titles("Cronômetro", "Relógio livre");
    var html = clubClockCardHtml();
    if (t) {
    selectedTournamentId = t.id;
    var lvl = t.levels[t.currentLevel] || t.levels[0];
    var nextLvl = t.levels[t.currentLevel + 1];
    var tsec = liveSeconds(t);
    html += '<div class="card timer-wrap">' +
      "<h3>" + t.name + "</h3>" +
      '<div class="round-info">Rodada ' + (t.currentLevel + 1) + " de " + t.levels.length + " · " + statusLabel(t.status) + "</div>" +
      '<div class="' + timerClass(tsec) + '">' + fmtTime(tsec) + "</div>" +
      '<div class="blinds">' + lvl.small + " / " + lvl.big + (lvl.ante ? " · Ante " + lvl.ante : "") + "</div>" +
      (t.roundEnded ? '<div class="muted">FIM DA RODADA · Próximos blinds: ' + nextBlindsText(t) + "</div>" : (nextLvl ? '<div class="muted">Próxima: ' + nextLvl.small + " / " + nextLvl.big + (nextLvl.ante ? " · Ante " + nextLvl.ante : "") + "</div>" : "")) +
      (isAdmin()
        ? '<div class="btn-row three" style="margin-top:12px">' +
          '<button class="btn primary" id="tourStart">INICIAR</button>' +
          '<button class="btn" id="tourPause">PAUSAR</button>' +
          '<button class="btn" id="tourReset">REINICIAR</button></div>' +
          (t.roundEnded
            ? '<button class="btn primary block" id="tmNext" style="margin-top:10px">Iniciar próxima rodada</button>'
            : '<div class="btn-row" style="margin-top:10px"><button class="btn ghost" id="tmPrev">Rodada anterior</button><button class="btn" id="tmNext">Avançar rodada</button></div>') +
          '<button class="btn block" id="tmLevels" style="margin-top:10px">Configurar blinds e tempos</button>' +
          '<button class="btn ghost block" id="tmSound" style="margin-top:10px">Testar som</button>'
        : '<p class="muted">Somente o admin controla as rodadas. A tela atualiza em tempo real.</p>') +
      "</div>";

    html += '<div class="card"><h3>Estrutura das rodadas</h3><div class="structure">';
    t.levels.forEach(function (l, i) {
      html += '<div class="lvl' + (i === t.currentLevel ? " current" : "") + '"><strong>' + (i + 1) + "</strong>" +
        "<span>" + l.small + " / " + l.big + (l.ante ? " · Ante " + l.ante : "") + "</span>" +
        "<span class='muted'>" + l.minutes + " min</span></div>";
    });
    html += "</div></div>";
    }
    $("view").innerHTML = html;
    bindClockControls();
    if (roundAlertClosed) hideRoundAlert();
    if (t && isAdmin()) {
      var tourStart = $("tourStart");
      var tourPause = $("tourPause");
      var tourReset = $("tourReset");
      if (tourStart) tourStart.onclick = function () { try { ensureAudio(); S.startTimer(t.id); hideRoundAlert(); toast("Cronômetro iniciado"); render(); } catch (e) { toast(e.message); } };
      if (tourPause) tourPause.onclick = function () { S.pauseTimer(t.id); toast("Pausado"); render(); };
      if (tourReset) tourReset.onclick = function () { S.resetTimer(t.id); lastAlertKey = ""; hideRoundAlert(); toast("Reiniciado"); render(); };
      var nextBtn = $("tmNext");
      if (nextBtn) nextBtn.onclick = function () {
        if (t.roundEnded) S.confirmNextRound(t.id);
        else S.nextLevel(t.id);
        lastAlertKey = "";
        hideRoundAlert();
        toast("Próxima rodada");
        render();
      };
      var prev = $("tmPrev");
      if (prev) prev.onclick = function () { S.prevLevel(t.id); lastAlertKey = ""; hideRoundAlert(); render(); };
      var lvls = $("tmLevels");
      if (lvls) lvls.onclick = function () { levelsEditor(S.getTournament(t.id)); };
      var sound = $("tmSound");
      if (sound) sound.onclick = function () { ensureAudio(); playAlarm(); toast("Som de alerta"); };
    }
    if (!roundAlertClosed) syncRoundAlert();
    else hideRoundAlert();
  }

  /* ---------- PAYMENTS ---------- */
  function renderPayments() {
    titles("Pagamentos", "Depositos e arrecadacao");
    var tournaments = S.state().tournaments;
    var t = S.getTournament(selectedTournamentId) || S.liveTournament() || tournaments[0];
    var html = '<label>Torneio<select id="payT">';
    html += '<option value="">Todos os jogadores</option>';
    tournaments.forEach(function (x) {
      html += '<option value="' + x.id + '"' + (t && t.id === x.id ? " selected" : "") + ">" + esc(x.name) + " · " + dte(x.date) + "</option>";
    });
    html += "</select></label>";

    if (t) {
      html += '<div class="card"><h3>' + esc(t.name) + '</h3><div class="row"><span class="muted">Total arrecadado</span><strong>' + money(S.collected(t)) + "</strong></div>";
      var paidN = (t.entries || []).filter(function (e) { return e.paid; }).length;
      html += '<div class="muted">' + paidN + " pagos · " + ((t.entries || []).length - paidN) + " pendentes</div></div>";
      html += '<div class="list">';
      (t.entries || []).forEach(function (e) {
        var p = S.getPlayer(e.playerId);
        html += '<div class="item"><div class="avatar">' + initials(p ? p.name : e.nameSnapshot) + "</div>" +
          '<div class="meta"><strong>' + esc(p ? p.name : e.nameSnapshot) + "</strong><span>" +
          (e.paid ? "Pago " + money(e.paidAmount) + (e.paidAt ? " em " + dte(e.paidAt) : "") : "Pendente · inscricao " + money(t.buyIn)) + "</span></div>" +
          '<div class="small-actions">' +
          (e.paid
            ? '<button class="btn" data-unpay="' + e.playerId + '">Pendente</button>'
            : '<button class="btn primary" data-pay="' + e.playerId + '">Registrar</button>') +
          "</div></div>";
      });
      html += "</div>";
    }

    html += '<div class="card"><h3>Histórico por jogador</h3>' +
      '<input class="search" id="paySearch" placeholder="Buscar jogador" value="' + esc(payQuery) + '">';
    var plist = S.searchPlayers(payQuery);
    if (!plist.length) html += '<div class="muted">Nenhum jogador.</div>';
    plist.forEach(function (p) {
      html += '<div class="item"><div class="avatar">' + initials(p.name) + '</div><div class="meta"><strong>' + esc(p.name) + "</strong>" +
        "<span>Total pago " + money(S.playerPaidTotal(p.id)) + "</span></div>" +
        '<button class="btn" data-hist="' + p.id + '">Histórico</button></div>';
    });
    html += "</div>";
    $("view").innerHTML = html;
    $("payT").onchange = function () { selectedTournamentId = $("payT").value; render(); };
    var s = $("paySearch");
    if (s) {
      s.oninput = function () {
        payQuery = s.value;
        var pos = s.selectionStart;
        render();
        var ns = $("paySearch");
        if (ns) { ns.focus(); ns.setSelectionRange(pos, pos); }
      };
    }
  }

  function payPrompt(t, playerId) {
    var e = (t.entries || []).find(function (x) { return x.playerId === playerId; });
    var p = S.getPlayer(playerId);
    openModal("<h2>Registrar pagamento</h2><p>" + S.displayName(p) + "</p>" +
      field("Valor pago (R$)", 'id="payVal" type="number" min="0" step="0.01" value="' + (e && e.paidAmount ? e.paidAmount : t.buyIn) + '"') +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button><button class="btn primary" id="fSave">Salvar</button></div>');
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      try { S.registerPayment(t.id, playerId, $("payVal").value); closeModal(); toast("Pagamento registrado"); render(); }
      catch (err) { toast(err.message); }
    };
  }

  function playerHistory(playerId) {
    var p = S.getPlayer(playerId);
    var hist = S.playerPayments(playerId);
    var html = "<h2>" + S.displayName(p) + "</h2><p class='muted'>Total pago: " + money(S.playerPaidTotal(playerId)) + "</p>";
    if (!hist.length) {
      S.state().tournaments.forEach(function (t) {
        var e = (t.entries || []).find(function (x) { return x.playerId === playerId; });
        if (e) hist.push({ date: t.date, tournamentId: t.id, amount: e.paidAmount || 0, status: e.paid ? "pago" : "pendente" });
      });
    }
    if (!hist.length) html += '<div class="empty">Sem registros.</div>';
    hist.forEach(function (h) {
      var t = S.getTournament(h.tournamentId);
      html += '<div class="item"><div class="meta"><strong>' + (t ? t.name : "Torneio") + "</strong><span>" +
        dte(h.date) + " · " + money(h.amount) + '</span></div><span class="tag ' + (h.status === "pago" ? "ok" : "warn") + '">' + h.status + "</span></div>";
    });
    html += '<button class="btn block" id="fCancel">Fechar</button>';
    openModal(html);
    $("fCancel").onclick = closeModal;
  }

  /* ---------- CASH ---------- */
  var MONTHS = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

  function cashForm(item, presetType) {
    var type = item ? item.type : (presetType || "in");
    var cats = type === "out" ? S.CASH_CATEGORIES_OUT : S.CASH_CATEGORIES_IN;
    var catOpts = cats.map(function (c) {
      return '<option value="' + c + '"' + ((item && item.category === c) || (!item && c === (type === "out" ? "premio" : "outros")) ? " selected" : "") + ">" + S.cashLabel(c) + "</option>";
    }).join("");
    var tOpts = '<option value="">Nenhum</option>' + S.state().tournaments.map(function (t) {
      return '<option value="' + t.id + '"' + (item && item.tournamentId === t.id ? " selected" : "") + ">" + esc(t.name) + "</option>";
    }).join("");
    openModal(
      "<h2>" + (item ? "Editar lançamento" : (type === "out" ? "Nova saída" : "Nova entrada")) + "</h2>" +
      '<div class="form">' +
      '<label>Tipo<select id="cType">' +
      '<option value="in"' + (type === "in" ? " selected" : "") + ">Entrada</option>" +
      '<option value="out"' + (type === "out" ? " selected" : "") + ">Saída</option></select></label>" +
      field("Valor (R$)", 'id="cAmount" type="number" min="0.01" step="0.01" value="' + (item ? item.amount : "") + '"') +
      field("Descrição", 'id="cDesc" value="' + (item ? esc(item.description) : "") + '"') +
      '<label>Categoria<select id="cCat">' + catOpts + "</select></label>" +
      field("Data", 'id="cDate" type="date" value="' + (item ? item.date : S.today()) + '"') +
      '<label>Torneio (opcional)<select id="cTid">' + tOpts + "</select></label>" +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button>' +
      '<button class="btn primary" id="fSave">Salvar</button></div></div>'
    );
    $("cType").onchange = function () {
      var next = $("cType").value;
      var payload = {
        type: next,
        amount: $("cAmount").value,
        description: $("cDesc").value,
        date: $("cDate").value,
        tournamentId: $("cTid").value
      };
      closeModal();
      cashForm(item ? Object.assign({}, item, payload) : payload, next);
    };
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      try {
        var payload = {
          type: $("cType").value,
          amount: $("cAmount").value,
          description: $("cDesc").value,
          category: $("cCat").value,
          date: $("cDate").value,
          tournamentId: $("cTid").value
        };
        if (item && item.id && !item.auto) S.updateCash(item.id, payload);
        else S.addCash(payload);
        closeModal(); toast("Lançamento salvo"); render();
      } catch (err) { toast(err.message); }
    };
  }

  function renderCash() {
    titles("Caixa", "Entradas, saídas e relatórios");
    var years = S.availableYears();
    if (years.indexOf(cashYear) === -1) cashYear = years[0] || String(new Date().getFullYear());
    var monthTotals = S.cashTotals(cashYear, cashMonth);
    var yearTotals = S.cashTotals(cashYear);
    var allTotals = S.cashTotals();
    var html = '<div class="kpi three">' +
      '<div class="card"><div class="num pos" style="font-size:16px">' + money(monthTotals.income) + '</div><div class="lbl">Entradas</div></div>' +
      '<div class="card"><div class="num neg" style="font-size:16px">' + money(monthTotals.expense) + '</div><div class="lbl">Saídas</div></div>' +
      '<div class="card"><div class="num" style="font-size:16px">' + money(monthTotals.balance) + '</div><div class="lbl">Saldo</div></div></div>';

    html += '<div class="year-row"><select id="cashYear">';
    years.forEach(function (y) { html += '<option' + (y === cashYear ? " selected" : "") + ">" + y + "</option>"; });
    html += '</select><select id="cashMonth">';
    MONTHS.forEach(function (name, i) {
      var mm = String(i + 1).padStart(2, "0");
      html += '<option value="' + mm + '"' + (mm === cashMonth ? " selected" : "") + ">" + name + "</option>";
    });
    html += "</select></div>";

    html += '<div class="seg">' +
      '<button type="button" data-cash-tab="mov"' + (cashTab === "mov" ? ' class="active"' : "") + ">Movimentos</button>" +
      '<button type="button" data-cash-tab="month"' + (cashTab === "month" ? ' class="active"' : "") + ">Mensal</button>" +
      '<button type="button" data-cash-tab="year"' + (cashTab === "year" ? ' class="active"' : "") + ">Anual</button></div>";

    html += '<div class="btn-row" style="margin-bottom:12px">' +
      '<button class="btn primary" data-cash-new="in">+ Entrada</button>' +
      '<button class="btn danger" data-cash-new="out">+ Saída</button></div>';

    if (cashTab === "mov") {
      var list = S.cashEntries().filter(function (c) { return S.inPeriod(c.date, cashYear, cashMonth); });
      html += '<div class="list">';
      if (!list.length) html += '<div class="empty">Nenhum lançamento neste mês.</div>';
      list.forEach(function (c) {
        var t = c.tournamentId ? S.getTournament(c.tournamentId) : null;
        html += '<div class="item"><div class="avatar">' + (c.type === "out" ? "S" : "E") + "</div>" +
          '<div class="meta"><strong>' + esc(c.description) + "</strong><span>" +
          dte(c.date) + " · " + S.cashLabel(c.category) + (t ? " · " + t.name : "") +
          (c.auto ? " · automático" : "") + "</span></div>" +
          '<span class="amt ' + c.type + '">' + (c.type === "out" ? "-" : "+") + money(c.amount) + "</span>";
        if (!c.auto) {
          html += '<div class="small-actions"><button class="btn" data-edit-c="' + c.id + '">Editar</button>' +
            '<button class="btn danger" data-del-c="' + c.id + '">Excluir</button></div>';
        }
        html += "</div>";
      });
      html += "</div>";
    } else if (cashTab === "month") {
      html += '<div class="card"><h3>Relatório mensal ' + MONTHS[Number(cashMonth) - 1] + "/" + cashYear + "</h3>" +
        '<div class="row"><span>Entradas</span><strong class="amt in">' + money(monthTotals.income) + "</strong></div>" +
        '<div class="row"><span>Saídas</span><strong class="amt out">' + money(monthTotals.expense) + "</strong></div>" +
        '<div class="row"><span>Saldo</span><strong>' + money(monthTotals.balance) + "</strong></div></div>";
      html += '<div class="card"><h3>Por categoria</h3>';
      var cats = S.cashByCategory(cashYear, cashMonth);
      if (!cats.length) html += '<div class="muted">Sem movimentos.</div>';
      var max = cats[0] ? cats[0].total : 1;
      cats.forEach(function (c) {
        html += '<div style="margin:10px 0"><div class="row"><span>' + (c.type === "out" ? "Saída" : "Entrada") + " · " + S.cashLabel(c.category) + "</span><strong>" + money(c.total) + "</strong></div>" +
          '<div class="bar"><i class="' + (c.type === "out" ? "out" : "") + '" style="width:' + Math.round(c.total / max * 100) + '%"></i></div></div>';
      });
      html += "</div>";
      html += '<div class="card"><h3>Ano ' + cashYear + " mês a mês</h3>";
      S.monthlyReport(cashYear).forEach(function (m, i) {
        html += '<div class="row" style="padding:6px 0"><span>' + MONTHS[i] + '</span><span class="muted">' +
          money(m.income) + " / " + money(m.expense) + "</span><strong>" + money(m.balance) + "</strong></div>";
      });
      html += '<div class="row" style="margin-top:8px"><span>Total ' + cashYear + "</span><strong>" + money(yearTotals.balance) + "</strong></div></div>";
    } else {
      html += '<div class="card"><h3>Relatório anual</h3>';
      var yearsRep = S.yearlyReport();
      if (!yearsRep.length) html += '<div class="muted">Sem dados.</div>';
      yearsRep.forEach(function (y) {
        html += '<div class="card" style="margin:8px 0"><strong>' + y.year + "</strong>" +
          '<div class="row"><span class="muted">Entradas</span><span class="amt in">' + money(y.income) + "</span></div>" +
          '<div class="row"><span class="muted">Saídas</span><span class="amt out">' + money(y.expense) + "</span></div>" +
          '<div class="row"><span class="muted">Saldo</span><strong>' + money(y.balance) + "</strong></div></div>";
      });
      html += '<div class="row"><span>Saldo geral</span><strong>' + money(allTotals.balance) + "</strong></div></div>";
    }

    $("view").innerHTML = html;
    $("cashYear").onchange = function () { cashYear = $("cashYear").value; render(); };
    $("cashMonth").onchange = function () { cashMonth = $("cashMonth").value; render(); };
  }

  /* ---------- CASH POT ---------- */
  function handForm() {
    if (!S.state().players.length) return toast("Cadastre um jogador primeiro");
    var pOpts = S.state().players.map(function (p) {
      return '<option value="' + p.id + '">' + esc(p.name) + "</option>";
    }).join("");
    var tOpts = '<option value="">Nenhum</option>' + S.state().tournaments.map(function (t) {
      return '<option value="' + t.id + '">' + esc(t.name) + "</option>";
    }).join("");
    var typeOpts = S.HAND_TYPES.map(function (h) {
      return '<option value="' + h.id + '">' + h.label + " · " + h.points + " pts</option>";
    }).join("");
    openModal("<h2>Registrar mão</h2><div class='form'>" +
      '<label>Mão<select id="hType">' + typeOpts + "</select></label>" +
      '<label>Jogador<select id="hPid">' + pOpts + "</select></label>" +
      '<label>Torneio (opcional)<select id="hTid">' + tOpts + "</select></label>" +
      field("Data", 'id="hDate" type="date" value="' + S.today() + '"') +
      field("Observação", 'id="hNote"') +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button>' +
      '<button class="btn primary" id="fSave">Salvar</button></div></div>');
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      try {
        S.addHand({ type: $("hType").value, playerId: $("hPid").value, tournamentId: $("hTid").value, date: $("hDate").value, note: $("hNote").value });
        closeModal(); toast("Mão registrada"); render();
      } catch (err) { toast(err.message); }
    };
  }

  function renderCashPot() {
    titles("Cash Pot", "Mãos especiais da temporada");
    var years = S.availableYears();
    if (years.indexOf(potYear) === -1) potYear = years[0] || String(new Date().getFullYear());
    var season = S.getSeason(potYear);
    var rank = S.cashPotRanking(potYear);
    var html = '<div class="year-row"><select id="potYear">';
    years.forEach(function (y) { html += '<option' + (y === potYear ? " selected" : "") + ">" + y + "</option>"; });
    html += "</select></div>";
    if (season) {
      var champ = S.getPlayer(season.championId);
      html += '<div class="champion-banner"><div class="crown">CAMPEÃO CASH POT ' + potYear + "</div><strong>" + S.displayName(champ) + "</strong>" +
        '<div class="muted">' + season.points + " pontos · fechado em " + dte(season.closedAt) + "</div></div>";
    }
    html += '<div class="card"><h3>Ranking do Cash Pot</h3>';
    if (!rank.length) html += '<div class="muted">Nenhuma mão registrada neste ano.</div>';
    var max = rank[0] ? rank[0].points : 1;
    rank.forEach(function (r, i) {
      html += '<div style="margin:10px 0"><div class="row"><span>' + (i + 1) + ". " + S.displayName(r.player) + "</span><strong>" + r.points + " pts</strong></div>" +
        '<div class="muted">RF ' + r.royal + " · SF " + r.straightflush + " · Q " + r.quads + " · P " + r.award + "</div>" +
        '<div class="bar"><i style="width:' + Math.round(r.points / max * 100) + '%"></i></div></div>';
    });
    html += "</div>";
    if (isAdmin()) {
      html += '<div class="btn-row" style="margin-bottom:12px">' +
        '<button class="btn primary" id="addHand">Registrar mão</button>' +
        (season
          ? '<button class="btn danger" id="reopenSeason">Reabrir temporada</button>'
          : '<button class="btn" id="closeSeason">Fechar temporada</button>') +
        "</div>";
    }
    html += '<div class="card"><h3>Registro de mãos</h3><div class="list">';
    var hands = S.handsByYear(potYear);
    if (!hands.length) html += '<div class="muted">Sem registros.</div>';
    hands.forEach(function (h) {
      var p = S.getPlayer(h.playerId);
      var t = h.tournamentId ? S.getTournament(h.tournamentId) : null;
      html += '<div class="item"><div class="avatar">' + h.points + '</div><div class="meta"><strong>' + esc(h.label) + "</strong><span>" +
        S.displayName(p) + " · " + dte(h.date) + (t ? " · " + t.name : "") + (h.note ? " · " + esc(h.note) : "") + "</span></div>" +
        (isAdmin() ? '<button class="btn danger" data-del-h="' + h.id + '">Excluir</button>' : "") + "</div>";
    });
    html += "</div></div>";
    $("view").innerHTML = html;
    $("potYear").onchange = function () { potYear = $("potYear").value; render(); };
    var add = $("addHand");
    if (add) add.onclick = handForm;
    var closeS = $("closeSeason");
    if (closeS) closeS.onclick = function () {
      if (!rank.length) return toast("Registre mãos antes de fechar");
      openModal("<h2>Fechar temporada " + potYear + "</h2><p>Campeão do Cash Pot: <strong>" + S.displayName(rank[0].player) + "</strong> · " + rank[0].points + " pts</p>" +
        '<div class="btn-row"><button class="btn ghost" id="cNo">Cancelar</button><button class="btn primary" id="cYes">Confirmar</button></div>');
      $("cNo").onclick = closeModal;
      $("cYes").onclick = function () {
        try { S.closeSeason(potYear); closeModal(); toast("Temporada fechada"); render(); }
        catch (err) { toast(err.message); }
      };
    };
    var reopen = $("reopenSeason");
    if (reopen) reopen.onclick = function () {
      S.reopenSeason(potYear); toast("Temporada reaberta"); render();
    };
  }

  /* ---------- CHAMPIONS ---------- */
  function renderChampions() {
    titles("Campeões", "Hall da fama");
    var years = S.availableYears();
    if (years.indexOf(yearFilter) === -1) yearFilter = years[0] || String(new Date().getFullYear());
    var html = '<div class="year-row"><select id="yearSel">';
    years.forEach(function (y) { html += '<option' + (y === yearFilter ? " selected" : "") + ">" + y + "</option>"; });
    html += '</select></div>';
    var ranking = S.titlesByPlayer(yearFilter);
    html += '<div class="card"><h3>Relatório anual ' + yearFilter + "</h3>";
    if (!ranking.length) html += '<div class="muted">Nenhum título neste ano.</div>';
    var max = ranking[0] ? ranking[0].titles : 1;
    ranking.forEach(function (r, i) {
      html += '<div style="margin:10px 0"><div class="row"><span>' + (i + 1) + ". " + S.displayName(r.player) + "</span><strong>" + r.titles + " título(s)</strong></div>" +
        '<div class="bar"><i style="width:' + Math.round(r.titles / max * 100) + '%"></i></div></div>';
    });
    html += "</div>";

    html += '<div class="card"><h3>Campeões do ano</h3>';
    var list = S.champions(yearFilter);
    if (!list.length) html += '<div class="muted">Sem campeões registrados.</div>';
    list.forEach(function (t) {
      var p = S.getPlayer(t.championId);
      html += '<div class="item"><div class="avatar">' + initials(p ? p.name : "?") + '</div><div class="meta"><strong>' + S.displayName(p) + "</strong>" +
        "<span>" + t.name + " · " + dte(t.date) + " · " + (t.entries || []).length + " jogadores · " + money(S.collected(t)) + "</span></div></div>";
    });
    html += "</div>";

    html += '<div class="card"><h3>Histórico de títulos por jogador</h3>';
    var all = S.titlesByPlayer();
    if (!all.length) html += '<div class="muted">Ainda não há títulos.</div>';
    all.forEach(function (r) {
      var hist = S.champions().filter(function (t) { return t.championId === r.playerId; });
      html += '<div class="item"><div class="avatar">' + initials(r.player ? r.player.name : "?") + '</div><div class="meta"><strong>' + S.displayName(r.player) + "</strong><span>" +
        r.titles + " título(s) · " + hist.map(function (t) { return t.name + " (" + dte(t.date) + ")"; }).join(" · ") + "</span></div></div>";
    });
    html += "</div>";
    $("view").innerHTML = html;
    $("yearSel").onchange = function () { yearFilter = $("yearSel").value; render(); };
  }

  /* ---------- BACKUP ---------- */
  function fillBackup(userList) {
    var sess = S.session();
    var st = typeof PokerCloud !== "undefined" ? PokerCloud.status() : {};
    var list = userList || S.users();
    var html = "<h2>Conta e backup</h2>";
    if (sess) html += '<p class="muted">' + esc(sess.name) + " · " + (sess.role === "admin" ? "Admin" : "Jogador") + "</p>";
    else {
      html += '<button class="btn primary block" id="loginBtn" style="margin-bottom:8px">Entrar</button>';
      html += '<button class="btn block" id="regUserBtn" style="margin-bottom:8px">Cadastrar usuário</button>';
      html += '<button class="btn ghost block" id="regAdminBtn" style="margin-bottom:8px">Sou administrador</button>';
    }
    html += '<p class="muted">' + cloudStatusLabel(st) + "</p>";
    if (!cloudOn()) {
      html += '<div class="cloud-error">SUPABASE ERROR: {code: CONFIG, message: POKER_SUPABASE_CONFIG ausente no build, details: js/supabase-config.js null, hint: Netlify env USER_SUPABASE_URL + USER_SUPABASE_ANON_KEY}</div>';
    } else if (st.error) {
      html += '<div class="cloud-error">' + esc(st.error) + "</div>";
    }
    if (isAdmin()) {
      html += '<h3 style="color:var(--gold);font-size:15px">Acessos</h3><div class="list">';
      if (!list.length) html += '<div class="muted">Nenhum acesso listado.</div>';
      list.forEach(function (u) {
        html += '<div class="item"><div class="meta"><strong>' + esc(u.name) + "</strong><span>" + (u.role === "admin" ? "Admin" : "Jogador") + "</span></div>" +
          '<div class="small-actions"><button class="btn" data-edit-u="' + u.id + '">Editar</button>' +
          (cloudOn() ? "" : '<button class="btn danger" data-del-u="' + u.id + '">Excluir</button>') + "</div></div>";
      });
      html += "</div>";
      if (!cloudOn()) html += '<button class="btn block" id="addUser" style="margin:8px 0">Novo acesso</button>';
      else html += '<p class="muted">Jogadores se cadastram no Início com nome e senha (Auth).</p>';
    } else if (sess && cloudOn()) {
      html += '<button class="btn block" id="claimAdminBtn" style="margin:8px 0">Sou administrador</button>';
    }
    html += '<button class="btn primary block" id="exp">Exportar backup</button>' +
      (isAdmin() ? '<button class="btn block" id="imp" style="margin-top:8px">Importar backup</button>' : "") +
      '<input id="impFile" type="file" accept="application/json" hidden>' +
      '<button class="btn block" id="cloudBtn" style="margin-top:8px">Banco online</button>' +
      '<button class="btn danger block" id="logoutBtn" style="margin-top:8px">Sair</button>' +
      '<button class="btn ghost block" id="fCancel" style="margin-top:8px">Fechar</button>';
    openModal(html);
    $("fCancel").onclick = closeModal;
    var loginBtn = $("loginBtn");
    if (loginBtn) loginBtn.onclick = function () { closeModal(); showLogin(); };
    var regAdminBtn = $("regAdminBtn");
    if (regAdminBtn) regAdminBtn.onclick = function () { closeModal(); showRegister("admin"); };
    var regUserBtn = $("regUserBtn");
    if (regUserBtn) regUserBtn.onclick = function () { closeModal(); showRegister("player"); };
    var addU = $("addUser");
    if (addU) addU.onclick = function () { closeModal(); userForm(null); };
    var claimBtn = $("claimAdminBtn");
    if (claimBtn) claimBtn.onclick = function () { closeModal(); showClaimAdmin(); };
    $("cloudBtn").onclick = function () { closeModal(); cloudSheet(); };
    $("logoutBtn").onclick = function () {
      S.logout();
      if (typeof PokerCloud !== "undefined") PokerCloud.signOut().catch(function () {});
      closeModal();
      render();
    };
    $("exp").onclick = function () {
      var blob = new Blob([S.exportData()], { type: "application/json" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "pokerclub-backup.json";
      a.click();
      toast("Backup exportado");
    };
    var imp = $("imp");
    if (imp) imp.onclick = function () { $("impFile").click(); };
    $("impFile").onchange = function () {
      var f = $("impFile").files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () {
        try { S.importData(String(reader.result)); closeModal(); toast("Backup importado"); render(); }
        catch (e) { toast(e.message || "Backup invalido"); }
      };
      reader.readAsText(f);
    };
  }

  function backupSheet() {
    if (cloudOn() && isAdmin() && PokerCloud.listProfiles) {
      PokerCloud.listProfiles().then(function (list) {
        S.setUsers(list);
        fillBackup(list);
      }).catch(function () { fillBackup(S.users()); });
      return;
    }
    fillBackup(S.users());
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c];
    });
  }

  function applyRole() {
    document.body.classList.toggle("role-player", !isAdmin());
    document.body.classList.toggle("role-admin", isAdmin());
    if (!isAdmin() && (view === "cash" || view === "payments")) view = "dashboard";
    updateSyncDot();
  }

  function updateSyncDot() {
    var el = $("syncDot");
    if (!el) return;
    var st = (typeof PokerCloud !== "undefined") ? PokerCloud.status() : null;
    el.className = "sync-dot";
    var pending = typeof PokerCloud !== "undefined" && PokerCloud.isConfigPending && PokerCloud.isConfigPending();
    if (pending) { el.classList.add("offline"); el.title = "Conectando nuvem"; }
    else if (!st || !st.ready) { el.classList.add("offline"); el.title = (st && st.error) || "Nuvem nao pronta"; }
    else if (st.online) { el.classList.add("online"); el.title = "Nuvem sincronizada"; }
    else { el.classList.add("offline"); el.title = st.error || "Nuvem offline"; }
  }

  function clearLoginGate() {
    var gate = $("loginGate");
    if (!gate) return;
    gate.hidden = true;
    gate.setAttribute("hidden", "hidden");
    gate.innerHTML = "";
  }

  function cloudOn() {
    return typeof PokerCloud !== "undefined" && PokerCloud.isConfigured && PokerCloud.isConfigured();
  }

  function cloudStatusLabel(st) {
    st = st || {};
    if (typeof PokerCloud !== "undefined" && PokerCloud.isConfigPending && PokerCloud.isConfigPending()) {
      return "Conectando banco (USER_SUPABASE_URL / USER_SUPABASE_ANON_KEY)";
    }
    if (st.ready && st.online) return "Nuvem conectada";
    if (st.ready) return st.error || "Nuvem offline";
    return st.error || "Aguardando USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY";
  }

  function ensureCloud() {
    if (typeof PokerCloud === "undefined") {
      return Promise.reject({ message: "SUPABASE ERROR: {code: CONFIG, message: PokerCloud ausente, details: js/cloud.js, hint: recarregue a pagina}" });
    }
    var wait = PokerCloud.waitConfig ? PokerCloud.waitConfig() : Promise.resolve();
    return wait.then(function () {
      PokerCloud.init();
      if (!PokerCloud.isConfigured()) {
        return Promise.reject(PokerCloud.configMissingError ? PokerCloud.configMissingError() : { message: "Supabase nao configurado" });
      }
      return true;
    });
  }

  function afterAuth(stay) {
    hideLogin(stay === true);
  }

  function authFail(btn, err) {
    if (btn) btn.disabled = false;
    toast((err && err.message) || "Falha no acesso");
  }

  function showLogin() {
    clearLoginGate();
    openModal("<h2>Entrar</h2>" +
      '<p class="muted">Use o nome e a senha cadastrados.</p>' +
      '<div class="form">' +
      field("Nome", 'id="lName"') +
      field("Senha", 'id="lPass" type="password"') +
      '<button class="btn primary block" id="lGo">Entrar</button>' +
      '<button class="btn ghost block" id="fCancel">Cancelar</button></div>');
    $("fCancel").onclick = closeModal;
    $("lGo").onclick = function () {
      var btn = $("lGo");
      if (btn.disabled) return;
      btn.disabled = true;
      var name = $("lName").value;
      var pass = $("lPass").value;
      ensureCloud().then(function () {
        return PokerCloud.signIn(name, pass);
      }).then(afterAuth).catch(function (err) { authFail(btn, err); });
    };
  }

  function showRegister(role) {
    clearLoginGate();
    var admin = role === "admin";
    openModal("<h2>" + (admin ? "Cadastrar administrador" : "Cadastrar usuário") + "</h2>" +
      '<p class="muted">' + (admin
        ? "Nome, senha e o código secreto do clube. Sem o código você entra como jogador."
        : "Só nome e senha. A senha fica no Auth, não no clube.") + "</p>" +
      '<div class="form">' +
      field("Nome", 'id="lName"') +
      field("Senha", 'id="lPass" type="password"') +
      (admin ? field("Código de administrador", 'id="lCode" type="password"') : "") +
      '<button class="btn primary block" id="lGo">' + (admin ? "Criar Admin" : "Criar usuário") + "</button>" +
      '<button class="btn ghost block" id="fCancel">Cancelar</button></div>');
    $("fCancel").onclick = closeModal;
    $("lGo").onclick = function () {
      var btn = $("lGo");
      if (btn.disabled) return;
      btn.disabled = true;
      var name = $("lName").value;
      var pass = $("lPass").value;
      var codeEl = $("lCode");
      var code = codeEl ? codeEl.value : "";
      ensureCloud().then(function () {
        return PokerCloud.signUp(name, pass, admin ? code : "");
      }).then(function (profile) {
        if (admin && profile && profile.role !== "admin") {
          toast("Código inválido ou já existe admin. Você entrou como jogador");
        }
        afterAuth();
      }).catch(function (err) { authFail(btn, err); });
    };
  }

  function showClaimAdmin() {
    openModal("<h2>Sou administrador</h2>" +
      '<p class="muted">Digite o código secreto do clube. Só vale uma vez, no primeiro admin.</p>' +
      '<div class="form">' +
      field("Código de administrador", 'id="lCode" type="password"') +
      '<button class="btn primary block" id="lGo">Ativar admin</button>' +
      '<button class="btn ghost block" id="fCancel">Cancelar</button></div>');
    $("fCancel").onclick = closeModal;
    $("lGo").onclick = function () {
      var btn = $("lGo");
      if (btn.disabled) return;
      btn.disabled = true;
      ensureCloud().then(function () {
        return PokerCloud.claimAdmin($("lCode").value);
      }).then(function (profile) {
        if (!profile || profile.role !== "admin") {
          authFail(btn, new Error("Não foi possível ativar o admin"));
          return;
        }
        toast("Você é o administrador");
        afterAuth();
      }).catch(function (err) { authFail(btn, err); });
    };
  }

  function hideLogin(stay) {
    clearLoginGate();
    closeModal();
    if (!stay) view = "dashboard";
    applyRole();
    startCloud();
    render();
  }

  function startCloud() {
    if (typeof PokerCloud === "undefined") { updateSyncDot(); return; }
    var go = function () {
      PokerCloud.init();
      if (!cloudBound) {
        cloudBound = true;
        PokerCloud.onStatus(function () { updateSyncDot(); if (view === "dashboard" || view === "players") render(); });
        S.subscribe(function (src) { if (src === "remote") { applyRole(); syncRoundAlert(); render(); syncPresentFromClock(); } });
      }
      PokerCloud.start();
      updateSyncDot();
      render();
    };
    if (PokerCloud.waitConfig) PokerCloud.waitConfig().then(go).catch(go);
    else go();
  }

  function cloudSheet() {
    var cfg = (typeof PokerCloud !== "undefined" && PokerCloud.getConfig()) || {};
    openModal("<h2>Banco online</h2><p class='muted'>Supabase sincroniza iPhone, Android e computador. Use só a Project URL e a chave anon (publishable). Nunca cole a service_role.</p>" +
      '<div class="form">' +
      field("Project URL", 'id="sbUrl" value="' + esc(cfg.url || "") + '" placeholder="https://xxxx.supabase.co"') +
      field("Anon / Publishable key", 'id="sbKey" value="' + esc(cfg.anonKey || "") + '"') +
      '<p class="muted">Clube: pokerclub (fixo para todos os aparelhos)</p>' +
      '<button class="btn primary block" id="fbSave">Salvar e conectar</button>' +
      '<button class="btn danger block" id="fbClear">Desconectar nuvem</button>' +
      '<button class="btn ghost block" id="fCancel">Fechar</button></div>');
    $("fCancel").onclick = closeModal;
    $("fbSave").onclick = function () {
      try {
        PokerCloud.setConfig({
          url: $("sbUrl").value.trim(),
          anonKey: $("sbKey").value.trim(),
          clubId: "pokerclub"
        });
        closeModal();
        startCloud();
        toast("Nuvem configurada");
      } catch (err) { toast(err.message); }
    };
    $("fbClear").onclick = function () {
      PokerCloud.clearConfig();
      closeModal();
      updateSyncDot();
      toast("Nuvem desconectada. Configure USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY no Netlify");
    };
  }

  function userForm(u) {
    var pOpts = '<option value="">Sem vínculo</option>' + S.state().players.map(function (p) {
      return '<option value="' + p.id + '"' + (u && u.playerId === p.id ? " selected" : "") + ">" + esc(p.name) + "</option>";
    }).join("");
    var passField = cloudOn() ? "" : field("Senha" + (u ? " (em branco = manter)" : ""), 'id="uPass" type="password"');
    openModal("<h2>" + (u ? "Editar acesso" : "Novo acesso") + "</h2><div class='form'>" +
      field("Nome", 'id="uName" value="' + (u ? esc(u.name) : "") + '"') +
      passField +
      '<label>Nível<select id="uRole">' +
      '<option value="player"' + (!u || u.role === "player" ? " selected" : "") + ">Jogador</option>" +
      '<option value="admin"' + (u && u.role === "admin" ? " selected" : "") + ">Admin</option></select></label>" +
      '<label>Jogador vinculado<select id="uPid">' + pOpts + "</select></label>" +
      '<div class="btn-row"><button class="btn ghost" id="fCancel">Cancelar</button>' +
      '<button class="btn primary" id="fSave">Salvar</button></div></div>');
    $("fCancel").onclick = closeModal;
    $("fSave").onclick = function () {
      var payload = { name: $("uName").value, role: $("uRole").value, playerId: $("uPid").value };
      var passEl = $("uPass");
      if (passEl) payload.password = passEl.value;
      if (cloudOn() && u && PokerCloud.updateProfile) {
        PokerCloud.updateProfile(u.id, payload).then(function () {
          closeModal(); toast("Acesso salvo"); render();
        }).catch(function (err) { toast(err.message); });
        return;
      }
      try {
        if (u) S.updateUser(u.id, payload);
        else S.registerUser(payload);
        closeModal(); toast("Acesso salvo"); render();
      } catch (err) { toast(err.message); }
    };
  }

  function render() {
    clearLoginGate();
    applyRole();
    if (view === "dashboard") renderDashboard();
    else if (view === "players") renderPlayers();
    else if (view === "tournaments") renderTournaments();
    else if (view === "timer") renderTimer();
    else if (view === "payments") renderPayments();
    else if (view === "cash") renderCash();
    else if (view === "cashpot") renderCashPot();
    else if (view === "champions") renderChampions();
    if (presentMode) enterPresent({ fullscreen: false });
  }

  function onClick(e) {
    var el = e.target.closest("[data-view],[data-go],[data-open-t],[data-edit-p],[data-del-p],[data-edit-t],[data-del-t],[data-pick],[data-start],[data-elim],[data-undo],[data-champ],[data-pay],[data-unpay],[data-hist],[data-back-t],[data-cash-tab],[data-cash-new],[data-edit-c],[data-del-c],[data-edit-u],[data-del-u],[data-del-h],#addPlayer,#addT,#btnBackup,#cloudFixBtn");
    if (!el) return;
    function needAdmin() {
      if (isAdmin()) return true;
      toast("Apenas o admin pode alterar");
      return false;
    }
    if (el.id === "cloudFixBtn") return cloudSheet();
    if (el.id === "addPlayer") { if (!needAdmin()) return; return playerForm(null); }
    if (el.id === "addT") { if (!needAdmin()) return; return tournamentForm(null); }
    if (el.id === "btnBackup") return backupSheet();
    if (el.hasAttribute("data-view")) {
      var next = el.getAttribute("data-view");
      if (!isAdmin() && (next === "cash" || next === "payments")) return toast("Acesso restrito ao admin");
      return setView(next);
    }
    if (el.hasAttribute("data-go")) {
      var go = el.getAttribute("data-go");
      if (!isAdmin() && (go === "cash" || go === "payments")) return toast("Acesso restrito ao admin");
      return setView(go);
    }
    if (el.hasAttribute("data-open-t")) { selectedTournamentId = el.getAttribute("data-open-t"); setView("tournaments"); return; }
    if (el.hasAttribute("data-back-t")) { selectedTournamentId = ""; render(); return; }
    if (el.hasAttribute("data-edit-p")) { if (!needAdmin()) return; return playerForm(S.getPlayer(el.getAttribute("data-edit-p"))); }
    if (el.hasAttribute("data-del-p")) {
      if (!needAdmin()) return;
      var id = el.getAttribute("data-del-p");
      return confirmBox("Excluir este jogador?", function () {
        if (!cloudOn() || !PokerCloud.removePlayer) {
          var missingDel = (typeof PokerCloud !== "undefined" && PokerCloud.configMissingError)
            ? PokerCloud.configMissingError()
            : { message: "SUPABASE ERROR: {code: CONFIG, message: POKER_SUPABASE_CONFIG ausente no build, details: n/a, hint: Netlify env}" };
          console.error("Supabase nao configurado: exclusao de jogador bloqueada", missingDel);
          toast(missingDel.message);
          return;
        }
        PokerCloud.removePlayer(id).then(function () {
          return PokerCloud.fetchPlayers();
        }).then(function (rows) {
          S.replacePlayers(rows);
          toast("Jogador excluído");
          render();
        }).catch(function (err) {
          console.error("Falha ao excluir jogador no Supabase", err);
          toast(supabaseErrorText(err, "DELETE public.players falhou"));
        });
      });
    }
    if (el.hasAttribute("data-edit-t")) { if (!needAdmin()) return; return tournamentForm(S.getTournament(el.getAttribute("data-edit-t"))); }
    if (el.hasAttribute("data-del-t")) {
      if (!needAdmin()) return;
      var tid = el.getAttribute("data-del-t");
      e.stopPropagation();
      return confirmBox("Excluir este torneio e seus pagamentos?", function () {
        if (selectedTournamentId === tid) selectedTournamentId = "";
        S.deleteTournament(tid); toast("Torneio excluido"); render();
      });
    }
    if (el.hasAttribute("data-pick")) { if (!needAdmin()) return; return pickPlayers(S.getTournament(el.getAttribute("data-pick"))); }
    if (el.hasAttribute("data-start")) {
      if (!needAdmin()) return;
      try { S.startTournament(el.getAttribute("data-start")); toast("Torneio iniciado"); render(); }
      catch (err) { toast(err.message); }
      return;
    }
    var t = S.getTournament(selectedTournamentId) || S.liveTournament();
    if (el.hasAttribute("data-elim") && t) {
      if (!needAdmin()) return;
      var elimId = el.getAttribute("data-elim");
      var before = S.getTournament(t.id);
      var active = (before.entries || []).filter(function (x) { return !x.eliminated; });
      if (active.length === 2) {
        var other = active.find(function (x) { return x.playerId !== elimId; });
        return finishConfirm(before, other.playerId);
      }
      S.eliminatePlayer(t.id, elimId);
      toast("Jogador eliminado");
      render();
      return;
    }
    if (el.hasAttribute("data-undo") && t) { if (!needAdmin()) return; S.undoEliminate(t.id, el.getAttribute("data-undo")); render(); return; }
    if (el.hasAttribute("data-champ") && t) { if (!needAdmin()) return; return finishConfirm(t, el.getAttribute("data-champ")); }
    if (el.hasAttribute("data-pay") && t) { if (!needAdmin()) return; return payPrompt(t, el.getAttribute("data-pay")); }
    if (el.hasAttribute("data-unpay") && t) { if (!needAdmin()) return; S.markPending(t.id, el.getAttribute("data-unpay")); render(); return; }
    if (el.hasAttribute("data-hist")) return playerHistory(el.getAttribute("data-hist"));
    if (el.hasAttribute("data-cash-tab")) { cashTab = el.getAttribute("data-cash-tab"); render(); return; }
    if (el.hasAttribute("data-cash-new")) { if (!needAdmin()) return; return cashForm(null, el.getAttribute("data-cash-new")); }
    if (el.hasAttribute("data-edit-c")) { if (!needAdmin()) return; return cashForm(S.getCash(el.getAttribute("data-edit-c"))); }
    if (el.hasAttribute("data-del-c")) {
      if (!needAdmin()) return;
      var cid = el.getAttribute("data-del-c");
      return confirmBox("Excluir este lançamento?", function () { S.deleteCash(cid); toast("Lançamento excluído"); render(); });
    }
    if (el.hasAttribute("data-edit-u")) { if (!needAdmin()) return; closeModal(); return userForm(S.users().find(function (u) { return u.id === el.getAttribute("data-edit-u"); })); }
    if (el.hasAttribute("data-del-h")) {
      if (!needAdmin()) return;
      var hid = el.getAttribute("data-del-h");
      return confirmBox("Excluir esta mão?", function () { S.deleteHand(hid); toast("Mão excluída"); render(); });
    }
    if (el.hasAttribute("data-del-u")) {
      if (!needAdmin()) return;
      var uid = el.getAttribute("data-del-u");
      return confirmBox("Excluir este acesso?", function () {
        try { S.deleteUser(uid); toast("Acesso excluído"); closeModal(); backupSheet(); }
        catch (err) { toast(err.message); }
      });
    }
  }

  function boot() {
    S = window.PokerStore;
    if (!S) {
      var s = document.createElement("script");
      s.src = "js/store.js";
      s.onload = boot;
      document.head.appendChild(s);
      return;
    }
    document.addEventListener("click", onClick);
    var clockBtn = $("alertClock");
    if (clockBtn) {
      var onClock = function (e) {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        goCronometro();
      };
      clockBtn.addEventListener("click", onClock);
      clockBtn.addEventListener("pointerup", onClock);
      clockBtn.addEventListener("touchend", onClock, { passive: false });
    }
    var nextBtn = $("alertNext");
    if (nextBtn) {
      nextBtn.addEventListener("click", function (e) {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        if (!isAdmin()) return;
        var ended = endedTournament();
        if (!ended) return;
        var last = ended.currentLevel >= ended.levels.length - 1;
        if (last) S.ackRoundEnd(ended.id);
        else S.confirmNextRound(ended.id);
        lastAlertKey = "";
        roundAlertClosed = false;
        writeClosedAlert("");
        hideRoundAlert();
        render();
      });
    }
    var presentExit = $("presentExit");
    if (presentExit) presentExit.onclick = function () {
      userDismissedPresent = true;
      leavePresent();
    };
    bindPresentControls();
    document.addEventListener("fullscreenchange", function () {
      if (!document.fullscreenElement && presentMode && userDismissedPresent) leavePresent();
    });
    S.loadSession();
    clearLoginGate();
    var closed = readClosedAlert();
    if (closed) {
      roundAlertClosed = true;
      lastAlertKey = closed;
    }
    S.state().tournaments.forEach(function (t) {
      if (t.timerRunning) S.tickTimer(t.id);
    });
    if (S.getClock().timerRunning) S.tickClock();
    startLoop();
    startCloud();
    setView("dashboard");
    function resumeTimers() {
      S.state().tournaments.forEach(function (t) {
        if (t.timerRunning) S.tickTimer(t.id);
      });
      if (S.getClock().timerRunning) S.tickClock();
      tick();
    }
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) {
        if (typeof PokerCloud !== "undefined" && PokerCloud.syncNow) PokerCloud.syncNow();
        resumeTimers();
      }
    });
    window.addEventListener("pageshow", resumeTimers);
    window.addEventListener("focus", resumeTimers);
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("sw.js").catch(function () {});
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
