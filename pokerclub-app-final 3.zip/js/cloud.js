(function (global) {
  var CFG_KEY = "pokerclub_supabase_cfg";
  var client = null;
  var channel = null;
  var pushing = false;
  var lastRemote = 0;
  var lastPushAt = 0;
  var status = { ready: false, online: false, error: "", clubId: "", role: "", userId: "" };
  var listeners = [];
  var timer = null;
  var started = false;
  var onRemoteFn = null;
  var clubSynced = false;
  var configPending = true;

  function storage() {
    try { return localStorage; } catch (e) { return null; }
  }

  function looksLikeServiceRole(key) {
    if (!key) return false;
    if (/service_role/i.test(key)) return true;
    try {
      var parts = String(key).split(".");
      if (parts.length < 2) return false;
      var json = parts[1].replace(/-/g, "+").replace(/_/g, "/");
      while (json.length % 4) json += "=";
      var payload = JSON.parse(atob(json));
      return payload && (payload.role === "service_role" || payload.role === "supabase_admin");
    } catch (e) {
      return false;
    }
  }

  var CLUB_ID = "pokerclub";

  function normalizeConfig(cfg) {
    if (!cfg) return null;
    var url = String(cfg.url || cfg.supabaseUrl || "").trim().replace(/\/+$/, "");
    var anonKey = String(cfg.anonKey || cfg.anon_key || cfg.publishableKey || cfg.key || "").trim();
    if (!url || !anonKey) return null;
    return { url: url, anonKey: anonKey, clubId: CLUB_ID };
  }

  function getConfig() {
    var published = normalizeConfig(global.POKER_SUPABASE_CONFIG);
    if (published) return published;
    try {
      var raw = storage() && storage().getItem(CFG_KEY);
      if (raw) {
        var cfg = normalizeConfig(JSON.parse(raw));
        if (cfg) return cfg;
      }
    } catch (e) {}
    return null;
  }

  function waitConfig() {
    var p = global.__pokerSupabaseConfigPromise;
    if (!p || typeof p.then !== "function") {
      configPending = false;
      return Promise.resolve(getConfig());
    }
    return p.then(function (cfg) {
      var n = normalizeConfig(cfg) || getConfig();
      if (n) {
        global.POKER_SUPABASE_CONFIG = n;
        client = null;
      }
      configPending = false;
      return n || getConfig();
    }).catch(function () {
      configPending = false;
      return getConfig();
    });
  }

  function isConfigured() {
    return !!getConfig();
  }

  function isConfigPending() {
    return configPending && !getConfig();
  }

  function setConfig(cfg) {
    var next = normalizeConfig(cfg);
    if (!next) throw new Error("Informe a Project URL e a chave anon (publishable)");
    if (!/^https:\/\//i.test(next.url)) throw new Error("A Project URL deve comecar com https://");
    if (looksLikeServiceRole(next.anonKey)) {
      throw new Error("Nao use a service_role. Cole apenas a chave anon / publishable");
    }
    storage() && storage().setItem(CFG_KEY, JSON.stringify(next));
    client = null;
    status.clubId = next.clubId;
    return next;
  }

  function clearConfig() {
    storage() && storage().removeItem(CFG_KEY);
    stop();
    client = null;
    status.online = false;
    status.ready = false;
    status.clubId = "";
    status.error = "";
    status.role = "";
    status.userId = "";
    emit();
  }

  function emit() {
    listeners.forEach(function (fn) { try { fn(status); } catch (e) {} });
  }

  function onStatus(fn) {
    listeners.push(fn);
    return function () { listeners = listeners.filter(function (x) { return x !== fn; }); };
  }

  function supabaseOk() {
    return !!(global.supabase && global.supabase.createClient);
  }

  function init() {
    var cfg = getConfig();
    status.clubId = cfg && cfg.clubId ? cfg.clubId : "";
    if (!cfg) {
      status.ready = false;
      status.online = false;
      status.error = configPending ? "" : configMissingError().message;
      emit();
      return false;
    }
    if (looksLikeServiceRole(cfg.anonKey)) {
      status.ready = false;
      status.error = "Chave service_role recusada. Use a anon key";
      emit();
      return false;
    }
    if (!supabaseOk()) {
      status.error = "Cliente Supabase nao carregou";
      emit();
      return false;
    }
    try {
      if (!client) {
        client = global.supabase.createClient(cfg.url, cfg.anonKey, {
          auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
          realtime: { params: { eventsPerSecond: 10 } }
        });
      }
      status.ready = true;
      status.error = "";
      emit();
      return true;
    } catch (e) {
      status.error = e.message || "Falha ao iniciar Supabase";
      emit();
      return false;
    }
  }

  function emailFromName(name) {
    var slug = String(name || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, ".").replace(/^\.+|\.+$/g, "") || "user";
    return slug + "@pokerclub.app";
  }

  function sessionUser() {
    return global.PokerStore && PokerStore.session ? PokerStore.session() : null;
  }

  function isAdmin() {
    var s = sessionUser();
    return !!(s && s.role === "admin");
  }

  function isSignedIn() {
    var s = sessionUser();
    return !!(s && s.id);
  }

  function applyProfile(profile, authUser) {
    var sess = {
      id: (profile && profile.id) || (authUser && authUser.id) || "",
      email: (authUser && authUser.email) || "",
      name: (profile && profile.name) || (authUser && authUser.user_metadata && authUser.user_metadata.name) || "",
      role: profile && profile.role === "admin" ? "admin" : "player",
      playerId: (profile && (profile.player_id || profile.playerId)) || ""
    };
    status.role = sess.role;
    status.userId = sess.id;
    if (global.PokerStore && PokerStore.setSession) PokerStore.setSession(sess);
    emit();
    return sess;
  }

  function loadProfile() {
    if (!client) return Promise.resolve(null);
    return client.auth.getUser().then(function (res) {
      if (res.error || !res.data || !res.data.user) return null;
      var user = res.data.user;
      return client.from("profiles").select("id, club_id, name, role, player_id").eq("id", user.id).maybeSingle()
        .then(function (p) {
          if (p.error) throw p.error;
          var profile = p.data;
          if (!profile) {
            var cfg = getConfig() || {};
            var name = (user.user_metadata && user.user_metadata.name) || String(user.email || "").split("@")[0];
            return client.from("profiles").insert({
              id: user.id,
              club_id: CLUB_ID,
              name: name,
              role: "player"
            }).select("id, club_id, name, role, player_id").maybeSingle()
              .then(function (ins) {
                profile = ins.data || { id: user.id, name: name, role: "player", player_id: "" };
                applyProfile(profile, user);
                return profile;
              });
          }
          applyProfile(profile, user);
          return profile;
        });
    });
  }

  function restoreSession() {
    if (!client) return Promise.resolve(null);
    return client.auth.getSession().then(function (res) {
      var session = res.data && res.data.session;
      if (!session) return null;
      return loadProfile();
    }).catch(function () { return null; });
  }

  function payloadFromState(state) {
    return {
      tournaments: state.tournaments || [],
      payments: state.payments || [],
      cash: state.cash || [],
      hands: state.hands || [],
      seasons: state.seasons || [],
      clock: state.clock || null,
      updatedAt: Date.now(),
      updatedBy: (sessionUser() && (sessionUser().name || sessionUser().email)) || "local"
    };
  }

  function applyRemote(data, players) {
    if (!global.PokerStore) return;
    if (!data) return;
    lastRemote = data.updatedAt || Date.now();
    var patch = {
      tournaments: data.tournaments || [],
      payments: data.payments || [],
      cash: data.cash || [],
      hands: data.hands || [],
      seasons: data.seasons || [],
      clock: data.clock || null
    };
    if (Array.isArray(players)) patch.players = players;
    PokerStore.applyRemote(patch);
  }

  function mapPlayerRow(row) {
    if (!row) return null;
    return {
      id: row.id,
      name: row.name || "",
      nickname: row.nickname || "",
      phone: row.phone || "",
      createdAt: row.created_at || row.createdAt || ""
    };
  }

  function applyPlayerChange(event, row, oldRow) {
    if (!global.PokerStore || !PokerStore.applyPlayerChange) return;
    PokerStore.applyPlayerChange(event, mapPlayerRow(row), mapPlayerRow(oldRow));
  }

  function formatCloudError(err, context) {
    var e = err || {};
    var code = e.code || e.status || e.statusCode || e.name || "";
    var message = e.message || (typeof err === "string" ? err : "erro desconhecido");
    var details = e.details || e.error_description || e.error || "";
    if (details && typeof details !== "string") details = JSON.stringify(details);
    var hint = e.hint || "";
    var text = "SUPABASE ERROR: {code: " + (code || "n/a") + ", message: " + message + ", details: " + (details || "n/a") + ", hint: " + (hint || "n/a") + "}";
    if (context) text = context + " — " + text;
    var out = new Error(text);
    out.code = code;
    out.details = details;
    out.hint = hint;
    return out;
  }

  function configMissingError() {
    return formatCloudError({
      code: "CONFIG",
      message: "POKER_SUPABASE_CONFIG ausente no build",
      details: "js/supabase-config.js esta null. O Netlify publicou o app sem USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY.",
      hint: "Netlify > Site configuration > Environment variables > Redeploy"
    }, "config");
  }

  function requireOnline() {
    return waitConfig().then(function () {
    var cfg = getConfig();
    if (!cfg) return Promise.reject(configMissingError());
    if (!init()) {
      return Promise.reject(formatCloudError({
        code: "INIT",
        message: status.error || "Falha ao iniciar o cliente Supabase",
        details: "createClient nao executou",
        hint: "Confira USER_SUPABASE_URL (https://xxxx.supabase.co) e a anon key no build"
      }, "init"));
    }
    if (!client) {
      return Promise.reject(formatCloudError({
        code: "CLIENT",
        message: "Cliente Supabase nao inicializado",
        details: "window.supabase.createClient indisponivel ou config invalida",
        hint: "Recarregue a pagina apos um build com env"
      }, "init"));
    }
    return client.auth.getSession().then(function (res) {
      if (res.error) throw formatCloudError(res.error, "auth.getSession");
      if (!res.data || !res.data.session) {
        throw formatCloudError({
          code: "AUTH",
          message: "sem sessao autenticada no Supabase Auth",
          details: "SELECT/INSERT em public.players exige JWT authenticated + is_club_member(pokerclub)",
          hint: "Sair e entrar com nome e senha do Auth. Login so local nao grava no banco."
        }, "auth.getSession");
      }
      return cfg;
    }).catch(function (err) {
      if (err && String(err.message || "").indexOf("SUPABASE ERROR") >= 0) throw err;
      throw formatCloudError(err, "auth.getSession");
    });
    });
  }

  function fetchPlayers() {
    return requireOnline().then(function () {
      return client.from("players").select("*").eq("club_id", CLUB_ID)
        .then(function (res) {
          if (res.error) {
            console.error("fetchPlayers", res.error);
            throw formatCloudError(res.error, "SELECT public.players");
          }
          return (res.data || []).map(mapPlayerRow);
        });
    });
  }

  function upsertPlayer(player) {
    if (!player || !player.id) {
      return Promise.reject(formatCloudError({
        code: "PLAYER",
        message: "jogador sem id",
        details: "upsertPlayer recebeu payload invalido",
        hint: "informe nome completo"
      }, "UPSERT public.players"));
    }
    return requireOnline().then(function () {
      var row = {
        id: player.id,
        club_id: CLUB_ID,
        name: player.name || "",
        nickname: player.nickname || "",
        phone: player.phone || "",
        created_at: player.createdAt || ""
      };
      return client.from("players").upsert(row, { onConflict: "club_id,id" }).then(function (res) {
        if (res.error) {
          console.error("upsertPlayer", res.error);
          markPushResult(res);
          throw formatCloudError(res.error, "UPSERT public.players club_id=" + CLUB_ID);
        }
        markPushResult(res);
        return player;
      });
    });
  }

  function removePlayer(id) {
    if (!id) {
      return Promise.reject(formatCloudError({
        code: "PLAYER",
        message: "id vazio",
        details: "removePlayer sem id",
        hint: ""
      }, "DELETE public.players"));
    }
    return requireOnline().then(function () {
      return client.from("players").delete().eq("club_id", CLUB_ID).eq("id", id).then(function (res) {
        if (res.error) {
          console.error("removePlayer", res.error);
          markPushResult(res);
          throw formatCloudError(res.error, "DELETE public.players");
        }
        markPushResult(res);
        return true;
      });
    });
  }

  function stop() {
    if (channel && client) {
      try { client.removeChannel(channel); } catch (e) {}
    }
    channel = null;
    started = false;
    clubSynced = false;
  }

  function fetchClub() {
    var cfg = getConfig();
    if (!client || !cfg) return Promise.resolve(null);
    return client.from("clubs").select("payload, updated_at, updated_by").eq("id", cfg.clubId).maybeSingle();
  }

  function subscribeRealtime(cfg) {
    if (!client) return;
    if (channel) {
      try { client.removeChannel(channel); } catch (e) {}
      channel = null;
    }
    channel = client.channel("club-" + cfg.clubId)
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "clubs",
        filter: "id=eq." + cfg.clubId
      }, function (payload) {
        status.online = true;
        status.error = "";
        emit();
        if (pushing) return;
        var row = payload.new || {};
        var data = row.payload || {};
        if (data.updatedAt && data.updatedAt === lastRemote) return;
        if (data.updatedAt && data.updatedAt === lastPushAt) return;
        clubSynced = true;
        applyRemote(data);
        if (onRemoteFn) onRemoteFn(data);
      })
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "players",
        filter: "club_id=eq." + CLUB_ID
      }, function (payload) {
        status.online = true;
        status.error = "";
        emit();
        applyPlayerChange(payload.eventType || payload.event, payload.new, payload.old);
      })
      .subscribe(function (ev) {
        if (ev === "SUBSCRIBED") {
          status.online = true;
          status.error = "";
          emit();
        } else if (ev === "CHANNEL_ERROR" || ev === "TIMED_OUT") {
          status.online = false;
          status.error = "Realtime offline";
          emit();
        }
      });
  }

  function syncNow() {
    var cfg = getConfig();
    if (!client || !cfg) return Promise.resolve();
    var remote = {};
    return fetchClub().then(function (res) {
      if (res && res.error) {
        status.online = false;
        status.error = formatCloudError(res.error, "SELECT public.clubs").message;
        emit();
      } else if (res) {
        status.online = true;
        status.error = "";
        emit();
        clubSynced = true;
        remote = (res.data && res.data.payload) || {};
        applyRemote(remote);
      }
      return fetchPlayers().then(function (rows) {
        status.online = true;
        status.error = "";
        emit();
        if (global.PokerStore && PokerStore.replacePlayers) PokerStore.replacePlayers(rows);
        if (onRemoteFn) onRemoteFn(remote);
        return rows;
      });
    }).catch(function (err) {
      return fetchPlayers().then(function (rows) {
        status.online = true;
        status.error = "";
        emit();
        if (global.PokerStore && PokerStore.replacePlayers) PokerStore.replacePlayers(rows);
        return rows;
      }).catch(function (err2) {
        status.online = false;
        status.error = (err2 && err2.message) || (err && err.message) || "Sync offline";
        emit();
      });
    });
  }

  function start(onRemote) {
    stop();
    onRemoteFn = onRemote || onRemoteFn;
    started = true;
    waitConfig().then(function () {
    if (!init()) return;
    var cfg = getConfig();
    restoreSession().then(function (profile) {
      if (!started) return;
      if (!profile) {
        status.online = false;
        status.error = formatCloudError({
          code: "AUTH",
          message: "sem sessao autenticada no Supabase Auth",
          details: "SELECT/INSERT em public.players exigem JWT. Nuvem configurada: USER_SUPABASE_URL + USER_SUPABASE_ANON_KEY.",
          hint: "Entre com nome e senha. Nao use modo local."
        }, "auth.getSession").message;
        emit();
        return;
      }
      subscribeRealtime(cfg);
      return syncNow();
    });
    });
  }

  function markPushResult(res, err) {
    if (err || (res && res.error)) {
      var raw = err || (res && res.error);
      status.error = formatCloudError(raw, "nuvem").message;
      status.online = false;
    } else {
      status.online = true;
      status.error = "";
    }
    emit();
  }

  function pushClock(clock) {
    if (!status.ready || !isSignedIn()) return Promise.resolve();
    var cfg = getConfig();
    if (!client || !cfg) return Promise.resolve();
    var c = clock || {};
    pushing = true;
    lastPushAt = Date.now();
    lastRemote = lastPushAt;
    return client.rpc("set_club_clock", {
      p_club: cfg.clubId,
      p_remaining: Math.round(Number(c.remainingSec) || 0),
      p_duration: Math.round(Number(c.durationSec) || 600),
      p_running: !!c.timerRunning,
      p_updated_at: c.timerUpdatedAt == null ? null : Number(c.timerUpdatedAt),
      p_paused: !!c.paused,
      p_start_at: c.startAt == null ? null : Number(c.startAt),
      p_end_at: c.endAt == null ? null : Number(c.endAt),
      p_cycle_id: c.cycleId || "",
      p_status: c.status || ""
    }).then(function (res) {
      markPushResult(res);
    }).catch(function (err) {
      markPushResult(null, err);
    }).then(function () {
      pushing = false;
    });
  }

  function upsertClubPayload(body, cfg) {
    return client.from("clubs").upsert({
      id: cfg.clubId,
      name: "Poker Club",
      payload: body,
      updated_at: new Date().toISOString(),
      updated_by: body.updatedBy
    }, { onConflict: "id" });
  }

  function pushState(state) {
    if (!status.ready || !isSignedIn()) return Promise.resolve();
    var cfg = getConfig();
    if (!client || !cfg) return Promise.resolve();
    if (!clubSynced && !isAdmin()) return pushClock(state && state.clock);
    pushing = true;
    var body = payloadFromState(state);
    lastRemote = body.updatedAt;
    lastPushAt = body.updatedAt;
    return client.rpc("set_club_payload", {
      p_club: cfg.clubId,
      p_payload: body
    }).then(function (res) {
      if (res && res.error) {
        if (isAdmin()) return upsertClubPayload(body, cfg).then(function (up) { markPushResult(up); });
        markPushResult(res);
        return;
      }
      markPushResult(res);
    }).catch(function (err) {
      if (isAdmin()) {
        return upsertClubPayload(body, cfg).then(function (up) { markPushResult(up); }).catch(function (e2) {
          markPushResult(null, e2);
        });
      }
      markPushResult(null, err);
    }).then(function () {
      pushing = false;
    });
  }

  function schedulePush(state) {
    if (!status.ready || !isSignedIn()) return;
    clearTimeout(timer);
    timer = setTimeout(function () {
      pushClock(state && state.clock);
      if (clubSynced || isAdmin()) pushState(state);
    }, 250);
  }

  function authError(err) {
    var msg = (err && err.message) || "Falha na autenticacao";
    if (/email not confirmed/i.test(msg)) {
      return new Error("Desative a confirmacao de e-mail no Supabase (Authentication > Providers > Email)");
    }
    if (/invalid login/i.test(msg) || /invalid credentials/i.test(msg)) {
      return new Error("Nome ou senha incorretos");
    }
    if (/already registered/i.test(msg) || /user already/i.test(msg)) {
      return new Error("Nome ja cadastrado. Use Entrar");
    }
    if (/codigo de administrador/i.test(msg) || /admin_setup/i.test(msg) || /Ja existe administrador/i.test(msg) || /invalido/i.test(msg)) {
      return new Error(msg);
    }
    return err instanceof Error ? err : new Error(msg);
  }

  function signUp(name, password, adminCode) {
    return waitConfig().then(function () {
    if (!getConfig()) return Promise.reject(configMissingError());
    if (!init()) return Promise.reject(formatCloudError({
      code: "INIT",
      message: status.error || "Falha ao iniciar o cliente Supabase",
      details: "",
      hint: "Confira USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY no build da Netlify"
    }, "signUp"));
    var cfg = getConfig();
    var userName = String(name || "").trim();
    if (!userName) return Promise.reject(new Error("Informe o nome"));
    if (!password || String(password).length < 4) return Promise.reject(new Error("Senha minima de 4 caracteres"));
    var email = emailFromName(userName);
    return client.auth.signUp({
      email: email,
      password: String(password),
      options: { data: { name: userName, club_id: cfg.clubId } }
    }).then(function (res) {
      if (res.error) throw authError(res.error);
      if (!res.data || !res.data.session) {
        return client.auth.signInWithPassword({ email: email, password: String(password) }).then(function (inn) {
          if (inn.error) throw authError(inn.error);
          return inn;
        });
      }
      return res;
    }).then(function () {
      return loadProfile();
    }).then(function (profile) {
      if (adminCode && String(adminCode).trim()) return claimAdmin(adminCode);
      start(onRemoteFn);
      return profile;
    });
    });
  }

  function claimAdmin(code) {
    return waitConfig().then(function () {
    if (!getConfig()) return Promise.reject(configMissingError());
    if (!init()) return Promise.reject(formatCloudError({
      code: "INIT",
      message: status.error || "Falha ao iniciar o cliente Supabase",
      details: "",
      hint: "Confira USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY no build da Netlify"
    }, "claimAdmin"));
    var cfg = getConfig();
    if (!code || !String(code).trim()) return Promise.reject(new Error("Informe o codigo de administrador"));
    return client.rpc("claim_club_admin", { p_club: cfg.clubId, p_code: String(code).trim() }).then(function (res) {
      if (res.error) throw authError(res.error);
      return loadProfile();
    }).then(function (profile) {
      start(onRemoteFn);
      return profile;
    });
    });
  }

  function signIn(name, password) {
    return waitConfig().then(function () {
    if (!getConfig()) return Promise.reject(configMissingError());
    if (!init()) return Promise.reject(formatCloudError({
      code: "INIT",
      message: status.error || "Falha ao iniciar o cliente Supabase",
      details: "",
      hint: "Confira USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY no build da Netlify"
    }, "signIn"));
    var userName = String(name || "").trim();
    if (!userName) return Promise.reject(new Error("Informe o nome"));
    if (!password) return Promise.reject(new Error("Informe a senha"));
    var email = emailFromName(userName);
    return client.auth.signInWithPassword({ email: email, password: String(password) }).then(function (res) {
      if (res.error) throw authError(res.error);
      return loadProfile();
    }).then(function (profile) {
      start(onRemoteFn);
      return profile;
    });
    });
  }

  function signOut() {
    status.role = "";
    status.userId = "";
    stop();
    if (!client) return Promise.resolve();
    return client.auth.signOut().catch(function () {}).then(function () {
      emit();
    });
  }

  function currentAuthUser() {
    return sessionUser();
  }

  function listProfiles() {
    if (!client) return Promise.resolve([]);
    return client.from("profiles").select("id, name, role, player_id, created_at").order("created_at", { ascending: true })
      .then(function (res) {
        if (res.error) throw res.error;
        return (res.data || []).map(function (u) {
          return { id: u.id, name: u.name, role: u.role, playerId: u.player_id || "", createdAt: u.created_at };
        });
      });
  }

  function updateProfile(id, input) {
    if (!client) return Promise.reject(new Error("Sem conexao"));
    var patch = {};
    if (input.name != null) patch.name = String(input.name).trim();
    if (input.role === "admin" || input.role === "player") patch.role = input.role;
    if (input.playerId != null) patch.player_id = input.playerId || null;
    return client.from("profiles").update(patch).eq("id", id).then(function (res) {
      if (res.error) throw res.error;
      var sess = sessionUser();
      if (sess && sess.id === id && global.PokerStore && PokerStore.setSession) {
        PokerStore.setSession({
          id: sess.id,
          email: sess.email,
          name: patch.name != null ? patch.name : sess.name,
          role: patch.role || sess.role,
          playerId: patch.player_id != null ? (patch.player_id || "") : sess.playerId
        });
      }
      return true;
    });
  }

  global.PokerCloud = {
    getConfig: getConfig,
    setConfig: setConfig,
    clearConfig: clearConfig,
    isConfigured: isConfigured,
    isConfigPending: isConfigPending,
    init: init,
    waitConfig: waitConfig,
    start: start,
    stop: stop,
    pushState: pushState,
    schedulePush: schedulePush,
    syncNow: syncNow,
    fetchPlayers: fetchPlayers,
    upsertPlayer: upsertPlayer,
    removePlayer: removePlayer,
    signIn: signIn,
    signUp: signUp,
    claimAdmin: claimAdmin,
    signOut: signOut,
    currentAuthUser: currentAuthUser,
    listProfiles: listProfiles,
    updateProfile: updateProfile,
    onStatus: onStatus,
    status: function () { return status; },
    supabaseOk: supabaseOk,
    formatCloudError: formatCloudError,
    configMissingError: configMissingError,
    clubId: function () { return CLUB_ID; }
  };
})(typeof window !== "undefined" ? window : globalThis);
