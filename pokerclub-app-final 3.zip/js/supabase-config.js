window.POKER_SUPABASE_CONFIG = window.POKER_SUPABASE_CONFIG || null;
window.__pokerSupabaseConfigPromise = (function () {
  function ok(cfg) {
    if (!cfg || !cfg.url || !cfg.anonKey) return null;
    if (/service_role/i.test(String(cfg.anonKey))) return null;
    return {
      url: String(cfg.url).replace(/\/+$/, ""),
      anonKey: String(cfg.anonKey),
      clubId: "pokerclub"
    };
  }
  if (ok(window.POKER_SUPABASE_CONFIG)) {
    window.POKER_SUPABASE_CONFIG = ok(window.POKER_SUPABASE_CONFIG);
    return Promise.resolve(window.POKER_SUPABASE_CONFIG);
  }
  var paths = ["/.netlify/functions/supabase-config", "/api/supabase-config"];
  function next(i) {
    if (i >= paths.length) return Promise.resolve(null);
    return fetch(paths[i], { cache: "no-store" }).then(function (res) {
      if (!res.ok) throw new Error("skip");
      return res.json();
    }).then(function (cfg) {
      var n = ok(cfg);
      if (n) {
        window.POKER_SUPABASE_CONFIG = n;
        return n;
      }
      return next(i + 1);
    }).catch(function () { return next(i + 1); });
  }
  return next(0);
})();
