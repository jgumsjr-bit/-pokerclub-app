exports.handler = async function () {
  function clean(v) {
    return String(v || "").trim().replace(/^['"]|['"]$/g, "");
  }
  var url = clean(process.env.USER_SUPABASE_URL || process.env.SUPABASE_URL || "");
  var anonKey = clean(process.env.USER_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || "");
  var headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, no-cache, must-revalidate",
    "Access-Control-Allow-Origin": "*"
  };
  if (!url || !anonKey) {
    return {
      statusCode: 503,
      headers: headers,
      body: JSON.stringify({
        error: "CONFIG",
        message: "USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY ausentes no Netlify",
        details: "Site configuration > Environment variables > Redeploy",
        hint: "Use a anon/publishable key. Nunca service_role."
      })
    };
  }
  if (/service_role/i.test(anonKey)) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({ error: "SERVICE_ROLE", message: "Recusado. Use a anon key." })
    };
  }
  return {
    statusCode: 200,
    headers: headers,
    body: JSON.stringify({
      url: url.replace(/\/+$/, ""),
      anonKey: anonKey,
      clubId: "pokerclub"
    })
  };
};
