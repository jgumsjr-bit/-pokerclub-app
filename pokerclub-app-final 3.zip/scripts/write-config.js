var fs = require("fs");
var path = require("path");

function clean(v) {
  return String(v || "").trim().replace(/^['"]|['"]$/g, "");
}

var url = clean(process.env.USER_SUPABASE_URL || process.env.SUPABASE_URL || "");
var anonKey = clean(process.env.USER_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || "");
var clubId = "pokerclub";

var out = path.join(__dirname, "..", "js", "supabase-config.js");

var loader = [
  "window.POKER_SUPABASE_CONFIG = window.POKER_SUPABASE_CONFIG || null;",
  "window.__pokerSupabaseConfigPromise = (function () {",
  "  function ok(cfg) {",
  "    if (!cfg || !cfg.url || !cfg.anonKey) return null;",
  "    if (/service_role/i.test(String(cfg.anonKey))) return null;",
  "    return { url: String(cfg.url).replace(/\\/+$/, \"\"), anonKey: String(cfg.anonKey), clubId: \"pokerclub\" };",
  "  }",
  "  if (ok(window.POKER_SUPABASE_CONFIG)) {",
  "    window.POKER_SUPABASE_CONFIG = ok(window.POKER_SUPABASE_CONFIG);",
  "    return Promise.resolve(window.POKER_SUPABASE_CONFIG);",
  "  }",
  "  var paths = [\"/.netlify/functions/supabase-config\", \"/api/supabase-config\"];",
  "  function next(i) {",
  "    if (i >= paths.length) return Promise.resolve(null);",
  "    return fetch(paths[i], { cache: \"no-store\" }).then(function (res) {",
  "      if (!res.ok) throw new Error(\"skip\");",
  "      return res.json();",
  "    }).then(function (cfg) {",
  "      var n = ok(cfg);",
  "      if (n) { window.POKER_SUPABASE_CONFIG = n; return n; }",
  "      return next(i + 1);",
  "    }).catch(function () { return next(i + 1); });",
  "  }",
  "  return next(0);",
  "})();",
  ""
].join("\n");

if (!url || !anonKey) {
  fs.writeFileSync(out, loader);
  console.error("BUILD FAIL: USER_SUPABASE_URL e USER_SUPABASE_ANON_KEY sao obrigatorios no Netlify.");
  console.error("Site configuration > Environment variables > adicione as duas > Trigger deploy / Redeploy.");
  console.error("ZIP/Drop: a funcao /.netlify/functions/supabase-config le as env em runtime.");
  process.exit(1);
}

if (!/^https:\/\//i.test(url)) {
  console.error("BUILD FAIL: USER_SUPABASE_URL deve comecar com https://");
  process.exit(1);
}

if (/service_role/i.test(anonKey)) {
  console.error("Refuse to write service_role key. Use the anon / publishable key.");
  process.exit(1);
}

if (process.env.USER_SUPABASE_SERVICE_ROLE || process.env.SUPABASE_SERVICE_ROLE) {
  console.error("Refuse to write service_role. Do not set SERVICE_ROLE in the frontend build.");
  process.exit(1);
}

var cfg = { url: String(url).replace(/\/+$/, ""), anonKey: String(anonKey), clubId: String(clubId || "pokerclub") };
fs.writeFileSync(out, "window.POKER_SUPABASE_CONFIG = " + JSON.stringify(cfg, null, 2) + ";\n" + loader);
console.log("Wrote js/supabase-config.js for club " + cfg.clubId);
