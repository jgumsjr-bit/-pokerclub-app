# Supabase — Poker Club A2.1

## O que voce precisa informar

Somente 2 valores obrigatorios (e 1 opcional):

1. Project URL
   Settings > API > Project URL
   Exemplo: `https://abcdefgh.supabase.co`
2. anon / publishable key
   Settings > API > Project API keys > `anon` `public`
3. ID do clube (opcional)
   Padrao: `pokerclub`

Nao use a chave `service_role`. O aplicativo recusa essa chave de proposito.

## Instalacao

1. Crie o projeto no Supabase.
2. SQL Editor > New query > cole `schema.sql` > Run.
3. Defina o codigo do primeiro admin:

```sql
update public.clubs
set admin_setup_hash = crypt('SEU_CODIGO_SECRETO', gen_salt('bf'))
where id = 'pokerclub';
```

4. Authentication > Providers > Email: desative **Confirm email**.
5. Database > Replication: confirme a tabela `clubs` no Realtime.
6. Publique com `USER_SUPABASE_URL` e `USER_SUPABASE_ANON_KEY`.

O SQL cria:

- `clubs` (documento JSON sincronizado; sem senhas)
- `profiles` (Auth: nome, papel admin/jogador)
- `players`, `tournaments`, `tournament_entries`, `tournament_levels`
- `payments`, `cash_entries`, `hands`, `seasons`, `clocks`
- remove `club_users` se existir
- RLS: membro autenticado le; so admin grava `clubs`
- cadastro Auth sempre cria perfil **player**
- `claim_club_admin(club, codigo)` promove o primeiro admin e apaga o hash
- trigger que espelha `clubs.payload` (remove users/passHash)
- Realtime na tabela `clubs`

## Papeis

- Cadastro pelo link publico = **player**
- Primeiro admin = cadastro + codigo secreto do SQL
- Depois do primeiro admin, o codigo deixa de valer
- Admin pode promover jogador em Conta > Acessos
