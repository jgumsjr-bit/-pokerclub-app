-- Poker Club A2.1 — Auth + RLS + Realtime
-- SQL Editor do Supabase: cole e execute uma vez.
-- Frontend: somente Project URL + anon/publishable key.
-- Nunca use service_role no aplicativo.

create extension if not exists pgcrypto;

-- Auth: desative confirmacao de e-mail (Authentication > Providers > Email)
-- para cadastro por nome+senha no celular.

create table if not exists public.clubs (
  id text primary key,
  name text not null default 'Poker Club',
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by text,
  admin_setup_hash text
);

alter table public.clubs add column if not exists admin_setup_hash text;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  club_id text not null references public.clubs(id) on delete cascade,
  name text not null,
  role text not null default 'player' check (role in ('admin', 'player')),
  player_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id text not null,
  club_id text not null references public.clubs(id) on delete cascade,
  name text not null,
  nickname text,
  phone text,
  created_at text,
  primary key (club_id, id)
);

create table if not exists public.tournaments (
  id text not null,
  club_id text not null references public.clubs(id) on delete cascade,
  name text not null,
  date text,
  time text,
  buy_in numeric,
  status text,
  current_level integer default 0,
  remaining_sec integer default 0,
  timer_running boolean default false,
  timer_updated_at bigint,
  round_ended boolean default false,
  round_ended_at bigint,
  champion_id text,
  finished_at text,
  levels jsonb default '[]'::jsonb,
  entries jsonb default '[]'::jsonb,
  extra jsonb default '{}'::jsonb,
  primary key (club_id, id)
);

create table if not exists public.tournament_entries (
  club_id text not null,
  tournament_id text not null,
  player_id text not null,
  name_snapshot text,
  nick_snapshot text,
  paid boolean default false,
  paid_amount numeric default 0,
  paid_at text,
  eliminated boolean default false,
  position integer,
  primary key (club_id, tournament_id, player_id)
);

create table if not exists public.tournament_levels (
  club_id text not null,
  tournament_id text not null,
  level_index integer not null,
  minutes integer not null default 15,
  small integer not null default 0,
  big integer not null default 0,
  ante integer not null default 0,
  primary key (club_id, tournament_id, level_index)
);

create table if not exists public.payments (
  id text not null,
  club_id text not null references public.clubs(id) on delete cascade,
  player_id text,
  tournament_id text,
  amount numeric default 0,
  date text,
  status text,
  primary key (club_id, id)
);

create table if not exists public.cash_entries (
  id text not null,
  club_id text not null references public.clubs(id) on delete cascade,
  type text,
  amount numeric,
  description text,
  category text,
  date text,
  tournament_id text,
  player_id text,
  auto boolean default false,
  primary key (club_id, id)
);

create table if not exists public.hands (
  id text not null,
  club_id text not null references public.clubs(id) on delete cascade,
  type text,
  label text,
  points integer default 0,
  player_id text,
  tournament_id text,
  date text,
  note text,
  primary key (club_id, id)
);

create table if not exists public.seasons (
  club_id text not null references public.clubs(id) on delete cascade,
  year text not null,
  champion_id text,
  points integer default 0,
  closed_at text,
  ranking jsonb default '[]'::jsonb,
  primary key (club_id, year)
);

create table if not exists public.clocks (
  club_id text primary key references public.clubs(id) on delete cascade,
  remaining_sec integer not null default 600,
  duration_sec integer not null default 600,
  timer_running boolean not null default false,
  timer_updated_at bigint,
  paused boolean not null default false,
  start_at bigint,
  end_at bigint,
  cycle_id text default '',
  status text default 'ready'
);
alter table public.clocks add column if not exists paused boolean not null default false;
alter table public.clocks add column if not exists start_at bigint;
alter table public.clocks add column if not exists end_at bigint;
alter table public.clocks add column if not exists cycle_id text default '';
alter table public.clocks add column if not exists status text default 'ready';

drop table if exists public.club_users;

create index if not exists profiles_club_idx on public.profiles (club_id);
create index if not exists players_club_idx on public.players (club_id);
create index if not exists tournaments_club_idx on public.tournaments (club_id);
create index if not exists payments_club_idx on public.payments (club_id);
create index if not exists cash_club_idx on public.cash_entries (club_id);
create index if not exists hands_club_idx on public.hands (club_id);
create index if not exists seasons_club_idx on public.seasons (club_id);

insert into public.clubs (id, name, payload)
values ('pokerclub', 'Poker Club', '{}'::jsonb)
on conflict (id) do nothing;

update public.profiles
   set club_id = 'pokerclub'
 where club_id is distinct from 'pokerclub';

create or replace function public.is_club_admin(p_club text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and club_id = p_club and role = 'admin'
  );
$$;

create or replace function public.is_club_member(p_club text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and club_id = p_club
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_club text;
  v_name text;
begin
  v_club := 'pokerclub';
  v_name := coalesce(nullif(trim(new.raw_user_meta_data->>'name'), ''), split_part(new.email, '@', 1), 'Jogador');
  insert into public.clubs (id, name) values (v_club, 'Poker Club') on conflict (id) do nothing;
  insert into public.profiles (id, club_id, name, role)
  values (new.id, v_club, v_name, 'player')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.profiles_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    if current_setting('pokerclub.claiming_admin', true) is distinct from 'on' then
      new.role := 'player';
    end if;
    return new;
  end if;
  if new.role is distinct from old.role then
    if current_setting('pokerclub.claiming_admin', true) is distinct from 'on'
       and not public.is_club_admin(old.club_id) then
      raise exception 'Somente o administrador pode alterar o papel';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_profiles_guard on public.profiles;
create trigger trg_profiles_guard
before insert or update on public.profiles
for each row execute function public.profiles_guard();

create or replace function public.claim_club_admin(p_club text, p_code text)
returns public.profiles
language plpgsql
security definer
set search_path = public
as $$
declare
  v_hash text;
  v_has_admin boolean;
  v_prof public.profiles;
begin
  if auth.uid() is null then
    raise exception 'Entre com nome e senha antes';
  end if;
  if p_code is null or length(trim(p_code)) < 4 then
    raise exception 'Informe o codigo de administrador';
  end if;
  select admin_setup_hash into v_hash from public.clubs where id = p_club;
  if v_hash is null or v_hash = '' then
    raise exception 'Codigo de admin nao configurado no Supabase';
  end if;
  if crypt(trim(p_code), v_hash) is distinct from v_hash then
    raise exception 'Codigo de administrador invalido';
  end if;
  select exists(select 1 from public.profiles where club_id = p_club and role = 'admin') into v_has_admin;
  if v_has_admin then
    raise exception 'Ja existe administrador neste clube';
  end if;
  perform set_config('pokerclub.claiming_admin', 'on', true);
  update public.profiles
     set role = 'admin'
   where id = auth.uid() and club_id = p_club
  returning * into v_prof;
  if v_prof is null then
    raise exception 'Perfil nao encontrado';
  end if;
  update public.clubs set admin_setup_hash = null where id = p_club;
  return v_prof;
end;
$$;

create or replace function public.set_club_payload(p_club text, p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payload jsonb;
  v_name text;
begin
  if auth.uid() is null then
    raise exception 'Entre com nome e senha';
  end if;
  if not public.is_club_member(p_club) then
    raise exception 'Sem acesso a este clube';
  end if;
  v_payload := coalesce(p_payload, '{}'::jsonb);
  v_payload := v_payload - 'users' - 'passHash' - 'pass_hash' - 'password' - 'passwords' - 'players';
  v_payload := jsonb_set(v_payload, '{updatedAt}', to_jsonb((extract(epoch from clock_timestamp()) * 1000)::bigint), true);
  select name into v_name from public.profiles where id = auth.uid();
  v_payload := jsonb_set(v_payload, '{updatedBy}', to_jsonb(coalesce(v_name, 'membro')), true);
  update public.clubs
     set payload = v_payload,
         updated_at = now(),
         updated_by = coalesce(v_name, 'membro')
   where id = p_club;
  if not found then
    raise exception 'Clube nao encontrado';
  end if;
  return v_payload;
end;
$$;

drop function if exists public.set_club_clock(text, integer, integer, boolean, bigint, boolean);
create or replace function public.set_club_clock(
  p_club text,
  p_remaining integer,
  p_duration integer,
  p_running boolean,
  p_updated_at bigint,
  p_paused boolean,
  p_start_at bigint default null,
  p_end_at bigint default null,
  p_cycle_id text default null,
  p_status text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payload jsonb;
  v_clock jsonb;
begin
  if auth.uid() is null then
    raise exception 'Entre com nome e senha';
  end if;
  if not public.is_club_member(p_club) then
    raise exception 'Sem acesso a este clube';
  end if;
  select payload into v_payload from public.clubs where id = p_club;
  if v_payload is null then
    v_payload := '{}'::jsonb;
  end if;
  v_clock := jsonb_build_object(
    'remainingSec', coalesce(p_remaining, 600),
    'durationSec', coalesce(p_duration, 600),
    'timerRunning', coalesce(p_running, false),
    'timerUpdatedAt', p_updated_at,
    'paused', coalesce(p_paused, false),
    'startAt', p_start_at,
    'endAt', p_end_at,
    'cycleId', coalesce(p_cycle_id, ''),
    'status', coalesce(p_status, case when coalesce(p_running, false) then 'running' when coalesce(p_paused, false) then 'paused' else 'ready' end)
  );
  v_payload := jsonb_set(v_payload, '{clock}', v_clock, true);
  v_payload := jsonb_set(v_payload, '{updatedAt}', to_jsonb((extract(epoch from clock_timestamp()) * 1000)::bigint), true);
  update public.clubs
     set payload = v_payload,
         updated_at = now(),
         updated_by = coalesce((select name from public.profiles where id = auth.uid()), 'membro')
   where id = p_club;
  return v_clock;
end;
$$;

create or replace function public.sync_club_payload()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  rec jsonb;
  t jsonb;
  e jsonb;
  lv jsonb;
  i integer;
  clean jsonb;
begin
  clean := coalesce(new.payload, '{}'::jsonb);
  clean := clean - 'users' - 'passHash' - 'pass_hash' - 'password' - 'passwords' - 'players';
  new.payload := clean;

  delete from public.tournament_entries where club_id = new.id;
  delete from public.tournament_levels where club_id = new.id;
  delete from public.tournaments where club_id = new.id;
  delete from public.payments where club_id = new.id;
  delete from public.cash_entries where club_id = new.id;
  delete from public.hands where club_id = new.id;
  delete from public.seasons where club_id = new.id;
  delete from public.clocks where club_id = new.id;

  for t in select value from jsonb_array_elements(coalesce(new.payload->'tournaments', '[]'::jsonb))
  loop
    insert into public.tournaments (
      id, club_id, name, date, time, buy_in, status, current_level, remaining_sec,
      timer_running, timer_updated_at, round_ended, round_ended_at, champion_id, finished_at,
      levels, entries, extra
    ) values (
      t->>'id', new.id, coalesce(t->>'name', ''), t->>'date', t->>'time',
      coalesce((t->>'buyIn')::numeric, 0), t->>'status',
      coalesce((t->>'currentLevel')::int, 0), coalesce((t->>'remainingSec')::int, 0),
      coalesce((t->>'timerRunning')::boolean, false), (t->>'timerUpdatedAt')::bigint,
      coalesce((t->>'roundEnded')::boolean, false), (t->>'roundEndedAt')::bigint,
      t->>'championId', t->>'finishedAt',
      coalesce(t->'levels', '[]'::jsonb), coalesce(t->'entries', '[]'::jsonb),
      jsonb_build_object(
        'emergencyStarted', t->'emergencyStarted',
        'emergencyStartedBy', t->'emergencyStartedBy',
        'emergencyStartedById', t->'emergencyStartedById',
        'emergencyStartedAt', t->'emergencyStartedAt'
      )
    )
    on conflict do nothing;

    i := 0;
    for lv in select value from jsonb_array_elements(coalesce(t->'levels', '[]'::jsonb))
    loop
      insert into public.tournament_levels (club_id, tournament_id, level_index, minutes, small, big, ante)
      values (
        new.id, t->>'id', i,
        coalesce((lv->>'minutes')::int, 15),
        coalesce((lv->>'small')::int, 0),
        coalesce((lv->>'big')::int, 0),
        coalesce((lv->>'ante')::int, 0)
      )
      on conflict do nothing;
      i := i + 1;
    end loop;

    for e in select value from jsonb_array_elements(coalesce(t->'entries', '[]'::jsonb))
    loop
      insert into public.tournament_entries (
        club_id, tournament_id, player_id, name_snapshot, nick_snapshot,
        paid, paid_amount, paid_at, eliminated, position
      ) values (
        new.id, t->>'id', e->>'playerId', e->>'nameSnapshot', e->>'nickSnapshot',
        coalesce((e->>'paid')::boolean, false), coalesce((e->>'paidAmount')::numeric, 0),
        e->>'paidAt', coalesce((e->>'eliminated')::boolean, false), (e->>'position')::int
      )
      on conflict do nothing;
    end loop;
  end loop;

  for rec in select value from jsonb_array_elements(coalesce(new.payload->'payments', '[]'::jsonb))
  loop
    insert into public.payments (id, club_id, player_id, tournament_id, amount, date, status)
    values (rec->>'id', new.id, rec->>'playerId', rec->>'tournamentId', coalesce((rec->>'amount')::numeric, 0), rec->>'date', rec->>'status')
    on conflict do nothing;
  end loop;

  for rec in select value from jsonb_array_elements(coalesce(new.payload->'cash', '[]'::jsonb))
  loop
    insert into public.cash_entries (id, club_id, type, amount, description, category, date, tournament_id, player_id, auto)
    values (
      rec->>'id', new.id, rec->>'type', coalesce((rec->>'amount')::numeric, 0),
      rec->>'description', rec->>'category', rec->>'date', rec->>'tournamentId', rec->>'playerId',
      coalesce((rec->>'auto')::boolean, false)
    )
    on conflict do nothing;
  end loop;

  for rec in select value from jsonb_array_elements(coalesce(new.payload->'hands', '[]'::jsonb))
  loop
    insert into public.hands (id, club_id, type, label, points, player_id, tournament_id, date, note)
    values (
      rec->>'id', new.id, rec->>'type', rec->>'label', coalesce((rec->>'points')::int, 0),
      rec->>'playerId', rec->>'tournamentId', rec->>'date', rec->>'note'
    )
    on conflict do nothing;
  end loop;

  for rec in select value from jsonb_array_elements(coalesce(new.payload->'seasons', '[]'::jsonb))
  loop
    insert into public.seasons (club_id, year, champion_id, points, closed_at, ranking)
    values (new.id, rec->>'year', rec->>'championId', coalesce((rec->>'points')::int, 0), rec->>'closedAt', coalesce(rec->'ranking', '[]'::jsonb))
    on conflict do nothing;
  end loop;

  rec := coalesce(new.payload->'clock', '{}'::jsonb);
  insert into public.clocks (club_id, remaining_sec, duration_sec, timer_running, timer_updated_at, paused, start_at, end_at, cycle_id, status)
  values (
    new.id,
    coalesce((rec->>'remainingSec')::int, 600),
    coalesce((rec->>'durationSec')::int, 600),
    coalesce((rec->>'timerRunning')::boolean, false),
    (rec->>'timerUpdatedAt')::bigint,
    coalesce((rec->>'paused')::boolean, false),
    (rec->>'startAt')::bigint,
    (rec->>'endAt')::bigint,
    coalesce(rec->>'cycleId', ''),
    coalesce(rec->>'status', 'ready')
  )
  on conflict (club_id) do update set
    remaining_sec = excluded.remaining_sec,
    duration_sec = excluded.duration_sec,
    timer_running = excluded.timer_running,
    timer_updated_at = excluded.timer_updated_at,
    paused = excluded.paused,
    start_at = excluded.start_at,
    end_at = excluded.end_at,
    cycle_id = excluded.cycle_id,
    status = excluded.status;

  return new;
end;
$$;

drop trigger if exists trg_sync_club_payload on public.clubs;
create trigger trg_sync_club_payload
before insert or update of payload on public.clubs
for each row execute function public.sync_club_payload();

alter table public.clubs enable row level security;
alter table public.profiles enable row level security;
alter table public.players enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_entries enable row level security;
alter table public.tournament_levels enable row level security;
alter table public.payments enable row level security;
alter table public.cash_entries enable row level security;
alter table public.hands enable row level security;
alter table public.seasons enable row level security;
alter table public.clocks enable row level security;

drop policy if exists clubs_select on public.clubs;
drop policy if exists clubs_insert on public.clubs;
drop policy if exists clubs_update on public.clubs;
drop policy if exists clubs_delete on public.clubs;
create policy clubs_select on public.clubs for select to authenticated
  using (public.is_club_member(id));
create policy clubs_insert on public.clubs for insert to authenticated
  with check (public.is_club_admin(id));
create policy clubs_update on public.clubs for update to authenticated
  using (public.is_club_admin(id)) with check (public.is_club_admin(id));
create policy clubs_delete on public.clubs for delete to authenticated
  using (public.is_club_admin(id));

drop policy if exists profiles_select on public.profiles;
drop policy if exists profiles_insert on public.profiles;
drop policy if exists profiles_update on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_club_member(club_id));
create policy profiles_insert on public.profiles for insert to authenticated
  with check (id = auth.uid() and role = 'player');
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_club_admin(club_id))
  with check (
    (id = auth.uid() and role = 'player')
    or public.is_club_admin(club_id)
  );

drop policy if exists players_read on public.players;
drop policy if exists players_insert on public.players;
drop policy if exists players_update on public.players;
drop policy if exists players_delete on public.players;
create policy players_read on public.players for select to authenticated using (public.is_club_member(club_id));
create policy players_insert on public.players for insert to authenticated with check (public.is_club_member(club_id));
create policy players_update on public.players for update to authenticated using (public.is_club_member(club_id)) with check (public.is_club_member(club_id));
create policy players_delete on public.players for delete to authenticated using (public.is_club_member(club_id));
drop policy if exists tournaments_read on public.tournaments;
create policy tournaments_read on public.tournaments for select to authenticated using (public.is_club_member(club_id));
drop policy if exists entries_read on public.tournament_entries;
create policy entries_read on public.tournament_entries for select to authenticated using (public.is_club_member(club_id));
drop policy if exists levels_read on public.tournament_levels;
create policy levels_read on public.tournament_levels for select to authenticated using (public.is_club_member(club_id));
drop policy if exists payments_read on public.payments;
create policy payments_read on public.payments for select to authenticated using (public.is_club_member(club_id));
drop policy if exists cash_read on public.cash_entries;
create policy cash_read on public.cash_entries for select to authenticated using (public.is_club_member(club_id));
drop policy if exists hands_read on public.hands;
create policy hands_read on public.hands for select to authenticated using (public.is_club_member(club_id));
drop policy if exists seasons_read on public.seasons;
create policy seasons_read on public.seasons for select to authenticated using (public.is_club_member(club_id));
drop policy if exists clocks_read on public.clocks;
create policy clocks_read on public.clocks for select to authenticated using (public.is_club_member(club_id));

revoke all on public.clubs from authenticated, anon, public;
grant usage on schema public to authenticated;
grant select (id, name, payload, updated_at, updated_by) on public.clubs to authenticated;
grant insert (id, name, payload, updated_at, updated_by) on public.clubs to authenticated;
grant update (name, payload, updated_at, updated_by) on public.clubs to authenticated;
grant delete on public.clubs to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.players to authenticated;
grant select on public.tournaments, public.tournament_entries,
  public.tournament_levels, public.payments, public.cash_entries, public.hands,
  public.seasons, public.clocks to authenticated;
grant execute on function public.is_club_admin(text) to authenticated;
grant execute on function public.is_club_member(text) to authenticated;
grant execute on function public.claim_club_admin(text, text) to authenticated;
grant execute on function public.set_club_clock(text, integer, integer, boolean, bigint, boolean, bigint, bigint, text, text) to authenticated;
grant execute on function public.set_club_payload(text, jsonb) to authenticated;

alter table public.clubs replica identity full;
alter table public.players replica identity full;
do $$
begin
  begin
    alter publication supabase_realtime add table public.clubs;
  exception when duplicate_object then
    null;
  end;
  begin
    alter publication supabase_realtime add table public.players;
  exception when duplicate_object then
    null;
  end;
end $$;

-- Obrigatorio depois deste SQL (troque SEU_CODIGO_SECRETO):
-- update public.clubs
-- set admin_setup_hash = crypt('SEU_CODIGO_SECRETO', gen_salt('bf'))
-- where id = 'pokerclub';
--
-- Sem esse UPDATE, ninguem vira admin pelo link publico.
-- Depois do primeiro admin, o codigo e apagado automaticamente.
