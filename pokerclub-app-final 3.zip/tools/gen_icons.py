#!/usr/bin/env python3
import struct, zlib, os

OUT = "/workspace/icons"

def png(path, w, h, pixel_fn):
    raw = b""
    for y in range(h):
        raw += b"\x00"
        for x in range(w):
            r, g, b = pixel_fn(x, y, w, h)
            raw += bytes((r, g, b))
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xffffffff)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(data)

def clamp(v):
    return max(0, min(255, int(v)))

def mix(a, b, t):
    return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(3))

def icon(x, y, w, h):
    cx, cy = (w - 1) / 2, (h - 1) / 2
    dx, dy = x - cx, y - cy
    d = (dx * dx + dy * dy) ** 0.5
    r = w * 0.46
    felt = (10, 31, 24)
    gold = (212, 175, 55)
    gold2 = (168, 130, 28)
    inner = (18, 55, 42)
    cream = (245, 236, 210)
    if d > r + 2:
        return felt
    if d > r:
        t = d - r
        return mix(gold, felt, min(1, t / 2))
    ring = w * 0.035
    if d > r - ring:
        ang = abs(((dx / (d or 1)) + 1) * 0.5)
        return mix(gold, gold2, ang)
    if d > r - ring * 2.2:
        return inner
    # inner chip
    if d > r * 0.22:
        # radial felt
        t = (d - r * 0.22) / (r * 0.7)
        return mix(inner, (12, 42, 32), t)
    # center disc
    if d > r * 0.12:
        return gold
    return cream

os.makedirs(OUT, exist_ok=True)
for size, name in [(180, "apple-touch-icon.png"), (192, "icon-192.png"), (512, "icon-512.png")]:
    png(os.path.join(OUT, name), size, size, icon)
print("ok")
